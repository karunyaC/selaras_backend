package com.selaras.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.selaras.api.entity.DSPOverview;

public interface DSPOverviewRepository extends JpaRepository<DSPOverview, Long> {

    DSPOverview findByCode(String planCode);
}
