package com.selaras.api.dto;


import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class DepartmentDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;

    private String name;
    private Long agencyCode;
    private String function;

    private Long addressId;

    private Long vote;

    private String voteCode;

    private Boolean active;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;

    private String addressLineNumber1;

    private String addressLineNumber2;

    private String city;

    private String postalCode;

    private Integer stateId;

    private String websiteUrl;
}
