package com.selaras.api.repository;

import com.selaras.api.entity.Helpdesk;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HelpdeskRepository extends JpaRepository<Helpdesk, Long> {

    Helpdesk findBySrNumber(Long srNumber);
}
