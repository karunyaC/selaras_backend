package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.requests.AppSecurityRequest;
import com.selaras.api.responses.AppSecurityResponse;
import com.selaras.api.service.AppSecurityServices;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ApplicationSecurityController {

    private final AppSecurityServices appSecurityServices;

    @Operation(summary = "Save Application Security", description = "Save application security parameters")
    @ApiResponse(responseCode = "200", description = "OK")
    @AuditTrail(recordType = "Authorization", action = "Save Application Security", presentValue = "Security parameters saved")
    @PostMapping("/appsecurity")
    public ResponseEntity<?> saveAppSecurity(@RequestBody List<AppSecurityRequest> request) {

        return ResponseEntity.ok().body(appSecurityServices.saveAppSecurity(request));
    }

    @Operation(summary = "Get all Application Security", description = "Retrieve all security parameters")
    @ApiResponse(responseCode = "200", description = "OK")
    @AuditTrail(recordType = "Authorization", action = "Retrieve Application Security by Type", presentValue = "Security parameters retrieved for specified type")
    @GetMapping("/appsecurity/policy/{securityType}")
    public ResponseEntity<?> getAppSecurities(@PathVariable String securityType) {

        return ResponseEntity.ok().body(appSecurityServices.getAppSecurities(securityType));
    }

    @Operation(summary = "Get specific Application Security", description = "Retrieve security parameters by Id")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/appsecurity/{id}")
    @AuditTrail(recordType = "Authorization", action = "Retrieve Application Security by ID",previousValue = "Previous minimum password age", presentValue = "Security parameters retrieved")
    public ResponseEntity<?> getAppSecuritiesById(@PathVariable Long id) throws ResourceNotFoundException {

        return ResponseEntity.ok().body(appSecurityServices.getAppSecuritiesById(id));
    }
    @Operation(summary = "Update Password Rule", description = "Update the 'active' and/or 'ruleValue' fields of a password rule by its ID")
    @ApiResponse(responseCode = "200", description = "OK")
    @AuditTrail(recordType = "Authorization", action = "Update Application Security by ID",previousValue = "Previous minimum password age", presentValue = "Security parameters retrieved")
    @PutMapping("/password-rules/Minimum Password Age/{id}")
    public ResponseEntity<AppSecurityResponse> updatePasswordRule(
            @PathVariable Long id,
            @RequestParam(required = false) Boolean active,
            @RequestParam(required = false) String ruleValue) throws ResourceNotFoundException {

        AppSecurityResponse response = appSecurityServices.updateAppSecuritiesById(id, active, ruleValue);
        return ResponseEntity.ok(response);
    }

}
