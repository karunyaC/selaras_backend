package com.selaras.api.repository;

import com.selaras.api.entity.MeasuringUnitKpi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MeasuringUnitKpiRepository extends JpaRepository< MeasuringUnitKpi,Long > {
}
