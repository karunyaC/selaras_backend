package com.selaras.api.exception;

public class ConfigDataNotFoundException extends RuntimeException {
    public ConfigDataNotFoundException( String message ) {
        super( message );
    }
}
