package com.selaras.api.requests;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectStrategicPlanRequest {

    private String startYear;
    private String endYear;
    private int noOfCores;
    private String coreName;
    private String code;
    private boolean status;
}
