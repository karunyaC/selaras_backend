package com.selaras.api.requests;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserNotificationRequest {
   private List<Long> announcementTo;
   private String description;
   private List<Long> platform;
   private String promotionScheduling;
   private String promotionTitle;
   private Long promotionCategoryId;
   private String status;
}
