package com.selaras.api.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "sp_strategy")
public class SPStrategy {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer rowId;

    @ManyToOne
    @JoinColumn(name = "sp_code", referencedColumnName = "spCode")
    private SPOverview spOverview;

    @ManyToOne
    @JoinColumn(name = "sp_core_id", referencedColumnName = "spCoreId")
    private SPCore spCore;

    private String spPlanCode;

    @Column(unique = true, nullable = false)
    private String spStratId;

    private String spStratPreferredName;
    private String spStratPreferredCode;
    private LocalDateTime createdAt;
    private LocalDateTime modifiedAt;
}
