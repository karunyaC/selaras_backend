package com.selaras.api.requests;


import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CoreDTO {
    private String coreName;
    private List<StrategyDTO> strategy;
}
