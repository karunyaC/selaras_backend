package com.selaras.api.controller;


import com.selaras.api.audittrail.annotation.AuditTrail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

import com.selaras.api.dto.DepartmentDTO;
import com.selaras.api.entity.Department;
import com.selaras.api.entity.UserAccount;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.DepartmentProjectRepository;
import com.selaras.api.repository.DepartmentRepository;
import com.selaras.api.responses.AgencyInfoResponse;
import com.selaras.api.responses.ApplicationUsersResponse;
import com.selaras.api.responses.CompanyResponse;
import com.selaras.api.service.CompanyAssociationService;
import com.selaras.api.service.DepartmentService;
import com.selaras.api.service.UserAccountService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;

import java.util.stream.Collectors;
import java.util.Collections;
import java.util.Comparator;






@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor

public class DashboardController {
	private final UserAccountService userAccountService;
    private final DepartmentService departmentService;
	private final DepartmentRepository departmentRepository;
    private final CompanyAssociationService companyAssociationService;

@Operation(summary = "Get Number of App Users", description = "Returns the count of active, cancelled, and total users.")
@ApiResponse(responseCode = "200", description = "Counts retrieved successfully")
@GetMapping("/user-status")
@AuditTrail(recordType = "User", action = "Retrieve Number of Application Users", presentValue = "Counts of active, cancelled, and total users retrieved")
public ResponseEntity<Map<String, Long>> getNumberofAppUsers() {
    List<UserAccount> users = userAccountService.getAllUsers();
    if (users == null || users.isEmpty()) {
        Map<String, Long> emptyStats = new HashMap<>();
        emptyStats.put("active", 0L);
        emptyStats.put("cancelled", 0L);
        emptyStats.put("total", 0L);
        return ResponseEntity.ok(emptyStats);
    }

    long activeUsers = users.stream().filter(UserAccount::getActive).count();
    long nonActiveUsers = users.stream().filter(user -> !user.getActive()).count();
    long totalUsers = users.size();

    Map<String, Long> stats = new HashMap<>();
    stats.put("active", activeUsers);
    stats.put("cancelled", nonActiveUsers);
    stats.put("total", totalUsers);

    return ResponseEntity.ok(stats);
}
@Operation(summary = "Get User Information", description = "Returns the name and creation date of all users along with the total count.")
@ApiResponse(responseCode = "200", description = "Data retrieved successfully")
@GetMapping("/application-users")
@AuditTrail(recordType = "User", action = "Retrieve User Information", presentValue = "User names and creation dates retrieved")
public ResponseEntity<Map<String, Object>> applicationusers() throws ResourceNotFoundException {
    List<UserAccount> users = userAccountService.getAllUsers();

    if (users == null || users.isEmpty()) {
        return ResponseEntity.ok(Collections.singletonMap("message", "No users available."));
    }

    long total = users.size();

    users.sort(Comparator.comparing(UserAccount::getCreatedAt, Comparator.nullsLast(Comparator.naturalOrder())));

    List<ApplicationUsersResponse> responseList = users.stream()
            .map(user -> {
                // Get the department ID directly as Long
                Long departmentId = user.getDepartmentId();

                // Fetch the department name
                String departmentName = departmentRepository.findById(departmentId)
                        .map(Department::getName)
                        .orElse("Unknown");

                // Return the response object
                return new ApplicationUsersResponse(
                    user.getName() != null ? user.getName() : "Unknown",
                    user.getCreatedAt() != null ? user.getCreatedAt().toString() : "Unknown",
                    departmentName
                );
            })
            .collect(Collectors.toList());

    Map<String, Object> result = new HashMap<>();
    result.put("totalUsers", total);
    result.put("users", responseList);

    return ResponseEntity.ok(result);
}



@Operation(summary = "Get Number of Users per Agency", description = "Returns the count of users per agency.")
@ApiResponse(responseCode = "200", description = "Counts retrieved successfully")
@GetMapping("/users-per-agency")
@AuditTrail(recordType = "User", action = "Retrieve Percentage of Users per Agency", presentValue = "Percentage of users per agency retrieved")
public ResponseEntity<Map<String, Long>> getNumberOfUsersPerAgency() {
    List<UserAccount> users = userAccountService.getAllUsers();

    // Check for null or empty user list
    if (users == null || users.isEmpty()) {
        Map<String, Long> noUsersMap = new HashMap<>();
        noUsersMap.put("message", 0L);
        return ResponseEntity.ok(noUsersMap);
    }

    // Group users by position, filtering out null positions
    Map<String, Long> userCountByAgency = users.stream()
        .filter(user -> user.getPosition() != null) // Filter out users with null position
        .collect(Collectors.groupingBy(UserAccount::getPosition, Collectors.counting()));

    return ResponseEntity.ok(userCountByAgency);
}


@Operation(summary = "Get Number of Registered Departments", description = "Returns the count of active, cancelled, and total departments.")
@ApiResponse(responseCode = "200", description = "Counts retrieved successfully")
@GetMapping("/department-status")
@AuditTrail(recordType = "Department", action = "Retrieve Number of Registered Departments", presentValue = "Counts of active, cancelled, and total departments retrieved")
public ResponseEntity<Map<String, Long>> getNumberofRegisteredDepartments() throws ResourceNotFoundException {
List<DepartmentDTO> departments = departmentService.getAllDepartments();

if (departments == null || departments.isEmpty()) {
    Map<String, Long> emptyStats = new HashMap<>();
    emptyStats.put("active", 0L);
    emptyStats.put("cancelled", 0L);
    emptyStats.put("total", 0L);
    return ResponseEntity.ok(emptyStats);
}
long activeDepartments = departments.stream().filter(DepartmentDTO::getActive).count();
long nonActiveDepartments = departments.stream().filter(department -> !department.getActive()).count();
long totalDepartments = departments.size();
Map<String, Long> stats = new HashMap<>();
stats.put("active", activeDepartments);
stats.put("cancelled", nonActiveDepartments);
stats.put("total", totalDepartments);
return ResponseEntity.ok(stats);
}
@Operation(summary = "Get Agency Information", description = "Returns a list of agency names with their creation dates and status.")
    @ApiResponse(responseCode = "200", description = "Agency details retrieved successfully")
    @GetMapping("/agency-info")
    @AuditTrail(recordType = "Department", action = "Retrieve Agency Information", presentValue = "List of agency names with creation dates and status retrieved")
    public ResponseEntity<List<AgencyInfoResponse>> getAgencyInfo() throws ResourceNotFoundException {
        List<DepartmentDTO> departments = departmentService.getAllDepartments();

        if (departments == null || departments.isEmpty()) {
            return ResponseEntity.ok(Collections.singletonList(new AgencyInfoResponse("No agencies available", null, null)));
        }

        List<AgencyInfoResponse> responseList = departments.stream()
                .sorted(Comparator.comparing(
                        DepartmentDTO::getCreatedAt,
                        Comparator.nullsLast(Comparator.naturalOrder())
                ))
                .map(department -> new AgencyInfoResponse(
                        department.getName() != null ? department.getName() : "Unknown",
                        department.getCreatedAt() != null ? department.getCreatedAt().toString() : "Unknown",
                        department.getActive() != null ? department.getActive().toString() : "Unknown"
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(responseList);
    }
@Operation(summary = "Get Number of Registered Contractors", description = "Returns the count of active, cancelled, and total Contractors.")
@ApiResponse(responseCode = "200", description = "Counts retrieved successfully")
@GetMapping("/Contractors-status")
@AuditTrail(recordType = "Contractor", action = "Retrieve Number of Registered Contractors", presentValue = "Counts of active, cancelled, and total contractors retrieved")
 public ResponseEntity<Map<String,Long>> getNumberofRegisteredContractors(){
    List<CompanyResponse> company= companyAssociationService.getAllCompanies();
    if (company == null || company.isEmpty()) {
        Map<String, Long> emptyStats = new HashMap<>();
        emptyStats.put("active", 0L);
        emptyStats.put("cancelled", 0L);
        emptyStats.put("total", 0L);
        return ResponseEntity.ok(emptyStats);
    }
    long activecompany=company.stream().filter(CompanyResponse::isStatus).count();
    long cancelled=company.stream().filter(x->!x.isStatus()).count();
    long totalcontractors=company.size();
    Map<String, Long> stats = new HashMap<>();
stats.put("active", activecompany);
stats.put("cancelled", cancelled);
stats.put("total", totalcontractors);
return ResponseEntity.ok(stats);

 }
 @Operation(summary = "Get percentage of Users per Agency", description = "Returns the percentage of users per agency.")
@ApiResponse(responseCode = "200", description = "Counts retrieved successfully")
@GetMapping("/users-percentage-agency")
 @AuditTrail(recordType = "User", action = "Retrieve Percentage of Users per Agency", presentValue = "Percentage of users per agency retrieved")
public ResponseEntity<Map<String, Double>> getPercentageOfUsersPerAgency() {
    List<UserAccount> users = userAccountService.getAllUsers();

    long totalUsers = users.size();

    if (totalUsers == 0) {
        return ResponseEntity.ok(Collections.emptyMap());
    }

    Map<String, Long> userCountByAgency = users.stream()
        .filter(user -> user.getPosition() != null)
        .collect(Collectors.groupingBy(UserAccount::getPosition, Collectors.counting()));

    Map<String, Double> percentageByAgency = userCountByAgency.entrySet().stream()
        .collect(Collectors.toMap(
            Map.Entry::getKey,
            entry -> (entry.getValue() * 100.0) / totalUsers
        ));

    return ResponseEntity.ok(percentageByAgency);
}
}
