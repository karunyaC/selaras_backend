package com.selaras.api.service;

import com.selaras.api.dto.StateDTO;

import java.util.List;

public interface StateService {

    List<StateDTO> getStates();
}
