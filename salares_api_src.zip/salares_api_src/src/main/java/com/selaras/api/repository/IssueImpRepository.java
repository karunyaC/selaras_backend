package com.selaras.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.selaras.api.entity.IssueImpact;

public interface IssueImpRepository extends JpaRepository<IssueImpact, Long>, JpaSpecificationExecutor<IssueImpact> {
    
}
