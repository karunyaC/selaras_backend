package com.selaras.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.selaras.api.entity.RSCore;

@Repository
public interface RSCoreRepository extends JpaRepository<RSCore, Long>{
    
}
