package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.dto.UserAccountDTO;
import com.selaras.api.entity.Department;
import com.selaras.api.entity.UserAccount;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.service.UserAccountService;
import com.selaras.api.service.impl.UserAccountDeptDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserAccountController {

    private final UserAccountService userAccountService;

    @Operation(summary = "Get all users", description = "Returns list of users")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping()
    @AuditTrail(recordType = "User", action = "Retrieve All Users", presentValue = "Retrieved all users")
    public List<UserAccount> getAllUsers() {
        return userAccountService.getAllUsers();
    }

    @Operation(summary = "Get all users Department", description = "Returns list of users")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/getAllUserDept")
    @AuditTrail(recordType = "User", action = "Retrieve All Users", presentValue = "Retrieved all users")
    public List<UserAccountDeptDTO> getAllUsersdept() {
        return userAccountService.getAllUserDept();
    }

    @Operation(summary = "Create a new user", description = "Adds a new user to the system.")
    @ApiResponse(responseCode = "201", description = "User created successfully")
    @PostMapping
    @AuditTrail(recordType = "User", action = "Create User", previousValue = "", presentValue = "User created")
    public ResponseEntity<UserAccountDTO> addUser(@RequestBody @Valid UserAccountDTO userAccountDTO) {
        try {
            if (userAccountDTO == null) {
                throw new IllegalArgumentException("Request body is expected.");
            }
            UserAccountDTO createdUser = userAccountService.addUser(userAccountDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdUser);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create resource");
        }

    }

    @Operation(summary = "Update an existing user", description = "Updates the details of the user with the specified ID.")
    @ApiResponse(responseCode = "200", description = "User updated successfully")
    @PutMapping("/{id}")
    @AuditTrail(recordType = "User", action = "Update User", previousValue = "User details before update", presentValue = "User updated with ID")
    public ResponseEntity<UserAccountDTO> updateUser(@PathVariable Long id,
                                                     @RequestBody @Valid UserAccountDTO userAccountDTO) throws ResourceNotFoundException {
        UserAccountDTO updatedUser = userAccountService.updateUser(id, userAccountDTO);
        return ResponseEntity.ok(updatedUser);
    }

    @Operation(summary = "Delete a user", description = "Removes the user with the specified ID from the system.")
    @ApiResponse(responseCode = "204", description = "User deleted successfully")
    @DeleteMapping("/{id}")
    @AuditTrail(recordType = "User", action = "Delete User", presentValue = "User deleted with ID: {id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) throws ResourceNotFoundException {
        userAccountService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Retrieve details of a specific user", description = "Fetches details of the user with the specified ID.")
    @ApiResponse(responseCode = "200", description = "User details")
    @GetMapping("/{id}")
    @AuditTrail(recordType = "User", action = "Retrieve User Details", presentValue = "Retrieved details of user with ID")
    public ResponseEntity<UserAccountDTO> getUserDetails(@PathVariable Long id) throws ResourceNotFoundException {
        UserAccountDTO userAccountDTO = userAccountService.getUserDetails(id);
        return ResponseEntity.ok(userAccountDTO);
    }

    @Operation(summary = "Search users by name", description = "Searches for users by name with pagination.")
    @ApiResponse(responseCode = "200", description = "Search results retrieved successfully")
    @GetMapping("/search")
    @AuditTrail(recordType = "User", action = "Search Users by Name", presentValue = "Searched users by name")
    public ResponseEntity<Page<UserAccountDTO>> searchUsersByName(@RequestParam String name,
                                                                  @PageableDefault(size = 10, sort = "name") Pageable pageable) {
        Page<UserAccountDTO> usersPage = userAccountService.searchUsersByName(name, pageable);
        return ResponseEntity.ok(usersPage);
    }

    @Operation(summary = "Advanced search for users", description = "Searches for users based on multiple criteria with pagination.")
    @ApiResponse(responseCode = "200", description = "Search results retrieved successfully")
    @GetMapping("/allsearch")
    @AuditTrail(recordType = "User", action = "Advanced Search for Users", presentValue = "Retrieved users based on advanced search criteria")
    public Page<UserAccountDTO> getAllUsers(@RequestParam(required = false) String name,
                                            @RequestParam(required = false) String email, @RequestParam(required = false) Long domainId,
                                            @RequestParam(required = false) String kpNumber,
                                            @RequestParam(required = false) Boolean active, Pageable pageable) {

        UserAccount filter = new UserAccount();
        filter.setName(name);
        filter.setEmail(email);
        filter.setDomainId(domainId);
        filter.setActive(active);
        filter.setKpNumber(kpNumber);

        return userAccountService.getAllUsers(filter, pageable);
    }

    @Operation(summary = "Get all system users", description = "Get all system users")
    @ApiResponse(responseCode = "200", description = "Get all system usersy")
    @GetMapping("/system/users")
    @AuditTrail(recordType = "User", action = "Get all system users", presentValue = "Retrieved all system users")
    public ResponseEntity<List<UserAccountDTO>> getAllSystemUsers() {
        return ResponseEntity.ok().body(userAccountService.getAllSystemUsers());
    }

    @Operation(summary = "Save org chart user", description = "Save org chart user")
    @ApiResponse(responseCode = "200", description = "Save org chart user")
    @PostMapping("/org/users")
    @AuditTrail(recordType = "User", action = "Save org chart user", presentValue = "Save org chart user")
    public ResponseEntity<UserAccountDTO> saveOrgCharUser(@RequestBody UserAccountDTO userAccountDTO) {
        return ResponseEntity.ok().body(userAccountService.saveOrgUser(userAccountDTO));
    }
}
