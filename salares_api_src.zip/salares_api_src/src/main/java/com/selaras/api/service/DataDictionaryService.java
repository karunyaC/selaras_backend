package com.selaras.api.service;

import com.selaras.api.dto.DistrictStateAssemblyDTO;
import com.selaras.api.dto.KpiYearsDTO;
import com.selaras.api.dto.MeasuringUnitKpiDTO;
import com.selaras.api.dto.ProjectStartAndEndYearDTO;
import com.selaras.api.entity.ProjectCategory;
import com.selaras.api.entity.ProjectStatus;
import com.selaras.api.entity.StrategicPlan;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.requests.ProjectCategoryRequest;
import com.selaras.api.requests.ProjectStatusRequest;
import com.selaras.api.requests.ProjectStrategicPlanRequest;
import com.selaras.api.responses.ProjectCategoryResponse;
import com.selaras.api.responses.ProjectStatusResponse;
import com.selaras.api.responses.ProjectStrategicPlanResponse;

import java.util.List;

public interface DataDictionaryService {
    ProjectStatus saveProjectStatus(ProjectStatusRequest request) throws BadRequestException;

    List<ProjectStatusResponse> getAllProjectStatus();

    ProjectCategory saveProjectCategory(ProjectCategoryRequest request) throws BadRequestException;

    List<ProjectCategoryResponse> getAllProjectCategory();

    StrategicPlan saveProjectStrategicPlan(ProjectStrategicPlanRequest request) throws BadRequestException;

    List<ProjectStrategicPlanResponse> getAllProjectStrategicPlan();

    DistrictStateAssemblyDTO saveDistrictStateAssembly( DistrictStateAssemblyDTO request );

    List<DistrictStateAssemblyDTO> getDistrictStateAssembly();

    KpiYearsDTO saveKpiYears( KpiYearsDTO request );

    List<KpiYearsDTO> getKpiYears();

    ProjectStartAndEndYearDTO saveProjectYears( ProjectStartAndEndYearDTO request );

    List<ProjectStartAndEndYearDTO> getProjectYears();

    MeasuringUnitKpiDTO saveMeasuringUnit( MeasuringUnitKpiDTO request );

    List<MeasuringUnitKpiDTO> getMeasuringUnit();
}
