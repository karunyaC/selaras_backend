package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.dto.HeadBreakPkDTO;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.exception.ResourceNotFoundRunTimeException;
import com.selaras.api.service.HeadBreakPkService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/headbreakpk")
@RequiredArgsConstructor
public class HeadBreakPkController {

    private final HeadBreakPkService headBreakPkService;

    @Operation(summary = "Create a HeadBreakPk", description = "Creates a new HeadBreakPk entry")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "HeadBreakPk created successfully"),
            @ApiResponse(responseCode = "400", description = "Bad Request")
    })
    @PostMapping
    @AuditTrail(recordType = "HeadBreakPk", action = "Create HeadBreakPk", presentValue = "New HeadBreakPk created")
    public ResponseEntity<HeadBreakPkDTO> createHeadBreakPk(
            @Parameter(description = "Details of the HeadBreakPk to be created") 
            @RequestBody HeadBreakPkDTO headBreakPkDTO) throws ResourceNotFoundException {
        HeadBreakPkDTO savedDto = headBreakPkService.saveHeadBreakPk(headBreakPkDTO);
        return ResponseEntity.ok(savedDto);
    }

    @Operation(summary = "Update a HeadBreakPk", description = "Updates an existing HeadBreakPk entry by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "HeadBreakPk updated successfully"),
            @ApiResponse(responseCode = "404", description = "HeadBreakPk not found"),
            @ApiResponse(responseCode = "400", description = "Bad Request")
    })
    @PutMapping("/{id}")
    @AuditTrail(recordType = "HeadBreakPk", action = "Update HeadBreakPk", 
                previousValue = "Previous details of HeadBreakPk with ID: {id}", 
                presentValue = "HeadBreakPk details updated")
    public ResponseEntity<HeadBreakPkDTO> updateHeadBreakPk(
            @Parameter(description = "ID of the HeadBreakPk to be updated") 
            @PathVariable Long id, 
            @Parameter(description = "Updated details of the HeadBreakPk") 
            @RequestBody HeadBreakPkDTO headBreakPkDTO) throws ResourceNotFoundException {
        headBreakPkDTO.setId(id);
        HeadBreakPkDTO updatedDto = headBreakPkService.updateHeadBreak(headBreakPkDTO);
        return updatedDto != null ? ResponseEntity.ok(updatedDto) : ResponseEntity.notFound().build();
    }

    @Operation(summary = "Get HeadBreakPk by Department ID", description = "Retrieves a list of HeadBreakPk by department ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "HeadBreakPk retrieved successfully"),
            @ApiResponse(responseCode = "404", description = "HeadBreakPk not found")
    })
    @GetMapping("getpkdeptbyid/{id}")
    @AuditTrail(recordType = "HeadBreakPk", action = "Retrieve HeadBreakPk by Department ID", presentValue = "HeadBreakPk retrieved by department ID")
    public ResponseEntity<List<HeadBreakPkDTO>> getHeadBreakPkById(
            @Parameter(description = "ID of the department to retrieve HeadBreakPk") 
            @PathVariable Long id) {
        try {
            List<HeadBreakPkDTO> dto = headBreakPkService.getdepartmentBreakPkbyid(id);
            return ResponseEntity.ok(dto);
        } catch (ResourceNotFoundRunTimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "Get all HeadBreakPk", description = "Retrieves all HeadBreakPk entries")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "List of HeadBreakPk retrieved successfully")
    })
    @GetMapping
    @AuditTrail(recordType = "HeadBreakPk", action = "Retrieve All HeadBreakPk", presentValue = "All HeadBreakPk retrieved")
    public ResponseEntity<List<HeadBreakPkDTO>> getAllHeadBreakPk() {
        List<HeadBreakPkDTO> headBreakPkList = headBreakPkService.getAllHeadBreakPk();
        return ResponseEntity.ok(headBreakPkList);
    }

    @Operation(summary = "Delete HeadBreakPk", description = "Deletes HeadBreakPk entries by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "HeadBreakPk deleted successfully"),
            @ApiResponse(responseCode = "404", description = "HeadBreakPk not found"),
            @ApiResponse(responseCode = "400", description = "Bad Request")
    })
    @DeleteMapping("/{id}")
    @AuditTrail(recordType = "HeadBreakPk", action = "Delete HeadBreakPk", presentValue = "HeadBreakPk entries deleted")
    public ResponseEntity<List<HeadBreakPkDTO>> deleteHeadBreakPk(
            @Parameter(description = "Array of IDs of HeadBreakPk to be deleted") 
            @PathVariable Long[] id) throws ResourceNotFoundException {
        return ResponseEntity.ok(headBreakPkService.deleteHeadBreakPk(id));
    }
}
