package com.selaras.api.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "sp_core")
public class SPCore {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer rowId;

    @ManyToOne
    @JoinColumn(name = "sp_code", referencedColumnName = "spCode")
    private SPOverview spOverview;

    private String spPlanCode;

    @Column(unique = true, nullable = false)
    private String spCoreId;

    private String spCorePreferredName;
    private String spCorePreferredCode;
    private LocalDateTime createdAt;
    private LocalDateTime modifiedAt;

    @OneToMany(mappedBy = "spCore", cascade = CascadeType.ALL)
    private List<SPStrategy> strategies;

}
