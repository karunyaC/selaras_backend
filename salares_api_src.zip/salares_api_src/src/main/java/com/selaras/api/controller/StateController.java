package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.dto.StateDTO;
import com.selaras.api.service.StateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/api/state")
@RequiredArgsConstructor
public class StateController {

    private  final StateService stateService;

    @GetMapping("/getAll")
    @AuditTrail(recordType = "State", action = "Retrieve States",presentValue = "Retrieved all states")
    public ResponseEntity<List<StateDTO>> getStates() {
        List<StateDTO> states = stateService.getStates();
        return new ResponseEntity<>(states, HttpStatus.OK);
    }

}
