package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.entity.Company;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.requests.CompanySaveRequest;
import com.selaras.api.responses.CompanyResponse;
import com.selaras.api.service.CompanyAssociationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class CompanyAssociationController {

    private final CompanyAssociationService companyAssociationService;

    @Operation(summary = "Save company or association", description = "Save company or association")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/company")
    @AuditTrail(recordType = "Company", action = "Save Company or Association", presentValue = "Company or association details saved")
    public ResponseEntity<?> saveCompany(@RequestBody CompanySaveRequest request) throws BadRequestException {
        return ResponseEntity.ok().body(companyAssociationService.saveCompany(request));
    }

    @Operation(summary = "Get Company details", description = "Get Company or association details")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/company")
    @AuditTrail(recordType = "Company", action = "Retrieve All Companies or Associations", presentValue = "All company or association details retrieved")
    public ResponseEntity<?> getAllCompanies() {
        return ResponseEntity.ok().body(companyAssociationService.getAllCompanies());
    }
    @Operation(summary = "Update company or association", description = "Update existing company or association by ID")
    @ApiResponse(responseCode = "200", description = "OK")
    @PutMapping("/company/{id}")
    @AuditTrail(recordType = "Company", action = "Update Company or Association",previousValue = "Previous company or association details: {previousValue}", presentValue = "Company or association details updated")
    public ResponseEntity<?> updateCompany(@PathVariable Long id, @RequestBody CompanySaveRequest request) throws BadRequestException {
        return ResponseEntity.ok().body(companyAssociationService.updateCompany(id, request));
    }
    @Operation(summary = "Get Company by name or ID", description = "Retrieve company details by name or ID")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/company/search")
    @AuditTrail(recordType = "Company", action = "Retrieve Company by Name or ID", presentValue = "Company details retrieved by name or ID")
    public ResponseEntity<CompanyResponse> getCompanyByNameOrId(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) Long id) throws BadRequestException {
        CompanyResponse response = companyAssociationService.getCompanyByNameOrId(name, id);
        return ResponseEntity.ok().body(response);
    }
    @Operation(summary = "Delete companies", description = "Mark companies as inactive by IDs")
    @ApiResponse(responseCode = "200", description = "Companies updated successfully")
    @DeleteMapping("/company")
    @AuditTrail(recordType = "Company", action = "Delete Companies", presentValue = "Selected companies marked as inactive")
    public ResponseEntity<List<CompanyResponse>> deleteCompanies(@RequestParam Long[] ids)throws BadRequestException  {
        List<CompanyResponse> deletedCompanies = companyAssociationService.DelectCompanies(ids);
        return ResponseEntity.ok(deletedCompanies);
    }
    @Operation(summary = "Get Company details", description = "Get Company or association details")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/companyfilter")
    @AuditTrail(recordType = "Company", action = "Retrieve Companies by Active Status", presentValue = "Companies retrieved based on active status filter")
    public ResponseEntity<?> getAllCompanies(@RequestParam(required = false) Boolean active) {
        return ResponseEntity.ok().body(companyAssociationService.findByActive(active));
    }

}
