package com.selaras.api.service.impl;

import com.selaras.api.dto.FaqDTO;
import com.selaras.api.entity.ArticleCategory;
import com.selaras.api.entity.Faq;
import com.selaras.api.entity.FaqArticleSubCategory;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.repository.ArticleCategoryRepository;
import com.selaras.api.repository.FaqArticleSubCategoryRepository;
import com.selaras.api.repository.FaqRepository;
import com.selaras.api.requests.FaqRequest;
import com.selaras.api.responses.FaqResponse;
import com.selaras.api.responses.SubCategoryResponse;
import com.selaras.api.service.FaqService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FaqServiceImpl implements FaqService {


   private final FaqRepository faqRepository;

   private final FaqArticleSubCategoryRepository faqArticleSubCategoryRepository;


   private final ArticleCategoryRepository articleCategoryRepository;


   private final ModelMapper modelMapper;

    @Override
    @Transactional
    public String createOrUpdateFaq(FaqRequest faqRequest) throws BadRequestException {
        // Fetch the category by ID, or create and save a new one if not found
        ArticleCategory category = articleCategoryRepository.findById(faqRequest.getArticleCategoryId()).
                orElseThrow(() -> new BadRequestException("Category not found"));
                /*.orElseGet(() -> {
                    ArticleCategory newCategory = new ArticleCategory();
                    newCategory.setName(faqRequest.getArticleTitle()); // Set a default name or retrieve it from the request
                    newCategory.setCreatedAt(LocalDateTime.now());
                    newCategory.setCreatedBy(1);
                    newCategory.setSubCategories(faqRequest.get);// Set the creator's ID (replace 1 with the actual user ID)
                    // Save the new category to ensure it has an ID
                    return articleCategoryRepository.save(newCategory);
                });*/

        // Now that the category is saved, it has a valid ID, so we can safely proceed

        // Check if an FAQ with the same title and category ID already exists
        Optional<Faq> existingFaq = faqRepository.findByTitleAndArticleCategoryId(
                faqRequest.getArticleTitle(), category.getId());

        Faq faq;
        if (existingFaq.isPresent()) {
            // Update existing FAQ
            faq = existingFaq.get();
            faq.setSummary(faqRequest.getArticleSummary());
            faq.setContent(faqRequest.getArticleDescription());
            faq.setModifiedAt(LocalDateTime.now());
            faq.setModifiedBy(1);
        } else {
            // Create new FAQ
            faq = new Faq();
            faq.setTitle(faqRequest.getArticleTitle());
            faq.setSummary(faqRequest.getArticleSummary());
            faq.setArticleCategory(category);
            faq.setContent(faqRequest.getArticleDescription());
            faq.setCreatedAt(LocalDateTime.now());
            faq.setCreatedBy(1);
            faq.setModifiedBy(1);
        }

        // Save the FAQ entity
        faqRepository.save(faq);

        // Return a success message or the ID of the saved FAQ
        return existingFaq.isPresent() ? "FAQ updated successfully" : "FAQ created successfully";
    }

    @Override
    public List<FaqResponse> getAllFaqCategories() {
        List<ArticleCategory> categories = articleCategoryRepository.findAll();

        return categories.stream().map(category -> {
            FaqResponse response = new FaqResponse();
            response.setCategoryId(category.getId());
            response.setCategory(category.getName());

            List<FaqArticleSubCategory> subCategories = faqArticleSubCategoryRepository.findByCategoryId(category.getId());

            List<SubCategoryResponse> subCategoryResponses = subCategories.stream()
                    .map(subCategory -> {
                        SubCategoryResponse subCategoryResponse = new SubCategoryResponse();
                        subCategoryResponse.setSubCategoryId(subCategory.getId());
                        subCategoryResponse.setSubcategory(subCategory.getName());
                        return subCategoryResponse;
                    }).collect(Collectors.toList());

            // Set the subcategories, use an empty list if there are none
            response.setSubcategories(subCategoryResponses.isEmpty() ? null : subCategoryResponses);

            return response;
        }).collect(Collectors.toList());
    }

    @Override
    public List<FaqDTO> getAllFaqs() {

        List<Faq> faqs = faqRepository.findAll();

        return faqs
                .stream()
                .map(faq -> modelMapper.map(faq, FaqDTO.class))
                .collect(Collectors.toList());
    }
}
