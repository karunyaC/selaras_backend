package com.selaras.api.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "dsp_strategy")
public class DSPStrategy {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rowId;

    @Column(unique = true, nullable = false)
    private String code;

    @Column(columnDefinition = "text")
    private String planCode;
    
    @Column(columnDefinition = "text")
    private String coreId;
    
    @Column(columnDefinition = "text", unique = true)
    private String stratId;
    
    @Column(columnDefinition = "text")
    private String stratPreferredName;
    
    @Column(columnDefinition = "text")
    private String stratPreferredCode;


    @CreationTimestamp
    private Timestamp createdAt;

    @UpdateTimestamp
    private Timestamp modifiedAt;
    
}
