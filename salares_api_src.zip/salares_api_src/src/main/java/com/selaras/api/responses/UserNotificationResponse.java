package com.selaras.api.responses;

import com.selaras.api.entity.PromotionCategory;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserNotificationResponse {
   private Long id;
   private List<AnnouncementToResponse> announcementTo;
   private String description;
   private List<PlatformResponse> platform;
   private String promotionScheduling;
   private String promotionTitle;
   private PromotionCategoryResponse promotionCategory;
   private String status;
}
