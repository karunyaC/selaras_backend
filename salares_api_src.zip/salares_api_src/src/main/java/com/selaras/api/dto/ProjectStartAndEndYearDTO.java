package com.selaras.api.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class ProjectStartAndEndYearDTO {

    private Long id;
    private String code;
    private List< LocalDateTime > startYears;
    private List< LocalDateTime > endYears;
    private Boolean active;
    private String createdBy;
    private LocalDateTime createdAt;
    private String modifiedBy;
    private LocalDateTime modifiedAt;
}
