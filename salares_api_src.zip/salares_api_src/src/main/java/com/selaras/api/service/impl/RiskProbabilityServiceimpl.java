package com.selaras.api.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.selaras.api.dto.RiskProbDTO;
import com.selaras.api.entity.RiskProb;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.RiskProbRepository;
import com.selaras.api.service.RiskProbabilityService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RiskProbabilityServiceimpl implements RiskProbabilityService {

    private final RiskProbRepository riskProbRepository;

    private final ModelMapper modelMapper;   

    @Override
    public RiskProbDTO createRiskProb(RiskProbDTO riskProbDTO) {
        System.out.println("DTO Before Mapping: " + riskProbDTO);
        
        RiskProb risk = modelMapper.map(riskProbDTO, RiskProb.class);
        
        System.out.println("Entity Before Saving: " + risk);
        
        RiskProb savedRiskProb = riskProbRepository.save(risk);
        return modelMapper.map(savedRiskProb, RiskProbDTO.class);
    }
    

    

    @Override
    public RiskProbDTO getById(long id) throws ResourceNotFoundException{
        RiskProb riskProb=riskProbRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("No rule found with the given id"));
        RiskProbDTO riskProbDTO=modelMapper.map(riskProb, RiskProbDTO.class);
        return riskProbDTO;
    }

  


@Override
public List<RiskProbDTO> getall() {
    List<RiskProb> riskProbs = riskProbRepository.findAll();

    if (riskProbs.isEmpty()) {
        try {
            throw new ResourceNotFoundException("No Risk Probability records found");
        } catch (ResourceNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    List<RiskProbDTO> riskProbDTOs = new ArrayList<>();
    for (RiskProb riskProb : riskProbs) {
        RiskProbDTO riskProbDTO = modelMapper.map(riskProb, RiskProbDTO.class);
        riskProbDTOs.add(riskProbDTO);
    }
    return riskProbDTOs;
}


   @Override
public RiskProbDTO updateRiskProb(long id, RiskProbDTO riskProbDTO) throws ResourceNotFoundException {
    RiskProb riskProb = riskProbRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("No Risk Probability found with the given id: " + id));
    
    riskProb.setRiskProbCode(riskProbDTO.getRiskProbCode());
    riskProb.setRiskProbability(riskProbDTO.getRiskProbability());
    riskProb.setIsActive(riskProbDTO.getIsActive());
    riskProb.setModifiedBy(riskProbDTO.getModifiedBy()); // Assuming this field exists in the DTO
    riskProb.setModifiedAt(LocalDateTime.now()); // Set the current timestamp for the modified date

    RiskProb updatedRiskProb = riskProbRepository.save(riskProb);
    
    return modelMapper.map(updatedRiskProb, RiskProbDTO.class);
}


@Override
public String deleteRiskProbability(long id) throws ResourceNotFoundException {
    RiskProb riskProb = riskProbRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("No Risk Probability found with the given id: " + id));

    riskProb.setIsActive(false);
    riskProb.setModifiedAt(LocalDateTime.now());
    riskProbRepository.save(riskProb);
    return "Risk Probability with id " + id + " has been successfully deactivated.";
}






    
}
