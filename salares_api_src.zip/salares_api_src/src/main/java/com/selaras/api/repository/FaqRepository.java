package com.selaras.api.repository;

import com.selaras.api.entity.Faq;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FaqRepository extends JpaRepository<Faq,Integer> {
   // @Query(nativeQuery = true,value = "select * from public.faq f  where f.title = :title and article_category_id = :articleCategoryId;")
    Optional<Faq> findByTitleAndArticleCategoryId(String title, Integer articleCategoryId);

}
