package com.selaras.api.dto;


import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class RmkDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;

    private String code;

    private String objective;

    private LocalDateTime startYear;

    private LocalDateTime endYear;

    private BigDecimal overallBudget;

    private Boolean active;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;

}
