package com.selaras.api.dto;


import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class RoleAccessLevelDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;

    private Long roleId;

    private Long accessLevelId;

    private LocalDateTime createdAt;

    private String createdBy;

    private String modifiedBy;

    private LocalDateTime modifiedAt;

}
