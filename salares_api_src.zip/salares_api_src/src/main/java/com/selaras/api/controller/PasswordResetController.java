package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.service.ResetPasswordService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class PasswordResetController {

    
    private final ResetPasswordService resetPasswordService;

    @Operation(summary = "Send reset token", description = "Send email with reset link")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/forgotpassword")
    @AuditTrail(recordType = "User", action = "Send Reset Token", presentValue = "Reset token sent to email")
    public ResponseEntity<?> forgotPassword(@RequestParam("email") String email, HttpServletRequest request) {
        return ResponseEntity.ok().body(resetPasswordService.generateResetToken(email, request));
    }

    @Operation(summary = "Reset password", description = "Validate reset token and reset password")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/resetpassword")
    @AuditTrail(recordType = "User", action = "Reset Password", presentValue = "Password reset for token")
    public ResponseEntity<String> resetPassword(@RequestParam("token") String token, @RequestParam("password") String password) {
        return ResponseEntity.ok().body(resetPasswordService.resetPassword(token, password));
    }
}
