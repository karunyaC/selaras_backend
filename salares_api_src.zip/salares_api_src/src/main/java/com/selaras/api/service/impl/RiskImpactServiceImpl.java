package com.selaras.api.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.selaras.api.dto.RiskImpactDTO;
import com.selaras.api.entity.RiskImpact;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.RiskImpRepository;
import com.selaras.api.service.RiskImpactService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RiskImpactServiceImpl implements RiskImpactService {

    private final RiskImpRepository riskImpRepository;
    private final ModelMapper modelMapper;

    @Override
    @Transactional
    public RiskImpactDTO createRiskImpact(RiskImpactDTO riskProbDTO) throws BadRequestException {
        if (riskProbDTO.getRiskImpCode() == null || riskProbDTO.getRiskImpCode().isEmpty()) {
            throw new BadRequestException("Risk impact code cannot be null or empty");
        }

        // Map DTO to Entity
        RiskImpact riskImpact = modelMapper.map(riskProbDTO, RiskImpact.class);
        riskImpact.setCreatedAt(LocalDateTime.now());
        riskImpact.setModifiedAt(LocalDateTime.now());

        // Save to the database
        RiskImpact savedRiskImpact = riskImpRepository.save(riskImpact);
        return modelMapper.map(savedRiskImpact, RiskImpactDTO.class);
    }

    @Override
    public RiskImpactDTO getById(long id) throws ResourceNotFoundException {
        RiskImpact riskImpact = riskImpRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RiskImpact not found with id: " + id));
        return modelMapper.map(riskImpact, RiskImpactDTO.class);
    }

    @Override
    @Transactional
    public RiskImpactDTO updateRiskImpact(long id, RiskImpactDTO riskProbDTO) throws ResourceNotFoundException {
        RiskImpact existingRiskImpact = riskImpRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RiskImpact not found with id: " + id));

        // Update fields
        existingRiskImpact.setRiskImpCode(riskProbDTO.getRiskImpCode());
        existingRiskImpact.setRiskImpact(riskProbDTO.getRiskImpact());
        existingRiskImpact.setIsActive(riskProbDTO.getIsactive());
        existingRiskImpact.setModifiedAt(LocalDateTime.now());
        existingRiskImpact.setModifiedBy(riskProbDTO.getModifiedBy());

        // Save updated entity
        RiskImpact updatedRiskImpact = riskImpRepository.save(existingRiskImpact);
        return modelMapper.map(updatedRiskImpact, RiskImpactDTO.class);
    }

    @Override
    @Transactional
    public String deleteRiskImpact(long id) throws ResourceNotFoundException {
        RiskImpact existingRiskImpact = riskImpRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RiskImpact not found with id: " + id));

        // Optional: Mark as inactive instead of deleting
        existingRiskImpact.setIsActive(false);
        riskImpRepository.save(existingRiskImpact);

        // Or uncomment the following line to delete it completely
        // riskImpRepository.delete(existingRiskImpact);

        return "RiskImpact with id " + id + " has been marked as inactive.";
    }

    @Override
    public List<RiskImpactDTO> getall() {
        List<RiskImpact> riskImpacts = riskImpRepository.findAll();
        return riskImpacts.stream()
                .map(riskImpact -> modelMapper.map(riskImpact, RiskImpactDTO.class))
                .toList();
    }
}
