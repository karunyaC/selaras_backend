package com.selaras.api.repository;

import com.selaras.api.entity.ProjectStartAndEndYear;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectStartAndEndYearRepository extends JpaRepository< ProjectStartAndEndYear,Long > {
}
