package com.selaras.api.service;

import com.selaras.api.entity.Company;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.requests.CompanySaveRequest;
import com.selaras.api.responses.CompanyResponse;

import java.util.List;

public interface CompanyAssociationService {
    String saveCompany(CompanySaveRequest request) throws BadRequestException;

    List<CompanyResponse> getAllCompanies();

    String updateCompany(Long companyId, CompanySaveRequest request) throws BadRequestException;

    CompanyResponse getCompanyByNameOrId(String name, Long id) throws BadRequestException;

    List<CompanyResponse> DelectCompanies(Long[] ids) throws BadRequestException;

    List<CompanyResponse> findByActive(Boolean active);

}
