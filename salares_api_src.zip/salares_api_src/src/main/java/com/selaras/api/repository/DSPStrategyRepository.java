package com.selaras.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.selaras.api.entity.DSPStrategy;

import java.util.List;

public interface DSPStrategyRepository extends JpaRepository<DSPStrategy, Long> {

    DSPStrategy findByStratPreferredName(String strategyName);

    List<DSPStrategy> findByCoreId(String coreId);

    List<DSPStrategy> findByPlanCode(String planCode);
}
