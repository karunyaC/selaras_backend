package com.selaras.api.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HelpdeskFileResponse {
    private Integer id;
    private String filePath;
    private String createdBy;
    private LocalDateTime createdAt;
}
