package com.selaras.api.repository;

import com.selaras.api.entity.PromotionCategory;
import com.selaras.api.entity.UserNotificationSettings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.time.LocalDateTime;

public interface UserNotificationSettingsRepository extends JpaRepository<UserNotificationSettings, Long>, JpaSpecificationExecutor<UserNotificationSettings> {

    UserNotificationSettings findByPromotionTitleAndPromotionCategoryAndDescriptionAndPlatformAndAnnouncementToAndPromotionScheduling(
            String promotionTitle,
            PromotionCategory promotionCategory,
            String description,
            String platform,
            String announcementTo,
            LocalDateTime promotionScheduling
    );

}