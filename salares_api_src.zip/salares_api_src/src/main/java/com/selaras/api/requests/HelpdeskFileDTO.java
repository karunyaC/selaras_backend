package com.selaras.api.requests;

import lombok.Data;

@Data
public class HelpdeskFileDTO {
    private String filePath;
    private String createdBy;
}
