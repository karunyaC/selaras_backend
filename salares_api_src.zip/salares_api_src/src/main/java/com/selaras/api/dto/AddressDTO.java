package com.selaras.api.dto;


import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class AddressDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;

    private String addressLineNumber1;

    private String addressLineNumber2;

    private String city;

    private String postalCode;

    private Long stateId;

    private String websiteUrl;

    private Boolean active;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;

    private Long addressTypeId;

}
