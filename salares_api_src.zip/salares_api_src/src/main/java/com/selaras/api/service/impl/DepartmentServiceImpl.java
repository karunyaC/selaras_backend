package com.selaras.api.service.impl;

import com.selaras.api.dto.DepartmensUsersRoleDTO;
import com.selaras.api.dto.DepartmentAddressUsersDTO;
import com.selaras.api.dto.DepartmentDTO;
import com.selaras.api.dto.ProjectDTO;
import com.selaras.api.dto.UsersDTO;
import com.selaras.api.entity.*;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.AddressRepository;
import com.selaras.api.repository.DepartmentProjectRepository;
import com.selaras.api.repository.DepartmentRepository;
import com.selaras.api.repository.ProjectRepository;
import com.selaras.api.repository.RoleAccessLevelRepository;
import com.selaras.api.repository.RoleRepository;
import com.selaras.api.repository.StateRepository;
import com.selaras.api.repository.UserAccountRepository;
import com.selaras.api.repository.UserRoleRepository;
import com.selaras.api.responses.DepartmentsResponse;
import com.selaras.api.service.DepartmentService;

import lombok.RequiredArgsConstructor;

import org.jetbrains.annotations.NotNull;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DepartmentServiceImpl  implements DepartmentService{

	 private final DepartmentRepository departmentRepository;
	 private  final ModelMapper modelMapper;
	 private final  ProjectRepository projectRepository;
	 private final  DepartmentProjectRepository departmentProjectRepository;
	 private final UserAccountRepository userAccountRepository;
	 private final StateRepository stateRepository;
	 private final AddressRepository addressRepository;
	 private final UserRoleRepository userRoleRepository;
	 private final RoleRepository roleRepository;
	@Override
	public DepartmentsResponse getDepartmentByName(int pageNo, int pageSize, String sortBy, String orderBy,
			String name) throws ResourceNotFoundException {
		
		 Sort sort = orderBy.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending()
	                : Sort.by(sortBy).descending();
		 Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
		 
		 Page<Department> pages = departmentRepository.findAll(pageable);
		 if(pages.isEmpty() || pages.getContent().isEmpty()) {
			 throw new ResourceNotFoundException("Departments not found by "+name);
		 }
		 
		 List<DepartmentDTO> departments=pages.getContent().stream().map(department->modelMapper.map(department,DepartmentDTO.class)).collect(Collectors.toList());
		 return DepartmentsResponse.builder()
				 .departments(departments)
				 .pageNo(pageNo)
				 .pageSize(pageSize)
				 .last(pages.isLast())
				 .build();
		 
	}

	// @Override
	// public DepartmentDTO createDepartment(DepartmentDTO departmentDTO) {
	// 	Department department=departmentRepository.save(modelMapper.map(departmentDTO, Department.class));
    //     return modelMapper.map(department,DepartmentDTO.class);
	// }
@Override
	public List<DepartmensUsersRoleDTO> getallDepartmensUsersRoleDTO(Long departmentId) throws ResourceNotFoundException {
		List<UserAccount> userAccounts = userAccountRepository.findByDepartmentId(departmentId);
	
		List<DepartmensUsersRoleDTO> departmentsUsersRoleDTOList = new ArrayList<>();
	
		for (UserAccount userAccount : userAccounts) {
			List<UserRole> userRoles = userRoleRepository.findByUserId(userAccount.getId());
	
			List<String> roleNames = userRoles.stream().map(UserRole::getRole).map(Role::getName).collect(Collectors.toList());
	
			DepartmensUsersRoleDTO dto = new DepartmensUsersRoleDTO();
			dto.setUser_name(userAccount.getName());
			dto.setId(userAccount.getId());
			dto.setActive(userAccount.getActive());
			dto.setUser_groups(roleNames);
			dto.setLastModified(userAccount.getModifiedAt());
			departmentsUsersRoleDTOList.add(dto);
		}
	
		return departmentsUsersRoleDTOList;
	}



    @Override
    public DepartmentAddressUsersDTO createDepartment(DepartmentAddressUsersDTO departmentDTO) {
        Address address = new Address();
        address.setAddressLineNumber1(departmentDTO.getAddressLineNumber1());
        address.setAddressLineNumber2(departmentDTO.getAddressLineNumber2());
        address.setCity(departmentDTO.getCity());
        address.setPostalCode(departmentDTO.getPostalCode());
        address.setState(stateRepository.findById(departmentDTO.getStateId()).orElse(null));

        Address savedAddress = addressRepository.save(address);
        Department department = new Department();
        department.setName(departmentDTO.getName());
        department.setFunction(departmentDTO.getFunction());
        department.setAddress(savedAddress);
        department.setVote(departmentDTO.getVote().intValue());
        department.setVoteCode(departmentDTO.getVoteCode());
        department.setActive(departmentDTO.getActive());
        department.setCreatedBy(departmentDTO.getCreatedBy());
        department.setCreatedAt(departmentDTO.getCreatedAt());
        department.setModifiedBy(departmentDTO.getModifiedBy());
        department.setModifiedAt(departmentDTO.getModifiedAt());
		department.setAgency_code(departmentDTO.getAgency_code()); 
		department.setWebsite_url(departmentDTO.getWebsite_url());

        Department savedDepartment = departmentRepository.save(department);

        DepartmentAddressUsersDTO savedDTO = new DepartmentAddressUsersDTO();
        savedDTO.setId(Long.valueOf(savedDepartment.getId()));
		savedDTO.setWebsite_url(savedDepartment.getWebsite_url());
		savedDTO.setAgency_code(savedDepartment.getAgency_code());
		savedDTO.setAddressId(Long.valueOf(savedDepartment.getAddress().getId()));
        savedDTO.setName(savedDepartment.getName());
        savedDTO.setFunction(savedDepartment.getFunction());
        savedDTO.setVote(Long.valueOf(savedDepartment.getVote()));
        savedDTO.setVoteCode(savedDepartment.getVoteCode());
        savedDTO.setActive(savedDepartment.getActive());
        savedDTO.setCreatedBy(savedDepartment.getCreatedBy());
        savedDTO.setCreatedAt(savedDepartment.getCreatedAt());
        savedDTO.setModifiedBy(savedDepartment.getModifiedBy());
        savedDTO.setModifiedAt(savedDepartment.getModifiedAt());
        savedDTO.setAddressLineNumber1(savedAddress.getAddressLineNumber1());
        savedDTO.setAddressLineNumber2(savedAddress.getAddressLineNumber2());
        savedDTO.setCity(savedAddress.getCity());
        savedDTO.setPostalCode(savedAddress.getPostalCode());
        savedDTO.setStateId(savedAddress.getState().getId());

        return savedDTO;
    }
	@Override
	public DepartmentDTO getDepartmentById(Long id) throws ResourceNotFoundException {
		Optional<Department> department =departmentRepository.findById(id);
		if(department.isEmpty()) {
			throw new ResourceNotFoundException("Departments not found by Id: "+id);
		}
		return modelMapper.map(department.get(), DepartmentDTO.class);
	}

	@Override
	public DepartmentDTO updateDepartment(DepartmentDTO departmentDTO, Long id) throws ResourceNotFoundException, BadRequestException {
		Optional<Department> department =departmentRepository.findById(departmentDTO.getId());

		if(id != departmentDTO.getId()) {
			throw new BadRequestException("Invalid Department details provided");
		}
		if(department.isEmpty()) {
			throw new ResourceNotFoundException("DepartmentId id Invalid to update Department");
		}

		if(!departmentDTO.getAddressId().equals(Long.valueOf(department.get().getAddress().getId()))) {
			throw new BadRequestException("Invalid address details in the request");
		}

		department.get().setName(departmentDTO.getName());
		department.get().setFunction(departmentDTO.getFunction());
		department.get().setVote(departmentDTO.getVote().intValue());
		department.get().setVoteCode(departmentDTO.getVoteCode());
		department.get().setActive(departmentDTO.getActive());
		department.get().setCreatedBy(departmentDTO.getCreatedBy());
		department.get().setCreatedAt(departmentDTO.getCreatedAt());
		department.get().setModifiedBy(departmentDTO.getModifiedBy());
		department.get().setModifiedAt(departmentDTO.getModifiedAt());
		department.get().getAddress().setAddressLineNumber1(departmentDTO.getAddressLineNumber1());
		department.get().getAddress().setAddressLineNumber2(departmentDTO.getAddressLineNumber2());
		department.get().getAddress().setCity(departmentDTO.getCity());
		department.get().getAddress().setPostalCode(departmentDTO.getPostalCode());
		State state = stateRepository.findById(Long.valueOf(departmentDTO.getStateId())).orElse(null);
		department.get().getAddress().setState(state);
		department.get().setAgency_code(departmentDTO.getAgencyCode());
		department.get().setWebsite_url(departmentDTO.getWebsiteUrl());

		Department updateDepartment = departmentRepository.save(department.get());

		DepartmentDTO dto = getDepartmentDTOAfterSaveOrUpdate(updateDepartment);

		return dto;
	}

	@NotNull
	private static DepartmentDTO getDepartmentDTOAfterSaveOrUpdate(Department updateDepartment) {
		DepartmentDTO dto = new DepartmentDTO();
		dto.setId(Long.valueOf(updateDepartment.getId()));
		dto.setName(updateDepartment.getName());
		dto.setFunction(updateDepartment.getFunction());
		dto.setAddressId(Long.valueOf(updateDepartment.getAddress().getId()));
		dto.setVote(Long.valueOf(updateDepartment.getVote()));
		dto.setVoteCode(updateDepartment.getVoteCode());
		dto.setActive(updateDepartment.getActive());
		dto.setCreatedBy(updateDepartment.getCreatedBy());
		dto.setCreatedAt(updateDepartment.getCreatedAt());
		dto.setModifiedBy(updateDepartment.getModifiedBy());
		dto.setModifiedAt(updateDepartment.getModifiedAt());
		dto.setAddressLineNumber1(updateDepartment.getAddress().getAddressLineNumber1());
		dto.setAddressLineNumber2(updateDepartment.getAddress().getAddressLineNumber2());
		dto.setCity(updateDepartment.getAddress().getCity());
		dto.setPostalCode(updateDepartment.getAddress().getPostalCode());
		dto.setStateId(updateDepartment.getAddress().getState().getId().intValue());
		dto.setAgencyCode(updateDepartment.getAgency_code());
		dto.setWebsiteUrl(updateDepartment.getWebsite_url());
		return dto;
	}
	@Override
	public List<DepartmentDTO> deleteDepartment(Long[] ids) throws ResourceNotFoundException {
		List<DepartmentDTO> deletedDepartments = new ArrayList<>();
	
		for (Long id : ids) {
			Optional<Department> departmentOptional = departmentRepository.findById(id);
			if (departmentOptional.isPresent()) {
				Department department = departmentOptional.get();
				department.setActive(false);
				Department savedDepartment = departmentRepository.save(department);
	
				// Convert the saved Department entity to a DepartmentDTO
				DepartmentDTO departmentDTO = new DepartmentDTO();
				departmentDTO.setId(Long.valueOf(savedDepartment.getId()));
				departmentDTO.setName(savedDepartment.getName());
				departmentDTO.setFunction(savedDepartment.getFunction());
				departmentDTO.setActive(savedDepartment.getActive());
				departmentDTO.setCreatedBy(savedDepartment.getCreatedBy());
				departmentDTO.setCreatedAt(savedDepartment.getCreatedAt());
				departmentDTO.setModifiedBy(savedDepartment.getModifiedBy());
				departmentDTO.setModifiedAt(savedDepartment.getModifiedAt());
	
				deletedDepartments.add(departmentDTO);
			} else {
				throw new ResourceNotFoundException("Department not found with ID: " + id);
			}
		}
	
		return deletedDepartments;
	}
	

	@Override
	public ProjectDTO addProjcetToDepartment(Long id, ProjectDTO projectDTOReq) throws ResourceNotFoundException {
		Optional<Department> department =departmentRepository.findById(id);
		if(department.isEmpty()) {
			throw new ResourceNotFoundException("DepartmentId  Invalid");
		}
		Project project=projectRepository.save(modelMapper.map(projectDTOReq, Project.class));
		departmentProjectRepository.save(buildDepartmentProject(department.get(),project));
		return modelMapper.map(project, ProjectDTO.class);
	}

	@Override
	public void deleteProjectFromDepartment(Long id, Long projectId) throws ResourceNotFoundException {
		Optional<Department> department =departmentRepository.findById(id);
		if(department.isEmpty()) {
			throw new ResourceNotFoundException("DepartmentId  Invalid");
		}
		projectRepository.deleteById(projectId);
		DepartmentProjectId departmentProjectId=new DepartmentProjectId();
		departmentProjectId.setDepartmentId(id.intValue());
		departmentProjectId.setProjectId(projectId.intValue());
		departmentProjectRepository.deleteById(departmentProjectId);
	}

	private DepartmentProject buildDepartmentProject(Department department, Project project) {
		DepartmentProject departmentProject=new DepartmentProject();
		departmentProject.setActive(true);
		departmentProject.setDepartment(department);
		DepartmentProjectId departmentProjectId=new DepartmentProjectId();
		departmentProjectId.setDepartmentId(department.getId().intValue());
		departmentProjectId.setProjectId(project.getId());
		departmentProject.setId(departmentProjectId);
		return departmentProject;
	}
	@Override
public List<DepartmentDTO> getAllDepartments() {
    List<Department> departments = departmentRepository.findAll();
    
    List<DepartmentDTO> departmentDTOs = departments.stream()
        .map(department -> modelMapper.map(department, DepartmentDTO.class))
        .collect(Collectors.toList());

    return departmentDTOs;
}

    @Override
    public List<DepartmentAddressUsersDTO> getAllDepartmentsByAddressUsersDTO() {
        List<Department> departments = departmentRepository.findAll();

        List<DepartmentAddressUsersDTO> deptAddUserDTO = new ArrayList<>();
        departments.forEach(i -> {
            DepartmentAddressUsersDTO dto = new DepartmentAddressUsersDTO();
            List<UsersDTO> usersDTOS = new ArrayList<>();
            List<UserAccount> users = userAccountRepository.findByDepartmentId(Long.valueOf(i.getId()));
            users.forEach(y -> {
                UsersDTO user = new UsersDTO();
                user.setName(y.getName());
                user.setPosition(y.getPosition());
                usersDTOS.add(user);
            });
			dto.setId(Long.valueOf(i.getId()));
            dto.setUsersDTO(usersDTOS);
            dto.setName(i.getName());
            dto.setFunction(i.getFunction());
            dto.setAddressId(Long.valueOf(i.getAddress().getId()));
            dto.setVote(Long.valueOf(i.getVote()));
            dto.setVoteCode(i.getVoteCode());
            dto.setActive(i.getActive());
            dto.setCreatedBy(i.getCreatedBy());
            dto.setCreatedAt(i.getCreatedAt());
            dto.setModifiedBy(i.getModifiedBy());
            dto.setModifiedAt(i.getModifiedAt());
            dto.setAddressLineNumber1(i.getAddress().getAddressLineNumber1());
            dto.setAddressLineNumber2(i.getAddress().getAddressLineNumber2());
            dto.setCity(i.getAddress().getCity());
            dto.setPostalCode(i.getAddress().getPostalCode());
            dto.setStateId(i.getAddress().getState().getId());
			dto.setAgency_code(i.getAgency_code());
			dto.setWebsite_url(i.getWebsite_url());
            dto.setUsersDTO(usersDTOS);
            deptAddUserDTO.add(dto);
        });

        return deptAddUserDTO;
    }

}
