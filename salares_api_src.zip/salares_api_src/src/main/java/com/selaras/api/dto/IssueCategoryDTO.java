package com.selaras.api.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class IssueCategoryDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private Long id;

    private String issueCatCode;

    private String issueCategory;
    
    private Boolean isActive;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;
    
}
