package com.selaras.api.service;

import com.selaras.api.dto.FaqDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.requests.FaqRequest;
import com.selaras.api.responses.FaqResponse;

import java.util.List;

public interface FaqService {
    public String createOrUpdateFaq(FaqRequest faqRequest) throws BadRequestException;

    List<FaqResponse> getAllFaqCategories();

    List<FaqDTO> getAllFaqs();
}
