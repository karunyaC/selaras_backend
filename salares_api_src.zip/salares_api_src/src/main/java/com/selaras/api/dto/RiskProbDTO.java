package com.selaras.api.dto;

import java.io.Serializable;
import java.time.LocalDateTime;


import lombok.Data;

@Data
public class RiskProbDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Long id;

    private String riskProbCode;

    private String riskProbability;
    
    private Boolean isActive;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;

    // private String riskCode; 
}
