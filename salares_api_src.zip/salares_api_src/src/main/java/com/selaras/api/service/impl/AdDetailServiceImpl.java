package com.selaras.api.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.selaras.api.dto.ADDetailsDTO;
import com.selaras.api.service.AdDetailService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AdDetailServiceImpl implements AdDetailService {@Override
    public List<ADDetailsDTO> getAllAdDetails() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getAllAdDetails'");
    }

    @Override
    public String updateById(ADDetailsDTO adDetailsDTO, long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateById'");
    }

    @Override
    public String bulkDeletes(List<Long> ids) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'bulkDeletes'");
    }

    @Override
    public ADDetailsDTO createAdDetail(ADDetailsDTO adDetailsDTO) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'createAdDetail'");
    }

    @Override
    public ADDetailsDTO getAdDetailById(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getAdDetailById'");
    }

    @Override
    public ADDetailsDTO updateAdDetail(Long id, ADDetailsDTO adDetail) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateAdDetail'");
    }

    @Override
    public void deleteAdDetail(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteAdDetail'");
    }
    

}
