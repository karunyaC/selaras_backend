package com.selaras.api.service;

import com.selaras.api.dto.ProjectCategoryDTO;
import com.selaras.api.dto.ProjectDTO;
import com.selaras.api.entity.AnnouncementTo;
import com.selaras.api.entity.Platform;
import com.selaras.api.entity.PromotionCategory;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.requests.ProjectNotificationsRequest;
import com.selaras.api.requests.UserNotificationRequest;
import com.selaras.api.responses.ProjectUpdateNotificationsResponse;
import com.selaras.api.responses.UserNotificationResponse;

import java.util.List;

public interface ProjectUserNotificationService {
    String saveUserNotification(UserNotificationRequest request) throws BadRequestException;

    List<UserNotificationResponse> getAllUserNotification();

    String saveProjectNotification(ProjectNotificationsRequest request) throws BadRequestException;

    List<ProjectUpdateNotificationsResponse> getAllProjectNotification();

    List<Platform> getallPlatform();

    List<AnnouncementTo> getallannouncement();
    
    List<PromotionCategory> getallPromotion();

    List<ProjectDTO> getallProjects();

}
