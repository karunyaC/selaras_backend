package com.selaras.api.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.selaras.api.dto.IssueCategoryDTO;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.service.IssueCategoryService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/issueCategories")
public class IssueCategoryController {

    private final IssueCategoryService issueCategoryService;

    @PostMapping
    public ResponseEntity<IssueCategoryDTO> createIssueCategory(@RequestBody IssueCategoryDTO issueCategory) {
        IssueCategoryDTO createdCategory = issueCategoryService.createIssueCategory(issueCategory);
        return new ResponseEntity<>(createdCategory, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<IssueCategoryDTO> getIssueCategoryById(@PathVariable Long id) {
        IssueCategoryDTO category = issueCategoryService.getIssueCategoryById(id);
        return new ResponseEntity<>(category, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<IssueCategoryDTO>> getAllIssueCategories() throws ResourceNotFoundException {
        List<IssueCategoryDTO> categories = issueCategoryService.getAllIssueCategories();
        return new ResponseEntity<>(categories, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<IssueCategoryDTO> updateIssueCategory(@PathVariable Long id, 
            @RequestBody IssueCategoryDTO issueCategory) throws ResourceNotFoundException {
        IssueCategoryDTO updatedCategory = issueCategoryService.updateIssueCategory(id, issueCategory);
        return new ResponseEntity<>(updatedCategory, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteIssueCategory(@PathVariable Long id) throws ResourceNotFoundException {
        String responseMessage = issueCategoryService.deleteIssueCategory(id);
        return new ResponseEntity<>(responseMessage, HttpStatus.OK);
    }
}
