package com.selaras.api.service.impl;

import com.selaras.api.dto.DistrictStateAssemblyDTO;
import com.selaras.api.dto.KpiYearsDTO;
import com.selaras.api.dto.MeasuringUnitKpiDTO;
import com.selaras.api.dto.ProjectStartAndEndYearDTO;
import com.selaras.api.entity.*;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.repository.*;
import com.selaras.api.requests.ProjectCategoryRequest;
import com.selaras.api.requests.ProjectStatusRequest;
import com.selaras.api.requests.ProjectStrategicPlanRequest;
import com.selaras.api.responses.ProjectCategoryResponse;
import com.selaras.api.responses.ProjectStatusResponse;
import com.selaras.api.responses.ProjectStrategicPlanResponse;
import com.selaras.api.service.DataDictionaryService;

import lombok.RequiredArgsConstructor;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DataDictionaryServiceImpl implements DataDictionaryService {


    private final ProjectStatusRepository projectStatusRepository;


    private final ProjectCategoryRepository projectCategoryRepository;


    private final StrategicPlanRepository strategicPlanRepository;


    private final DistrictStateAssemblyRepository districtStateAssemblyRepository;


    private final KpiYearsRepository kpiYearsRepository;


    private final ProjectStartAndEndYearRepository projectStartAndEndYearRepository;


    private final MeasuringUnitKpiRepository measuringUnitKpiRepository;

    private final ModelMapper mapper;

    @Override
    public ProjectStatus saveProjectStatus(ProjectStatusRequest request) throws BadRequestException {
        validateProjectStatusRequest(request);
        ProjectStatus projectStatus = projectStatusRepository.findByCode(request.getCode());

        if (projectStatus == null) {
            projectStatus = new ProjectStatus();
            projectStatus.setType("SYSTEM CREATED"); // until roles are identified and implemented, defaulting this to system created
            projectStatus.setCreatedBy("SYSTEM"); // until login is implemented, defaulting this to system
        }
        projectStatus.setActive(request.isStatus());
        projectStatus.setCode(request.getCode());
        projectStatus.setCategory(request.getStatusCategory());

        ProjectStatus updatedProjectStatus = projectStatusRepository.save(projectStatus);

        return updatedProjectStatus;
    }

    @Override
    public List<ProjectStatusResponse> getAllProjectStatus() {
        List<ProjectStatusResponse> responses = new ArrayList<>();

        List<ProjectStatus> statusList = projectStatusRepository.findAll();
        if (!statusList.isEmpty()) {
            statusList.forEach(status -> {
                ProjectStatusResponse res = new ProjectStatusResponse();
                res.setType(status.getType());
                res.setId(status.getId());
                res.setCode(status.getCode());
                res.setCategory(status.getCategory());
                res.setActive(status.getActive());
                res.setCreatedAt(status.getCreatedAt().format(DateTimeFormatter.ofPattern("yyyy-MM-dd, hh:mma")));
                responses.add(res);
            });
        }
        return responses;
    }

    @Override
    public ProjectCategory saveProjectCategory(ProjectCategoryRequest request) throws BadRequestException {
        validateProjectCategoryRequest(request);
        ProjectCategory projectCategory = projectCategoryRepository.findByCode(request.getCode());

        if (projectCategory == null) {
            projectCategory = new ProjectCategory();
            projectCategory.setCreatedBy("SYSTEM"); // until login is implemented, defaulting this to system
        }
        projectCategory.setActive(request.isStatus());
        projectCategory.setCode(request.getCode());
        projectCategory.setName(request.getCategory());

        ProjectCategory savedProjectCategory = projectCategoryRepository.save(projectCategory);

        return savedProjectCategory;
    }

    private void validateProjectCategoryRequest(ProjectCategoryRequest request) throws BadRequestException {
        if (request.getCategory() == null || request.getCategory().trim().isEmpty() || request.getCode() == null || request.getCode().trim().isEmpty()) {
            throw new BadRequestException("Invalid input data provided");
        }
    }

    @Override
    public List<ProjectCategoryResponse> getAllProjectCategory() {
        List<ProjectCategoryResponse> responses = new ArrayList<>();

        List<ProjectCategory> categoryList = projectCategoryRepository.findAll();
        if (!categoryList.isEmpty()) {
            categoryList.forEach(status -> {
                ProjectCategoryResponse res = new ProjectCategoryResponse();
                res.setId(status.getId());
                res.setCode(status.getCode());
                res.setCategory(status.getName());
                res.setActive(status.getActive());
                res.setCreatedAt(status.getCreatedAt().format(DateTimeFormatter.ofPattern("yyyy-MM-dd, hh:mma")));
                responses.add(res);
            });
        }
        return responses;
    }

    @Override
    public StrategicPlan saveProjectStrategicPlan(ProjectStrategicPlanRequest request) throws BadRequestException {
        validateProjectStrategicPlanRequest(request);
        StrategicPlan strategicPlan = strategicPlanRepository.findByCode(request.getCode());

        if (strategicPlan == null) {
            strategicPlan = new StrategicPlan();
            strategicPlan.setCreatedBy("SYSTEM"); // until login is implemented, defaulting this to system
        }
        strategicPlan.setActive(request.isStatus());
        strategicPlan.setCode(request.getCode());
        strategicPlan.setEndYear(LocalDate.parse(request.getEndYear()).atTime(LocalTime.MIN));
        strategicPlan.setStartYear(LocalDate.parse(request.getStartYear()).atTime(LocalTime.MIN));
        strategicPlan.setCoreName(request.getCoreName());
        strategicPlan.setNoOfCores(request.getNoOfCores());

        StrategicPlan updatedStrategicPlan = strategicPlanRepository.save(strategicPlan);

        return updatedStrategicPlan;
    }

    private void validateProjectStrategicPlanRequest(ProjectStrategicPlanRequest request) throws BadRequestException {
        if (request.getCode() == null || request.getCode().trim().isEmpty()
                || request.getNoOfCores() == 0
                || request.getCoreName() == null || request.getCoreName().trim().isEmpty()
                || request.getStartYear() == null || request.getStartYear().trim().isEmpty()
                || request.getEndYear() == null || request.getEndYear().trim().isEmpty()) {
            throw new BadRequestException("Invalid input data provided");
        }
        LocalDateTime start = LocalDate.parse(request.getStartYear()).atTime(LocalTime.MIN);
        LocalDateTime end = LocalDate.parse(request.getEndYear()).atTime(LocalTime.MIN);

        if (start.isAfter(end)) {
            throw new BadRequestException("Start Date cannot be specified after End Date");
        }
    }

    @Override
    public List<ProjectStrategicPlanResponse> getAllProjectStrategicPlan() {
        List<ProjectStrategicPlanResponse> responses = new ArrayList<>();

        List<StrategicPlan> stategicPlanList = strategicPlanRepository.findAll();
        if (!stategicPlanList.isEmpty()) {
            stategicPlanList.forEach(status -> {
                ProjectStrategicPlanResponse res = new ProjectStrategicPlanResponse();
                res.setId(status.getId());
                res.setCode(status.getCode());
                res.setCoreName(status.getCoreName());
                res.setStatus(status.getActive());
                res.setNoOfCores(status.getNoOfCores());
                res.setCreatedAt(status.getCreatedAt().format(DateTimeFormatter.ofPattern("yyyy-MM-dd, hh:mma")));
                res.setStartYear(status.getStartYear().format(DateTimeFormatter.ofPattern("yyyy")));
                res.setEndYear(status.getEndYear().format(DateTimeFormatter.ofPattern("yyyy")));
                responses.add(res);
            });
        }
        return responses;
    }

    @Override
    public DistrictStateAssemblyDTO saveDistrictStateAssembly( DistrictStateAssemblyDTO request ) {

        //Validate that Request is not null
        Assert.notNull(request,"Given request is Null");
        DistrictStateAssembly districtStateAssembly = mapper.map( request, DistrictStateAssembly.class );
        districtStateAssembly.setCreatedBy( request.getCreatedBy() != null ? request.getCreatedBy() : "SYSTEM" );
        DistrictStateAssembly savedObject =  districtStateAssemblyRepository.save( districtStateAssembly );
        return mapper.map( savedObject, DistrictStateAssemblyDTO.class );
    }

    @Override
    public List< DistrictStateAssemblyDTO > getDistrictStateAssembly() {

        List<DistrictStateAssemblyDTO> districtStateAssemblyDTOList = new ArrayList<>();
        List< DistrictStateAssembly > districtStateAssemblyList = districtStateAssemblyRepository.findAll();
        if( districtStateAssemblyList.isEmpty() ) {
            return null;
        } else {
            for( DistrictStateAssembly value : districtStateAssemblyList  ){
                DistrictStateAssemblyDTO dto = mapper.map( value, DistrictStateAssemblyDTO.class );
                districtStateAssemblyDTOList.add( dto );
            }
            return districtStateAssemblyDTOList;
        }
    }

    @Override
    public KpiYearsDTO saveKpiYears( KpiYearsDTO request ) {

        //Validate that Request is not null
        Assert.notNull(request,"Given request is Null");

        KpiYears kpiYears = new KpiYears();
        kpiYears.setActive( request.getActive() );
        kpiYears.setYears( request.getYears() );
        kpiYears.setCreatedBy(request.getCreatedBy() != null ? request.getCreatedBy() : "SYSTEM"  );
        kpiYears.setCode( request.getCode() );
        kpiYears.setModifiedBy( request.getModifiedBy() );

       KpiYears savedObject= kpiYearsRepository.save( kpiYears );
        return mapper.map( savedObject, KpiYearsDTO.class );
    }

    @Override
    public List< KpiYearsDTO > getKpiYears() {

        List<KpiYears> kpiYearsList = kpiYearsRepository.findAll();
        List<KpiYearsDTO> dtoList= new ArrayList<>();

        if( kpiYearsList.isEmpty() ) {
            return null;
        } else {
            for( KpiYears value : kpiYearsList  ){
                KpiYearsDTO dto = mapper.map( value, KpiYearsDTO.class );
                dtoList.add( dto );
            }
            return dtoList;
        }
    }

    @Override
    public ProjectStartAndEndYearDTO saveProjectYears( ProjectStartAndEndYearDTO request ) {

        // Mapping Values got in request to Entity
        ProjectStartAndEndYear projectStartAndEndYear = mapper
                .map( request, ProjectStartAndEndYear.class );

        projectStartAndEndYear.setCreatedBy( request.getCreatedBy() != null ? request.getCreatedBy() : "SYSTEM" );
        ProjectStartAndEndYear savedObject = projectStartAndEndYearRepository.save( projectStartAndEndYear );
       // Returning the saved Object mapped to DTO
        return mapper.map( savedObject, ProjectStartAndEndYearDTO.class );
    }

    @Override
    public List< ProjectStartAndEndYearDTO > getProjectYears() {

        List<ProjectStartAndEndYear> foundList = projectStartAndEndYearRepository.findAll();
        List<ProjectStartAndEndYearDTO> dtoList = new ArrayList<>();

        if( foundList.isEmpty() ) {
            return null;
        } else {
            for( ProjectStartAndEndYear value : foundList  ){
                ProjectStartAndEndYearDTO dto = mapper.map( value, ProjectStartAndEndYearDTO.class );
                dtoList.add( dto );
            }
            return dtoList;
        }
    }

    @Override
    public MeasuringUnitKpiDTO saveMeasuringUnit( MeasuringUnitKpiDTO request ) {

        MeasuringUnitKpi measuringUnitKpi = mapper
                .map( request, MeasuringUnitKpi.class );

        measuringUnitKpi.setCreatedBy( request.getCreatedBy() != null ? request.getCreatedBy() : "SYSTEM" );
        MeasuringUnitKpi savedObject =  measuringUnitKpiRepository.save( measuringUnitKpi );

        // Returning the saved Object mapped to DTO
        return mapper.map( savedObject, MeasuringUnitKpiDTO.class );
    }

    @Override
    public List< MeasuringUnitKpiDTO > getMeasuringUnit() {

        List<MeasuringUnitKpi> foundList = measuringUnitKpiRepository.findAll();
        List<MeasuringUnitKpiDTO> dtoList = new ArrayList<>();

        if( foundList.isEmpty() ) {
            return null;
        } else {
            for( MeasuringUnitKpi value : foundList  ){
                MeasuringUnitKpiDTO dto = mapper.map( value, MeasuringUnitKpiDTO.class );
                dtoList.add( dto );
            }
            return dtoList;
        }
    }

    private void validateProjectStatusRequest(ProjectStatusRequest request) throws BadRequestException {

        if (request.getStatusCategory() == null || request.getStatusCategory().trim().isEmpty() || request.getCode() == null || request.getCode().trim().isEmpty()) {
            throw new BadRequestException("Invalid input data provided");
        }
    }
}
