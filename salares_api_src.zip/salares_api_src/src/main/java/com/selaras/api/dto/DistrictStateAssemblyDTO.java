package com.selaras.api.dto;


import lombok.Data;

import java.time.LocalDateTime;

/**
 * Current Data transfer Object will be used for UI request handling and Responses
 */
@Data
public class DistrictStateAssemblyDTO {

    private Long id;
    private String code;
    private Integer numberOfDistricts;
    private Integer numberOfStateAssembly;
    private String nameOfDistricts;
    private String nameOfStateAssembly;
    private String stateAssemblyCode;
    private Boolean active;
    private String createdBy;
    private LocalDateTime createdAt;
    private String modifiedBy;
    private LocalDateTime modifiedAt;

}
