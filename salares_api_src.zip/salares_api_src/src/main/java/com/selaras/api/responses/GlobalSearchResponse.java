package com.selaras.api.responses;

import com.selaras.api.dto.DepartmentDTO;
import com.selaras.api.dto.RoleDTO;
import com.selaras.api.dto.UsersDTO;
import com.selaras.api.entity.Department;
import com.selaras.api.entity.UserAccount;
import com.selaras.api.repository.UserAccountRepository;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GlobalSearchResponse {
    List<UsersDTO> users;
    List<DepartmentDTO> departments;
    List<RoleDTO> roles;
}
