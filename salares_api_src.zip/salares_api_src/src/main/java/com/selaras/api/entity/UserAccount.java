package com.selaras.api.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * $table.getTableComment()
 */
@Data
@Entity
@Table(name = "user_account")
public class UserAccount implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "email", nullable = false)
    private String email;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "kp_number")
    private String kpNumber;

    @Column(name = "domain_id", nullable = false)
    private Long domainId;

    @Column(name = "system_generated_password", nullable = false)
    private Boolean systemGeneratedPassword;

    @Column(name = "change_password_on_first_login", nullable = false)
    private Boolean changePasswordOnFirstLogin;

    @Column(name = "email_proof_of_authentication", nullable = false)
    private Boolean emailProofOfAuthentication;

    @Column(name = "department_id")
    private Long departmentId;

    @Column(name = "section_id")
    private Long sectionId;

    @Column(name = "position")
    private String position;

    @Column(name = "official_phone")
    private String officialPhone;

    @Column(name = "mobile_phone")
    private String mobilePhone;

    @Column(name = "type_of_department_administrator")
    private Long typeOfDepartmentAdministrator;

    @Column(name = "active", nullable = false)
    private Boolean active;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "modified_at")
    private LocalDateTime modifiedAt;

    @Column(name = "reset_token")
    private String resetToken;

    @Column(name = "login_captcha")
    private String loginCaptcha;

    public void updateLoginAttempt(boolean success) {
        this.active = success; // Indicates whether the login attempt was successful
        this.modifiedAt = modifiedAt; // Update the modified timestamp
    }

    @Column(name = "manager_ser_id")
    private Long managerUserId;
}
