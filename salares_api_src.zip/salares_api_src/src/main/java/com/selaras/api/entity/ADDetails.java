package com.selaras.api.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "ad_details")
public class ADDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long row_id;

    @Column(unique = true)
    private String domainName;

    @Column(length = 50)
    private String port;

    @Column(length = 50)
    private String groupBase;

    private boolean isActive;

    @Column(columnDefinition = "DATETIME")
    private Date createdAt;

    @Column(length = 50)
    private String createdBy;

    @Column(columnDefinition = "DATETIME")
    private Date modifiedAt;

    @Column(length = 50)
    private String modifiedBy;
}
