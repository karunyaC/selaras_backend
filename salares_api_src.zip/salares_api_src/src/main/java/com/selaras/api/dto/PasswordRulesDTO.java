package com.selaras.api.dto;


import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class PasswordRulesDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;

    private String ruleName;

    private String description;

    private Boolean active;

    private LocalDateTime createdAt;

    private String createdBy;

    private String modifiedBy;

    private LocalDateTime modifiedAt;

}
