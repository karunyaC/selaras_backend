package com.selaras.api.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class IssueStatusDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private Long id;

    private String IssueStatusCode;

    private String IssueStatus;
    
    private Boolean isActive;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;
    
}
