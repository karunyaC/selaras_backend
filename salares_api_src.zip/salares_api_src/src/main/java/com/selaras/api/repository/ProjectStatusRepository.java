package com.selaras.api.repository;

import com.selaras.api.entity.ProjectStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ProjectStatusRepository extends JpaRepository<ProjectStatus, Long>, JpaSpecificationExecutor<ProjectStatus> {

    ProjectStatus findByCode(String code);
}