package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.dto.RoleDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.responses.RolesResponse;
import com.selaras.api.service.RoleService;
import com.selaras.api.util.ApplicationConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/role")
@RequiredArgsConstructor
public class RoleController {

    private  final RoleService roleService;
    
    @Operation(summary = "Create a new Role", description = "Create a new role in the system")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("Create")
    @AuditTrail(recordType = "Role", action = "Create Role", presentValue = "Role created")
    public ResponseEntity<RoleDTO> createRole(@RequestBody RoleDTO roleDTO) throws BadRequestException {
        roleDTO = roleService.createRole(roleDTO);

        return new ResponseEntity<>(roleDTO, HttpStatus.OK);
    }
    
    @Operation(summary = "Get all Roles", description = "Retrieve a list of all roles")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/getAll")
    @AuditTrail(recordType = "Role", action = "Get All Roles", presentValue = "Retrieved all roles")
    public ResponseEntity<List<RoleDTO>> getRoles() {
        var roles = roleService.getRoles();

        return new ResponseEntity<>(roles, HttpStatus.OK);
    }
   
    @Operation(summary = "Get Role by ID", description = "Retrieve a role by its ID")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/id/{roleId}")
    @AuditTrail(recordType = "Role", action = "Get Role by ID", presentValue = "Retrieved role with ID")
    public ResponseEntity<RoleDTO> getRoleById(@PathVariable("id") Long id) {
        var role = roleService.findRoleById(id);

        return new ResponseEntity<>(role, HttpStatus.OK);
    }
    
    @Operation(summary = "Search Role by Name", description = "Search for a role by its name with pagination support")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/name/{roleName}")
    @AuditTrail(recordType = "Role", action = "Search Role by Name", presentValue = "Searched for role by name")
    public ResponseEntity<RolesResponse> getRoleByName(
            @RequestParam(value = "pageNo", defaultValue = ApplicationConstants.DEFAULT_PAGE_NUMBER, required = false) int pageNo,
            @RequestParam(value = "pageSize", defaultValue = ApplicationConstants.DEFAULT_PAGE_SIZE, required = false) int pageSize,
            @RequestParam(value = "sortBy", defaultValue = ApplicationConstants.DEFAULT_SORT_BY, required = false) String sortBy,
            @RequestParam(value = "orderBy", defaultValue = ApplicationConstants.DEFAULT_ORDER_BY, required = false) String orderBy,
            @PathVariable(value = "name") String name) throws ResourceNotFoundException {

        return new ResponseEntity<>(roleService.findRoleByName(pageNo,pageSize,sortBy,orderBy,name),HttpStatus.OK);
    }
    
    @Operation(summary = "Update Role", description = "Update an existing role's details")
    @ApiResponse(responseCode = "200", description = "OK")
    @PutMapping("update")
    @AuditTrail(recordType = "Role", action = "Update Role", previousValue = "Previous role details", presentValue = "Role updated with ID")
    public ResponseEntity<RoleDTO> updateRole(@RequestBody RoleDTO roleDTORequest) throws ResourceNotFoundException {
        var role = roleService.updateRole(roleDTORequest);

        return new ResponseEntity<>(role,HttpStatus.OK);
    }
    
    @Operation(summary = "Delete Role", description = "Delete a role by its ID")
    @ApiResponse(responseCode = "200", description = "OK")
    @DeleteMapping("/delete/{id}")
    @AuditTrail(recordType = "Role", action = "Delete Role", presentValue = "Role deleted with ID")
    public void deleteRole(@PathVariable("id") Long id) {
        roleService.deleteRole(id);
    }
}
