package com.selaras.api.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.Hibernate;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class DepartmentProjectId implements Serializable {
    private static final long serialVersionUID = 7583562772190221296L;
    @Column(name = "department_id", nullable = false)
    private Integer departmentId;

    @Column(name = "project_id", nullable = false)
    private Integer projectId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        DepartmentProjectId entity = (DepartmentProjectId) o;
        return Objects.equals(this.departmentId, entity.departmentId) &&
                Objects.equals(this.projectId, entity.projectId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(departmentId, projectId);
    }

}