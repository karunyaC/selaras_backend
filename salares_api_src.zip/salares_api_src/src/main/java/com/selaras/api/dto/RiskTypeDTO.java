package com.selaras.api.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class RiskTypeDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private Long id;

    private String riskCode;

    private String riskType;
    
    private Boolean isActive;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;
}