package com.selaras.api.service.impl;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmailService {

    
    private  final JavaMailSender mailSender;

    public String sendResetToken(String to, String token, HttpServletRequest request) {
        String subject = "Password Reset Request";
        String text = "To reset your password, click the link below:\n" +
                request.getRemoteHost() + "/reset-password?token=" + token  ;

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);
        mailSender.send(message);

        return "Reset password email have been sent";
    }
}
