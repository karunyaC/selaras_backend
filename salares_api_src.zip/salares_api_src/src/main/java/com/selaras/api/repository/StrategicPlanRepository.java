package com.selaras.api.repository;

import com.selaras.api.entity.StrategicPlan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface StrategicPlanRepository extends JpaRepository<StrategicPlan, Long>, JpaSpecificationExecutor<StrategicPlan> {

    StrategicPlan findByCode(String code);
}