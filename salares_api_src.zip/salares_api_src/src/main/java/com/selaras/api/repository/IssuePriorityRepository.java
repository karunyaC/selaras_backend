package com.selaras.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.selaras.api.entity.IssuePriority;


public interface IssuePriorityRepository extends JpaRepository<IssuePriority, Long>, JpaSpecificationExecutor<IssuePriority> {
    
}
