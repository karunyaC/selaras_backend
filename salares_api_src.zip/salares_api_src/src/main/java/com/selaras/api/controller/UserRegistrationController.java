package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.dto.UserAccountDTO;
import com.selaras.api.service.UserAccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/register")
@RequiredArgsConstructor
public class UserRegistrationController {

    private  final UserAccountService userAccountService;

    @Operation(summary = "Register User", description = "Register user")
    @ApiResponse(responseCode = "200", description = "OK")
    @AuditTrail(recordType = "User registration", action = "user registration", presentValue = "user registered")
    //@PostMapping
    public ResponseEntity<UserAccountDTO> registerUser(@RequestBody UserAccountDTO userAccountDTO) {
        userAccountDTO = userAccountService.registerUser(userAccountDTO);
        return new ResponseEntity<UserAccountDTO>(userAccountDTO, HttpStatus.OK);
    }

}
