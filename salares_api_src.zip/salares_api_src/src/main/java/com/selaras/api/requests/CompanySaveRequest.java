package com.selaras.api.requests;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanySaveRequest {
    private String companyName;
    private String regNo;
    private boolean status;
}
