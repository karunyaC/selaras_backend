package com.selaras.api.service.impl;

import com.selaras.api.dto.ModuleAccessLevelDTO;
import com.selaras.api.dto.ModuleDTO;
import com.selaras.api.entity.Module;
import com.selaras.api.repository.AccessLevelRepository;
import com.selaras.api.repository.ModuleAccessLevelRepository;
import com.selaras.api.repository.ModuleRepository;
import com.selaras.api.service.ModuleService;

import lombok.RequiredArgsConstructor;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ModuleServiceImpl implements ModuleService {


    private final ModuleRepository moduleRepository;


    private final AccessLevelRepository accessLevelRepository;


    private final ModuleAccessLevelRepository moduleAccessLevelRepository;


    private final ModelMapper modelMapper;

    @Override
    public List<ModuleDTO> getAllModules() {
        List<Module> modules = moduleRepository.findAll();

        return modules
                .stream()
                .map(module -> modelMapper.map(module, ModuleDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public ModuleDTO getModuleById(Long id) {
        Module module = moduleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid module ID"));

        return modelMapper.map(module, ModuleDTO.class);
    }

    @Override
    public ModuleDTO createModule(ModuleDTO moduleDTO) {
        Module module = modelMapper.map(moduleDTO, Module.class);
        module = moduleRepository.save(module);

        return modelMapper.map(module, ModuleDTO.class);
    }

    @Override
    public void deleteModule(Long id) {
        Module module = moduleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid module ID"));
        module.setActive(false);

        moduleRepository.save(module);
    }

    @Override
    public ModuleAccessLevelDTO addAccessLevelToModule(Long moduleId, Long accessLevelId, String additionalInfo) {
        return null;
    }

    @Override
    public String uploadLogo(Long moduleId, MultipartFile image) {

        String fileName = image.getOriginalFilename();
        String fileType = image.getContentType();

        if (fileType == null || (!fileType.equals("image/jpeg") && !fileType.equals("image/png"))) {
            throw new IllegalArgumentException("Only JPG, JPEG, and PNG files are allowed.");
        }

        Module module = moduleRepository.findById(moduleId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid module ID"));

        try {
            module.setLogo(image.getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        moduleRepository.save(module);

        return "Logo uploaded successfully";
    }

    @Override
    public byte[] downloadLogo(Long moduleId) {
        Module module = moduleRepository.findById(moduleId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid module ID"));
        if(module.getLogo().length > 0) {
            return module.getLogo();
        }
        return new byte[0];
    }
}
