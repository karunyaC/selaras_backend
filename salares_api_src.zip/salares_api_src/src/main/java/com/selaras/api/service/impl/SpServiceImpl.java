package com.selaras.api.service.impl;

import com.selaras.api.entity.*;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.*;
import com.selaras.api.requests.CoreDTO;
import com.selaras.api.requests.SpSaveDTO;
import com.selaras.api.requests.StrategyDTO;
import com.selaras.api.service.SpService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SpServiceImpl implements SpService {

    private final SPOverviewRepository spOverviewRepository;
    private final SPCoreRepository spCoreRepository;
    private final SPStrategyRepository spStrategyRepository;

    @Override
    @Transactional
    public SpSaveDTO saveSp(SpSaveDTO saveDTO) {
        // Create and save SPOverview

        SPOverview spOverview = spOverviewRepository.findBySpCode(saveDTO.getSpCode());
        if (spOverview == null) {
            spOverview = new SPOverview();
        }
        spOverview.setSpCode(saveDTO.getSpCode());
        spOverview.setSpStartyear(LocalDate.parse(saveDTO.getYearFrom()));
        spOverview.setSpEndyear(LocalDate.parse(saveDTO.getYearUpto()));
        spOverview.setSpNumCores(Integer.valueOf(saveDTO.getNoOfCores()));
        spOverview.setStatusLookup(saveDTO.isStatus());
        spOverviewRepository.save(spOverview);

        // Loop through each core in the request
        int coreCount = 1;
        for (CoreDTO coreRequest : saveDTO.getCore()) {
            SPCore spCore = spCoreRepository.findBySpCorePreferredName(coreRequest.getCoreName());
            if (spCore == null) {
                spCore = new SPCore();
                spCore.setSpCoreId("PSP-KP-T" + coreCount);
            }

            spCore.setSpCorePreferredName(coreRequest.getCoreName());
            spCore.setSpCorePreferredCode("CORE-" + coreCount);
            spCore.setSpPlanCode(spOverview.getSpPlanCode());
            spCoreRepository.save(spCore);


            // Loop through each strategy in the core
            int strategyCount = 1;
            for (StrategyDTO strategyRequest : coreRequest.getStrategy()) {
                SPStrategy spStrategy = spStrategyRepository.findBySpStratPreferredName(strategyRequest.getStrategyName());
                if (spStrategy == null) {
                    spStrategy = new SPStrategy();
                    spStrategy.setSpStratId("STRAT-" + coreCount + "-" + strategyCount);
                    spStrategy.setRowId(spCore.getRowId());
                    spStrategy.setSpCore(spCore);
                    spStrategy.setSpOverview(spOverview);
                }
                spStrategy.setSpStratId("STRAT-" + coreCount + "-S" + strategyCount);
               spStrategy.setSpStratPreferredCode(spCore.getSpCorePreferredCode() + "-S" + strategyCount);
               // spStrategy.setRowId(Integer.valueOf(spCore.getRowId()));
                spStrategy.setSpStratPreferredCode(spCore.getSpCorePreferredCode());
                spStrategy.setSpStratPreferredName(strategyRequest.getStrategyName());
                spStrategy.setSpPlanCode(spOverview.getSpPlanCode());
                spStrategyRepository.save(spStrategy);
                strategyCount++;
            }
            coreCount++;
        }
        return saveDTO;
    }

    @Override
    public List<SpSaveDTO> getAllsp() {
        List<SPOverview> overviews = spOverviewRepository.findAll();
        List<SpSaveDTO> saveDTOS = new ArrayList<>();
        overviews.forEach(o -> {
            SpSaveDTO saveDTO = new SpSaveDTO();
            saveDTO.setSpCode(o.getSpCode());
            saveDTO.setNoOfCores(String.valueOf(o.getSpNumCores()));
            saveDTO.setYearFrom(String.valueOf(o.getSpStartyear()));
            saveDTO.setYearUpto(String.valueOf(o.getSpEndyear()));
            saveDTO.setStatus(o.isStatusLookup());
            List<SPCore> cores = spCoreRepository.findBySpOverviewSpCode(o.getSpCode());
            List<CoreDTO> coreDTOS = new ArrayList<>();
            cores.forEach(c -> {
                CoreDTO coreDTO = new CoreDTO();
                coreDTO.setCoreName(c.getSpCorePreferredName());
                List<SPStrategy> strategies = spStrategyRepository.findBySpCoreSpCoreId(c.getSpCorePreferredCode());
                List<StrategyDTO> strategyDTOS = new ArrayList<>();
                strategies.forEach(s -> {
                    StrategyDTO strategyDTO = new StrategyDTO();
                    strategyDTO.setStrategyCode(s.getSpStratId());
                    strategyDTO.setStrategyName(s.getSpStratPreferredName());
                    strategyDTOS.add(strategyDTO);
                });
                coreDTO.setStrategy(strategyDTOS);
                coreDTOS.add(coreDTO);
            });
            saveDTO.setCore(coreDTOS);
            saveDTOS.add(saveDTO);
        });
        return saveDTOS;
    }

    @Override
    public SpSaveDTO getSpByCode(String code) {
        SPOverview overviews = spOverviewRepository.findBySpCode(code);
        if(overviews == null) {
            return new SpSaveDTO();
        }
        SpSaveDTO saveDTO = new SpSaveDTO();
        saveDTO.setSpCode(overviews.getSpPlanCode());
        saveDTO.setNoOfCores(String.valueOf(overviews.getSpNumCores()));
        saveDTO.setYearFrom(String.valueOf(overviews.getSpStartyear()));
        saveDTO.setYearUpto(String.valueOf(overviews.getSpEndyear()));
        saveDTO.setStatus(overviews.isStatusLookup());
        List<SPCore> cores = spCoreRepository.findBySpOverviewSpCode(overviews.getSpCode());
        List<CoreDTO> coreDTOS = new ArrayList<>();
        cores.forEach(c -> {
            CoreDTO coreDTO = new CoreDTO();
            coreDTO.setCoreName(c.getSpCorePreferredName());
            List<SPStrategy> strategies = spStrategyRepository.findBySpCoreSpCoreId(c.getSpCorePreferredCode());
            List<StrategyDTO> strategyDTOS = new ArrayList<>();
            strategies.forEach(s -> {
                StrategyDTO strategyDTO = new StrategyDTO();
                strategyDTO.setStrategyCode(s.getSpStratPreferredCode());
                strategyDTO.setStrategyName(s.getSpStratPreferredName());
                strategyDTOS.add(strategyDTO);
            });
            coreDTO.setStrategy(strategyDTOS);
            coreDTOS.add(coreDTO);
        });
        saveDTO.setCore(coreDTOS);

        return saveDTO;
    }

    @Override
    public String deleteSpByCode(String code) throws ResourceNotFoundException {
        SPOverview overviews = spOverviewRepository.findBySpCode(code);
        if(overviews == null) {
            throw new ResourceNotFoundException("Strategic Plan not found with given code");
        }
        overviews.setStatusLookup(false);
        spOverviewRepository.save(overviews);
        return "Strategic Plan deleted successfully";
    }
}
