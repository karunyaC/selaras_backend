package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.dto.DivisionDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.service.DivisionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping( value = "/api" )
public class DivisionController {

    private final DivisionService divisionService;

    @Operation( summary = "Save Division/Section", description = "Persist Values to DB for Division/Section" )
    @ApiResponse( responseCode = "201", description = "Created" )
    @PostMapping( "/project/division" )
    @AuditTrail( recordType = "Division", action = "Save Division/Section", presentValue = "District/Section saved" )
    public ResponseEntity< DivisionDTO > saveDivision( @RequestBody DivisionDTO request ) throws BadRequestException {
        return ResponseEntity.status( HttpStatus.CREATED ).body( divisionService.saveDivision( request ) );
    }

    @Operation( summary = "Get Division/Section", description = "Retrieve all Division/Section" )
    @ApiResponse( responseCode = "200", description = "OK" )
    @GetMapping( "/project/division" )
    @AuditTrail( recordType = "Division/Section", action = "Retrieve Division/Section", presentValue = "All Division/Section retrieved" )
    public ResponseEntity< List< DivisionDTO > > getDivisionAll() throws BadRequestException {
        return ResponseEntity.ok().body( divisionService.getAllDivision() );
    }

    @Operation( summary = "Update Division/Section", description = "Update Values to DB for Division/Section" )
    @ApiResponse( responseCode = "200", description = "OK" )
    @PutMapping( "/project/division" )
    @AuditTrail( recordType = "Division", action = "Update Division/Section", presentValue = "District/Section updated" )
    public ResponseEntity< DivisionDTO > updateDivision( @RequestBody DivisionDTO request ) throws BadRequestException {
        return ResponseEntity.status( HttpStatus.OK ).body( divisionService.saveDivision( request ) );
    }

    @Operation( summary = "Delete Division/Section", description = "Delete Values for Division/Section" )
    @ApiResponse( responseCode = "204", description = "No Content" )
    @DeleteMapping( "/project/division" )
    @AuditTrail( recordType = "Division", action = "Delete Division/Section", presentValue = "District/Section Deleted" )
    public ResponseEntity< Void > deleteDivision( @PathVariable Long id ) throws BadRequestException {
        divisionService.deleteByDivisionId( id );
        return ResponseEntity.noContent().build();
    }
}
