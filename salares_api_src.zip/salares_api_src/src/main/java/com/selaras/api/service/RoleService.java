package com.selaras.api.service;

import com.selaras.api.dto.RoleDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.responses.RolesResponse;

import java.util.List;

public interface RoleService {
    RoleDTO createRole(RoleDTO roleDTO) throws BadRequestException;

    List<RoleDTO> getRoles();

    RoleDTO findRoleById(Long id);

    RolesResponse findRoleByName(int pageNo, int pageSize, String sortBy, String orderBy, String name) throws ResourceNotFoundException;

    RoleDTO updateRole(RoleDTO roleDTO) throws ResourceNotFoundException;

    void deleteRole(Long id);
}
