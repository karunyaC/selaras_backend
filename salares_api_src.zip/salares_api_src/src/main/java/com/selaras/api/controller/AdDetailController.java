package com.selaras.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.selaras.api.dto.ADDetailsDTO;
import com.selaras.api.service.AdDetailService;

@RestController
@RequestMapping("/api/adDetails")
public class AdDetailController {
    @Autowired
    private AdDetailService adDetailService;

    @GetMapping
    public List<ADDetailsDTO> getAllAdDetails() {
        return adDetailService.getAllAdDetails();
    }

    @PostMapping
    public ADDetailsDTO createAdDetail(@RequestBody ADDetailsDTO adDetail) {
        return adDetailService.createAdDetail(adDetail);
    }

    @GetMapping("/{id}")
    public ADDetailsDTO getAdDetailById(@PathVariable Long id) {
        return adDetailService.getAdDetailById(id);
    }

    @PutMapping("/{id}")
    public ADDetailsDTO updateAdDetail(@PathVariable Long id, @RequestBody ADDetailsDTO adDetail) {
        return adDetailService.updateAdDetail(id, adDetail);
    }

    @DeleteMapping("/{id}")
    public void deleteAdDetail(@PathVariable Long id) {
        adDetailService.deleteAdDetail(id);
    }
    
}
