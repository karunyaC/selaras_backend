package com.selaras.api.service.impl;


import com.selaras.api.entity.UserAccount;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.UserAccountRepository;
import com.selaras.api.repository.UserRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {


    private final UserAccountRepository userAccountRepository;
    private final UserRepository repository;

    @Override
    public UserDetails loadUserByUsername(String email) {

        UserAccount userAccount = null;

        userAccount = userAccountRepository.findByEmail(email);

        if (userAccount == null) {
            new ResourceNotFoundException(String.format("User does not exist, email: %s", email));

        }

        return org.springframework.security.core.userdetails.User.builder()
                .username(userAccount.getName())
                .password(userAccount.getPassword())
                .build();
    }
}
