package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.service.FileHandlerService;
import io.minio.errors.*;
import lombok.RequiredArgsConstructor;

import org.simpleframework.xml.Path;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

@RestController
@RequestMapping("/api/file")
@RequiredArgsConstructor
public class FileHandlerController {

    private final FileHandlerService fileHandlerService;

    @PostMapping("/upload")
    @AuditTrail(recordType = "File", action = "Upload File", presentValue = "File uploaded to folder 'selaras' with name: {file.originalFilename}")
    public ResponseEntity<?> uploadFile(@RequestPart("file") MultipartFile file) throws ServerException, InsufficientDataException, BadRequestException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {

        return new ResponseEntity<>(fileHandlerService.uploadFile("selaras",file), HttpStatus.OK);
    }

    @PostMapping("/download/{folder}/{filePath}")
    @AuditTrail(recordType = "File", action = "Download File", presentValue = "File downloaded from folder: {folder}, with path: {filePath}")
    public ResponseEntity<?> downloadFile(@PathVariable String folder, @PathVariable String filePath) throws ServerException, InsufficientDataException, BadRequestException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        Map<InputStream, String> map = fileHandlerService.downloadFile(folder + "/" + filePath);
        InputStream is = null;
        String contentType = null;

        if (!map.isEmpty()) {
            // Assuming the map contains only one entry
            Map.Entry<InputStream, String> entry = map.entrySet().iterator().next();
            is = entry.getKey();
            contentType = entry.getValue();
        }
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filePath.substring(filePath.lastIndexOf("/") + 1) + "\"")
                .contentType(MediaType.parseMediaType(contentType))
                .body(new InputStreamResource(is));
    }
}
