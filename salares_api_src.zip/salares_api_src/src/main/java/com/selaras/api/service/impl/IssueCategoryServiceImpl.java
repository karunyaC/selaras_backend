package com.selaras.api.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.selaras.api.dto.IssueCategoryDTO;
import com.selaras.api.entity.IssueCategory;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.IssueCatRepository;
import com.selaras.api.service.IssueCategoryService;

import lombok.RequiredArgsConstructor;
@Service
@RequiredArgsConstructor
public class IssueCategoryServiceImpl implements IssueCategoryService {


    private final IssueCatRepository issueCatRepository;
    private final ModelMapper modelMapper;

    @Override
    public IssueCategoryDTO createIssueCategory(IssueCategoryDTO issueCategory) {
        IssueCategory iCategory=modelMapper.map(issueCategory, IssueCategory.class);

        IssueCategory issue=issueCatRepository.save(iCategory);
        IssueCategoryDTO rIssueCategoryDTO=modelMapper.map(issue, IssueCategoryDTO.class);
        return rIssueCategoryDTO;
    
    }

    @Override
    public IssueCategoryDTO getIssueCategoryById(Long id) {
        Optional<IssueCategory> issueCategory=issueCatRepository.findById(id);
        IssueCategoryDTO issueCategoryDTO=modelMapper.map(issueCategory, IssueCategoryDTO.class);
        return issueCategoryDTO;
    }

    @Override
    public List<IssueCategoryDTO> getAllIssueCategories() {
        List<IssueCategory> issueCategory=issueCatRepository.findAll();
        if (issueCategory == null || issueCategory.isEmpty()) {
            return List.of();
        }
        List<IssueCategoryDTO> issue=new ArrayList<>();
        for(IssueCategory iCategory:issueCategory){
            IssueCategoryDTO issueCategoryDTO=modelMapper.map(iCategory, IssueCategoryDTO.class);
            issue.add(issueCategoryDTO);
        }
        return issue;

    }

   
   @Override
public IssueCategoryDTO updateIssueCategory(Long id, IssueCategoryDTO issueCategoryDTO) throws ResourceNotFoundException {
    IssueCategory issueCategory = issueCatRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("IssueCategory not found with id " + id));

    issueCategory.setIssueCatCode(issueCategoryDTO.getIssueCatCode());
    issueCategory.setIssueCategory(issueCategoryDTO.getIssueCategory());
    issueCategory.setCreatedAt(issueCategoryDTO.getCreatedAt());
    issueCategory.setModifiedAt(issueCategoryDTO.getModifiedAt());
    issueCategory.setCreatedBy(issueCategoryDTO.getCreatedBy());
    issueCategory.setModifiedBy(issueCategoryDTO.getModifiedBy());

    IssueCategory updatedIssueCategory = issueCatRepository.save(issueCategory);

    return modelMapper.map(updatedIssueCategory, IssueCategoryDTO.class);
}

@Override
public String deleteIssueCategory(Long id) throws ResourceNotFoundException {
    IssueCategory issueCategory = issueCatRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("IssueCategory not found with id " + id));

    issueCategory.setIsActive(false);

    issueCatRepository.save(issueCategory);
    return "IssueCategory with id " + id + " has been deactivated.";
}


   
    
}
