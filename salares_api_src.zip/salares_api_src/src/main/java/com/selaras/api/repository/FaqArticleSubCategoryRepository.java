package com.selaras.api.repository;

import com.selaras.api.entity.FaqArticleSubCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FaqArticleSubCategoryRepository extends JpaRepository<FaqArticleSubCategory,Integer> {

    @Query(nativeQuery = true,value = "select * from public.faq_article_sub_category fasc where category_id  = :categoryId")
    List<FaqArticleSubCategory> findByCategoryId(Integer categoryId);
}