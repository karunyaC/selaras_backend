package com.selaras.api.dto;


import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class DepartmentAddressUsersDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;

    private String name;

    private String function;
    private Long agency_code;

    private Long addressId;
    private String Website_url;

    private Long vote;

    private String voteCode;

    private Boolean active;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;

    private String addressLineNumber1;

    private String addressLineNumber2;

    private String city;

    private String postalCode;

    private Long stateId;

    private List<UsersDTO> usersDTO;

}
