package com.selaras.api.requests;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DspSaveDTO {
    private String planCode;
    private String yearFrom;
    private String yearUpto;
    private String noOfCores;
    private List<CoreDTO> core;
    private boolean status;
}
