package com.selaras.api.service;

import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.requests.AppSecurityRequest;
import com.selaras.api.responses.AppSecurityResponse;

import java.util.List;

public interface AppSecurityServices {
    String saveAppSecurity(List<AppSecurityRequest> request);

    List<AppSecurityResponse> getAppSecurities(String securityType);

    AppSecurityResponse getAppSecuritiesById(Long id) throws ResourceNotFoundException;

    AppSecurityResponse updateAppSecuritiesById(Long id, Boolean active, String ruleValue) throws ResourceNotFoundException;


}
