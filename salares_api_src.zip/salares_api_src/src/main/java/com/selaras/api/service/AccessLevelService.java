package com.selaras.api.service;

import com.selaras.api.dto.AccessLevelDTO;

import java.util.List;

public interface AccessLevelService {

    List<AccessLevelDTO> getAccessLevels();
}
