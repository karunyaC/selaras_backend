package com.selaras.api.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "rmk")
public class Rmk {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "code", nullable = false, length = 50)
    private String code;

    @Column(name = "objective", length = Integer.MAX_VALUE)
    private String objective;

    @Column(name = "start_year")
    private LocalDateTime startYear;

    @Column(name = "end_year")
    private LocalDateTime endYear;

    @Column(name = "overall_budget", precision = 15, scale = 2)
    private BigDecimal overallBudget;

    @ColumnDefault("true")
    @Column(name = "active")
    private Boolean active;

    @Column(name = "created_by", length = 100)
    private String createdBy;

    @ColumnDefault("CURRENT_TIMESTAMP")
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "modified_by", length = 100)
    private String modifiedBy;

    @ColumnDefault("CURRENT_TIMESTAMP")
    @Column(name = "modified_at")
    private LocalDateTime modifiedAt;

}