package com.selaras.api.service.impl;

import com.selaras.api.dto.UserAccountDTO;
import com.selaras.api.entity.Department;
import com.selaras.api.entity.UserAccount;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.DepartmentRepository;
import com.selaras.api.repository.UserAccountRepository;
import com.selaras.api.repository.specification.UserAccountSpecification;
import com.selaras.api.service.UserAccountService;

import lombok.RequiredArgsConstructor;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserAccountServiceImpl implements UserAccountService {

    private final UserAccountRepository userAccountRepository;

    private final DepartmentRepository departmentRepository;

    private final PasswordEncoder passwordEncoder;

    private final ModelMapper modelMapper;

    @Override
    public UserAccountDTO registerUser(UserAccountDTO userAccountDTO) {
        UserAccount userAccount = modelMapper.map(userAccountDTO, UserAccount.class);
        userAccount.setPassword(passwordEncoder.encode(userAccountDTO.getPassword()));

        userAccount.setDomainId(1L);
        userAccount.setDepartmentId(2L);
        userAccount.setSectionId(1L);

        userAccountRepository.save(userAccount);
        return userAccountDTO;
    }

    public List<UserAccountDeptDTO> getAllUserDept() {
        List<UserAccount> users = userAccountRepository.findAll();
        List<UserAccountDeptDTO> userAccountDeptDTOs = new ArrayList<>();

        users.forEach(user -> {
            UserAccountDeptDTO userAccountDeptDTO = modelMapper.map(user, UserAccountDeptDTO.class);

            // Check if departmentId is not null
            if (user.getDepartmentId() != null) {
                Optional<Department> departmentOpt = departmentRepository.findById(user.getDepartmentId());

                // Set agency_name to the department name if available, otherwise set it to null
                userAccountDeptDTO.setAgenct_name(departmentOpt.map(Department::getName).orElse(null));
            } else {
                // If departmentId is null, set agency_name to null
                userAccountDeptDTO.setAgenct_name(null);
            }

            userAccountDeptDTOs.add(userAccountDeptDTO);
        });

        return userAccountDeptDTOs;
    }


    public UserAccountDTO addUser(UserAccountDTO userAccountDTO) {

        UserAccount userAccount = modelMapper.map(userAccountDTO, UserAccount.class);
        userAccount.setPassword(passwordEncoder.encode(userAccountDTO.getPassword()));
        userAccount.setCreatedAt(LocalDateTime.now());
        userAccountRepository.save(userAccount);
        return modelMapper.map(userAccount, UserAccountDTO.class);
    }

    public UserAccountDTO updateUser(Long id, UserAccountDTO userAccountDTO) throws ResourceNotFoundException {
        UserAccount existingUser = userAccountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));

        modelMapper.map(userAccountDTO, existingUser);
        existingUser.setModifiedAt(LocalDateTime.now());
        userAccountRepository.save(existingUser);
        return modelMapper.map(existingUser, UserAccountDTO.class);
    }

    public void deleteUser(Long id) throws ResourceNotFoundException {
        UserAccount userAccount = userAccountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));
        userAccountRepository.delete(userAccount);
    }

    public UserAccountDTO getUserDetails(Long id) throws ResourceNotFoundException {
        UserAccount userAccount = userAccountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));
        return modelMapper.map(userAccount, UserAccountDTO.class);
    }

    public Page<UserAccountDTO> searchUsersByName(String name, Pageable pageable) {
        Page<UserAccount> usersPage = userAccountRepository.findByNameContainingIgnoreCase(name, pageable);
        return usersPage.map(user -> modelMapper.map(user, UserAccountDTO.class));
    }

    @Override
    public Page<UserAccountDTO> getAllUsers(UserAccount filter, Pageable pageable) {
        UserAccountSpecification spec = new UserAccountSpecification(filter);
        Page<UserAccount> page = userAccountRepository.findAll(spec, pageable);
        return page.map(this::mapToDTO);
    }

    @Override
    public List<UserAccountDTO> getAllSystemUsers() {
        List<UserAccount> users = userAccountRepository.findByDomainIdIsNotAndDomainIdIsNotNull(0l);

        List<UserAccountDTO> userAccountDTOList = new ArrayList<>();

        if (!users.isEmpty()) {
            users.forEach(user -> {
                userAccountDTOList.add(modelMapper.map(user, UserAccountDTO.class));
            });
        }
        return userAccountDTOList;
    }

    @Override
    public UserAccountDTO saveOrgUser(UserAccountDTO userAccountDTO) {

        UserAccount ua = new UserAccount();
        if(userAccountDTO.getId() != 0) {
            ua = userAccountRepository.findById(userAccountDTO.getId()).orElse(null);
        } else {
            ua = userAccountRepository.findByEmail(userAccountDTO.getEmail());
        }
        if(ua != null) {
            ua.setManagerUserId(userAccountDTO.getManageUserId());
        } else {
            ua = modelMapper.map(userAccountDTO, UserAccount.class);
            ua.setPassword(passwordEncoder.encode(userAccountDTO.getPassword()));
            ua.setCreatedAt(LocalDateTime.now());
        }
        UserAccount savedUser = userAccountRepository.save(ua);

        return modelMapper.map(savedUser, UserAccountDTO.class);
    }

    private UserAccountDTO mapToDTO(UserAccount userAccount) {
        UserAccountDTO userAccountDTO = modelMapper.map(userAccount, UserAccountDTO.class);
        return userAccountDTO;
    }

    @Override
    public List<UserAccount> getAllUsers() {
        return userAccountRepository.findAll();
    }


}
