package com.selaras.api.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmailTemplateResponse {
    private long id;
    private String templateName;
    private String subject;
    private String body;
    private String firstSavedBody;
    private String firstSavedSubject;
    private boolean active;
}
