package com.selaras.api.service;

import com.selaras.api.exception.BadRequestException;
import com.selaras.api.requests.AuditTrailRequest;
import com.selaras.api.responses.AuditTrailResponse;

import java.util.List;

public interface AuditTrailService {
    String saveAuditTrail(AuditTrailRequest request) throws BadRequestException;

    List<AuditTrailResponse> getAllAuditTrail();
}
