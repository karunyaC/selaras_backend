package com.selaras.api.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.selaras.api.dto.RiskProbDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.service.RiskProbabilityService;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/probability")
public class RiskProbabilityController {

    private final RiskProbabilityService riskProbabilityService;

    @PostMapping
    public ResponseEntity<RiskProbDTO> createRiskProbability(@RequestBody RiskProbDTO riskProbDTO) throws BadRequestException {
        RiskProbDTO createdRiskProb = riskProbabilityService.createRiskProb(riskProbDTO);
        return ResponseEntity.ok(createdRiskProb);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RiskProbDTO> getRiskProbabilityById(@PathVariable long id) throws ResourceNotFoundException {
        RiskProbDTO riskProbDTO = riskProbabilityService.getById(id);
        return ResponseEntity.ok(riskProbDTO);
    }

    @GetMapping
    public ResponseEntity<List<RiskProbDTO>> getAllRiskProbabilities() {
        List<RiskProbDTO> riskProbDTOs = riskProbabilityService.getall();
        return ResponseEntity.ok(riskProbDTOs);
    }

    @PutMapping("/{id}")
    public ResponseEntity<RiskProbDTO> updateRiskProbability(@PathVariable long id, @RequestBody RiskProbDTO riskProbDTO) throws ResourceNotFoundException {
        RiskProbDTO updatedRiskProb = riskProbabilityService.updateRiskProb(id, riskProbDTO);
        return ResponseEntity.ok(updatedRiskProb);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteRiskProbability(@PathVariable long id) throws ResourceNotFoundException {
        String message = riskProbabilityService.deleteRiskProbability(id);
        return ResponseEntity.ok(message);
    }
}
