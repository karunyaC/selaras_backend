package com.selaras.api.service.impl;

import com.selaras.api.dto.RoleDTO;
import com.selaras.api.entity.*;
import com.selaras.api.entity.Module;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.*;
import com.selaras.api.requests.ModuleAccessMapDTO;
import com.selaras.api.responses.RolesResponse;
import com.selaras.api.service.RoleService;

import lombok.RequiredArgsConstructor;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RoleServiceImpl implements RoleService {


    private final RoleRepository roleRepository;

    private final ModuleRepository moduleRepository;

    private final AccessLevelRepository accessLevelRepository;

    private final ModuleAccessLevelRepository moduleAccessLevelRepository;

    private final ModelMapper modelMapper;
    private final RoleAccessLevelRepository roleAcessLevelRepository;


    @Override
    public RoleDTO createRole(RoleDTO roleDTO) throws BadRequestException {

        List<ModuleAccessMapDTO> obj = roleDTO.getModuleAccessLevelsDTOS().getModuleAccessMapDTOList();
        for(ModuleAccessMapDTO i : obj) {
            Module module = moduleRepository.findById(i.getModuleId()).orElse(null);
            if(module == null) {
                throw new BadRequestException("Invalid module");
            }

            List<AccessLevel> accessLevels = accessLevelRepository.findAllById(i.getAccessIds());

            if(accessLevels.isEmpty() || accessLevels.size() != i.getAccessIds().size()) {
                throw new BadRequestException("Invalid access levels");
            }

            List<ModuleAccessLevel> moduleAccessLevels = moduleAccessLevelRepository.findAllByAccessLevel_IdIn(i.getAccessIds());

            List<Long> moduleIdsFromAccess = moduleAccessLevels.stream().map(ModuleAccessLevel::getModule).map(Module::getId).map(Long::valueOf).distinct().collect(Collectors.toList());


            if((moduleAccessLevels.isEmpty() || moduleAccessLevels.size() != i.getAccessIds().size())) {
                throw new BadRequestException("Invalid Module Accesslevel mapping");
            }

            if(moduleIdsFromAccess.size() > 1) {
                throw new BadRequestException("Invalid Module Accesslevel mapping");
            }

            if(moduleIdsFromAccess.get(0) != i.getModuleId()) {
                throw new BadRequestException("Invalid Module Accesslevel mapping");
            }
        }

        Role role = new Role();
        role.setDescription(roleDTO.getDescription());
        role.setName(roleDTO.getName());
        role.setType(roleDTO.getType());
        role.setCreatedAt(roleDTO.getCreatedAt());
        role.setCreatedBy(roleDTO.getCreatedBy());
        role.setActive(roleDTO.getActive());
        role = roleRepository.save(role);

        List<RoleAccessLevel> roleAccessLevels = new ArrayList<>();

        for(ModuleAccessMapDTO obj1 : roleDTO.getModuleAccessLevelsDTOS().getModuleAccessMapDTOList()) {
            for(Long accessId: obj1.getAccessIds()) {
                RoleAccessLevel r = new RoleAccessLevel();
                r.setAccessLevel(accessLevelRepository.findById(accessId).get());
                r.setModule(moduleRepository.findById(obj1.getModuleId()).get());
                r.setRole(role);
                r.setCreatedBy(roleDTO.getCreatedBy());

                roleAccessLevels.add(r);

            }

        }

        List<RoleAccessLevel> savedRoleAccessLevels = roleAcessLevelRepository.saveAll(roleAccessLevels);

        return modelMapper.map(role, RoleDTO.class);

    }

    @Override
    public List<RoleDTO> getRoles() {
        var roles = roleRepository.findAll();

        return roles
                .stream()
                .map(role -> modelMapper.map(role, RoleDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public RoleDTO findRoleById(Long id) {
        Optional<Role> role = roleRepository.findById(id);

        return modelMapper.map(role, RoleDTO.class);
    }

    @Override
    public RolesResponse findRoleByName(int pageNo, int pageSize, String sortBy, String orderBy, String name) throws ResourceNotFoundException {
        var sort = orderBy.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        var pageable = PageRequest.of(pageNo, pageSize, sort);
        var pages = roleRepository.findByName(name,pageable);

        if(pages.isEmpty() || pages.getContent().isEmpty()) {
            throw new ResourceNotFoundException("Role not found by " + name);
        }

        var roles = pages.getContent()
                .stream()
                .map(role -> modelMapper.map(role, RoleDTO.class))
                .collect(Collectors.toList());

        return RolesResponse.builder()
                .roles(roles)
                .pageNo(pageNo)
                .pageSize(pageSize)
                .last(pages.isLast())
                .build();
    }

    @Override
    public RoleDTO updateRole(RoleDTO roleDTO) throws ResourceNotFoundException {
        var role = roleRepository.findById(roleDTO.getId());
        if(role.isEmpty()) {
            throw new ResourceNotFoundException("Role Id is invalid to update Role.");
        }
        var updateRole = modelMapper.map(roleDTO, Role.class);
        updateRole= roleRepository.save(updateRole);

        return modelMapper.map(updateRole, RoleDTO.class);
    }

    @Override
    public void deleteRole(Long id) {

    }
}
