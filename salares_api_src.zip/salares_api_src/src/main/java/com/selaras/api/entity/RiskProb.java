package com.selaras.api.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "risk_probability")
public class RiskProb {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "risk_prob_code", nullable = false, length = 50)
    private String riskProbCode;

    @Column(name = "risk_probability", length = 50)
    private String riskProbability;

    @Column(name = "is_active", columnDefinition = "boolean DEFAULT true")
    private Boolean isActive;

    @Column(name = "created_by", length = 100)
    private String createdBy;

    @Column(name = "created_at", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime createdAt;

    @Column(name = "modified_by", length = 100)
    private String modifiedBy;

    @Column(name = "modified_at", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime modifiedAt;

    // @ManyToOne
    // @JoinColumn(name = "risk_code", referencedColumnName = "risk_code", nullable = false)
    // private RiskType riskType;
    // @Column(name = "risk_code")
    // private String risk_code;
}
