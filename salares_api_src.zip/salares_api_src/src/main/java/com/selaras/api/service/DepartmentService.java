package com.selaras.api.service;


import com.selaras.api.dto.DepartmensUsersRoleDTO;
import com.selaras.api.dto.DepartmentAddressUsersDTO;
import com.selaras.api.dto.DepartmentDTO;
import com.selaras.api.dto.ProjectDTO;
import java.util.List;

import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.responses.DepartmentsResponse;



public interface DepartmentService {

	DepartmentsResponse getDepartmentByName(int pageNo, int pageSize, String sortBy, String orderBy, String name) throws ResourceNotFoundException;

	DepartmentAddressUsersDTO createDepartment(DepartmentAddressUsersDTO departmentDTO);

	DepartmentDTO getDepartmentById(Long id) throws ResourceNotFoundException;

	DepartmentDTO updateDepartment(DepartmentDTO departmentDTO, Long id) throws ResourceNotFoundException, BadRequestException;

	List<DepartmentDTO> deleteDepartment(Long[] ids) throws ResourceNotFoundException ;

	ProjectDTO addProjcetToDepartment(Long id, ProjectDTO projectDTOReq) throws ResourceNotFoundException;

	void deleteProjectFromDepartment(Long id, Long projectId) throws ResourceNotFoundException;

	List<DepartmentDTO> getAllDepartments() throws ResourceNotFoundException;

	List<DepartmentAddressUsersDTO> getAllDepartmentsByAddressUsersDTO() throws ResourceNotFoundException;

	List<DepartmensUsersRoleDTO> getallDepartmensUsersRoleDTO(Long id) throws ResourceNotFoundException;

}
