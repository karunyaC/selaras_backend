package com.selaras.api.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.selaras.api.dto.RiskCategoryDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.service.RiskCategoryService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/risk-category")
@RequiredArgsConstructor
public class RiskCategoryController {

    private final RiskCategoryService riskCategoryService;

    @PostMapping
    public ResponseEntity<RiskCategoryDTO> createRiskCategory(@RequestBody RiskCategoryDTO riskCategoryDTO) {
        try {
            RiskCategoryDTO createdRiskCategory = riskCategoryService.createRiskCategory(riskCategoryDTO);
            return new ResponseEntity<>(createdRiskCategory, HttpStatus.CREATED);
        } catch (BadRequestException e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<RiskCategoryDTO> getRiskCategoryById(@PathVariable long id) {
        try {
            RiskCategoryDTO riskCategory = riskCategoryService.getById(id);
            return new ResponseEntity<>(riskCategory, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping
    public ResponseEntity<List<RiskCategoryDTO>> getAllRiskCategories() {
        List<RiskCategoryDTO> riskCategories = riskCategoryService.getall();
        return new ResponseEntity<>(riskCategories, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<RiskCategoryDTO> updateRiskCategory(
            @PathVariable long id, @RequestBody RiskCategoryDTO riskCategoryDTO) {
        try {
            RiskCategoryDTO updatedRiskCategory = riskCategoryService.updateRiskCategory(id, riskCategoryDTO);
            return new ResponseEntity<>(updatedRiskCategory, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteRiskCategory(@PathVariable long id) {
        try {
            String responseMessage = riskCategoryService.deleteRiskCategory(id);
            return new ResponseEntity<>(responseMessage, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }
}
