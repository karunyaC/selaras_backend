package com.selaras.api.responses;

import com.selaras.api.dto.DepartmentDTO;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class DepartmentsResponse {

	private List<DepartmentDTO> departments;
    private int pageNo;
    private int pageSize;
    private long totalElements;
    private int totalPages;
    private boolean last;
}
