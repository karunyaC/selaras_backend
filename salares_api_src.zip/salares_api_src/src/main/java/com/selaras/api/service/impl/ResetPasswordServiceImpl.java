package com.selaras.api.service.impl;

import com.selaras.api.entity.UserAccount;
import com.selaras.api.repository.UserAccountRepository;
import com.selaras.api.service.ResetPasswordService;
import com.selaras.api.service.UserAccountService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ResetPasswordServiceImpl implements ResetPasswordService {

    private final UserAccountService usersTypeService;


    private final AuthenticationManager authenticationManager;


    private final CustomUserDetailsService customUserDetailsService;


    private final UserAccountRepository userAccountRepository;


    private final   EmailService emailService;


    PasswordEncoder passwordEncoder;

    @Override
    public String generateResetToken(String email, HttpServletRequest request) {

        UserAccount userDetails = userAccountRepository.findByEmail(email);
        if (userDetails == null) {
            throw new IllegalArgumentException("No user found with this email.");
        }

        String token = UUID.randomUUID().toString();
        userDetails.setResetToken(token);
        userAccountRepository.save(userDetails);
        return emailService.sendResetToken(email, token, request);
    }

    @Override
    public String resetPassword(String token, String password) {
        UserAccount userDetails = userAccountRepository.findByResetToken(token);

        if (userDetails == null) {
            throw new IllegalArgumentException("Invalid reset token.");
        }

        userDetails.setPassword(passwordEncoder.encode(password));
        userDetails.setResetToken(null);
        userAccountRepository.save(userDetails);

        return "Password has been reset successfully";
    }

}
