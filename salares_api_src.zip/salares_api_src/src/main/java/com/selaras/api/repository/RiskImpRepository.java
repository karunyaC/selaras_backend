package com.selaras.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.selaras.api.entity.RiskImpact;

public interface RiskImpRepository extends JpaRepository<RiskImpact, Long>, JpaSpecificationExecutor<RiskImpact> {
    
}
