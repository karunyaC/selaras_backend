package com.selaras.api.dto;


import lombok.Data;

import java.io.Serializable;

@Data
public class SubDepartmentDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;
    private String subDeptName;
    private Long deptId;
    private String deptName;
}
