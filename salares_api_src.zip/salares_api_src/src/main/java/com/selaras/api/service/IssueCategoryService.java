package com.selaras.api.service;

import java.util.List;

import com.selaras.api.dto.IssueCategoryDTO;
import com.selaras.api.exception.ResourceNotFoundException;

public interface IssueCategoryService {
    
    IssueCategoryDTO createIssueCategory(IssueCategoryDTO issueCategory);

    IssueCategoryDTO getIssueCategoryById(Long id);

    List<IssueCategoryDTO> getAllIssueCategories() ;

    IssueCategoryDTO updateIssueCategory(Long id, IssueCategoryDTO issueCategory) throws ResourceNotFoundException;

    String deleteIssueCategory(Long id) throws ResourceNotFoundException;
}
