package com.selaras.api.service;

import java.util.List;

import com.selaras.api.entity.Rmk;

public interface RmkService {
    
    List<Rmk> getAllRmks();

    Rmk getRmkById(Integer id);

    Rmk createRmk(Rmk rmk);

    Rmk updateRmk(Integer id, Rmk rmk);

    void deleteRmk(Integer id);
}
