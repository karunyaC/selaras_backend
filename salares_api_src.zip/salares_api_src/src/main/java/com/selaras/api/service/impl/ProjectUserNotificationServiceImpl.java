package com.selaras.api.service.impl;

import com.selaras.api.dto.ProjectDTO;
import com.selaras.api.entity.*;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.repository.*;
import com.selaras.api.requests.ProjectNotificationsRequest;
import com.selaras.api.requests.UserNotificationRequest;
import com.selaras.api.responses.*;
import com.selaras.api.service.ProjectUserNotificationService;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProjectUserNotificationServiceImpl implements ProjectUserNotificationService {


    private final  PlatformRepository platformRepository;


    private final  AnnouncementToRepository announcementToRepository;


    private final PromotionCategoryRepository promotionCategoryRepository;


    private final UserNotificationSettingsRepository userNotificationSettingsRepository;


    private final  ProjectRepository projectRepository;


    private final  DepartmentRepository departmentRepository;


    private final ProjectUpdateNotificationsRepository projectUpdateNotificationsRepository;

    @Override
    public String saveUserNotification(UserNotificationRequest request) throws BadRequestException {
        validateSaveUserNotificationRequest(request);

        List<Platform> platform = platformRepository.findAllById(request.getPlatform());
        if (platform.isEmpty() || platform.size() != request.getPlatform().size()) {
            throw new BadRequestException("Invalid platform details");
        }

        List<AnnouncementTo> announcementTo = announcementToRepository.findAllById(request.getAnnouncementTo());
        if (announcementTo.isEmpty() || announcementTo.size() != request.getAnnouncementTo().size()) {
            throw new BadRequestException("Invalid Announcement To details");
        }

        Optional<PromotionCategory> promotionCategory = promotionCategoryRepository.findById(request.getPromotionCategoryId());
        if (!promotionCategory.isPresent()) {
            throw new BadRequestException("Promotion category not found");
        }

        String platformString = request.getPlatform().stream()
                .map(String::valueOf)
                .collect(Collectors.joining(","));

        String announcementToString = request.getAnnouncementTo().stream()
                .map(String::valueOf)
                .collect(Collectors.joining(","));

        UserNotificationSettings userNotificationSettings = userNotificationSettingsRepository.findByPromotionTitleAndPromotionCategoryAndDescriptionAndPlatformAndAnnouncementToAndPromotionScheduling(request.getPromotionTitle(),
                promotionCategory.get(), request.getDescription(), platformString, announcementToString, LocalDateTime.parse(request.getPromotionScheduling(), DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a").ISO_DATE_TIME));

        if (userNotificationSettings == null) {
            userNotificationSettings = new UserNotificationSettings();
            userNotificationSettings.setCreatedBy("SYSTEM");
            userNotificationSettings.setStatus("Send");
        } else {
            userNotificationSettings.setStatus(request.getStatus());
        }
        

        userNotificationSettings.setDescription(request.getDescription());
        userNotificationSettings.setPlatform(platformString);
        userNotificationSettings.setAnnouncementTo(announcementToString);
        userNotificationSettings.setPromotionTitle(request.getPromotionTitle());
        userNotificationSettings.setDescription(request.getDescription());
        userNotificationSettings.setPromotionCategory(promotionCategory.get());
        userNotificationSettings.setPromotionScheduling(LocalDateTime.parse(request.getPromotionScheduling(), DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a").ISO_DATE_TIME));

        userNotificationSettingsRepository.save(userNotificationSettings);

        return "Project User Notification saved successfully";
    }

    @Override
    public List<UserNotificationResponse> getAllUserNotification() {
        List<UserNotificationSettings> settings = userNotificationSettingsRepository.findAll();
        List<UserNotificationResponse> responses = new ArrayList<>();

        settings.forEach(s -> {
            UserNotificationResponse res = new UserNotificationResponse();
            res.setDescription(s.getDescription());
            List<String> platforms = Arrays.asList(s.getPlatform().split(",")).stream().map(String::valueOf).collect(Collectors.toList());
            List<PlatformResponse> platformResponses = new ArrayList<>();
            platforms.forEach(p -> {
                Optional<Platform> platform = platformRepository.findById(Long.valueOf(p));
                if(platform.isPresent()) {
                    PlatformResponse pres = new PlatformResponse();
                    pres.setId(platform.get().getId());
                    pres.setPlatform(platform.get().getPlatform());
                    platformResponses.add(pres);
                }
            });
            res.setPlatform(platformResponses);

            List<String> announcementTo = Arrays.asList(s.getAnnouncementTo().split(",")).stream().map(String::valueOf).collect(Collectors.toList());
            List<AnnouncementToResponse> announcementToResponses = new ArrayList<>();
            announcementTo.forEach(a -> {
                Optional<AnnouncementTo> announcement = announcementToRepository.findById(Long.valueOf(a));
                if(announcement.isPresent()) {
                    AnnouncementToResponse ares = new AnnouncementToResponse();
                    ares.setId(announcement.get().getId());
                    ares.setAnnouncementTo(announcement.get().getPlatform());
                    announcementToResponses.add(ares);
                }
            });


            res.setAnnouncementTo(announcementToResponses);
            res.setPromotionTitle(s.getPromotionTitle());
            res.setPromotionScheduling(s.getPromotionScheduling().format(DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a").ISO_DATE_TIME));
            res.setPromotionCategory(new PromotionCategoryResponse(s.getPromotionCategory().getId(), s.getPromotionCategory().getCategory()));
            res.setId(s.getId());
            res.setStatus(s.getStatus());
            responses.add(res);
        });

        return responses;
    }

    @Override
    public String saveProjectNotification(ProjectNotificationsRequest request) throws BadRequestException {
        validateProjectNotificationsRequest(request);
        Optional<Project> project = projectRepository.findById(request.getProjectId());
        if (!project.isPresent()) {
            throw new BadRequestException("No project found with given details");
        }

        Optional<Department> department = departmentRepository.findById(request.getAgencyId());
        if (!department.isPresent()) {
            throw new BadRequestException("No Agency found with given details");
        }

        ProjectUpdateNotifications projectUpdateNotifications = projectUpdateNotificationsRepository.findByProjectAndDepartment(project.get(), department.get());

        if (projectUpdateNotifications == null) {
            projectUpdateNotifications = new ProjectUpdateNotifications();
            projectUpdateNotifications.setProject(project.get());
            projectUpdateNotifications.setDepartment(department.get());
        }
        projectUpdateNotifications.setNotificationPeriod(request.getNotificationPeriod());

        projectUpdateNotificationsRepository.save(projectUpdateNotifications);
        return "Project Update Notifications saved successfully";
    }

    @Override
    public List<ProjectUpdateNotificationsResponse> getAllProjectNotification() {
        List<ProjectUpdateNotifications> notifications = projectUpdateNotificationsRepository.findAll();
        List<ProjectUpdateNotificationsResponse> responses = new ArrayList<>();

        notifications.forEach(notify -> {
            ProjectUpdateNotificationsResponse res = new ProjectUpdateNotificationsResponse();
            res.setProject(notify.getProject().getCodeTitle());
            res.setProjectId(notify.getProject().getId());
            res.setAgency(notify.getDepartment().getName());
            res.setAgencyId(notify.getDepartment().getId());
            res.setNotificationPeriod(notify.getNotificationPeriod());
            res.setId(notify.getId());
            responses.add(res);
        });
        return responses;
    }

    private void validateProjectNotificationsRequest(ProjectNotificationsRequest request) throws BadRequestException {
        if (request.getProjectId() == 0 || request.getAgencyId() == 0 || request.getNotificationPeriod() == null || request.getNotificationPeriod().trim().isEmpty()) {
            throw new BadRequestException("Invalid input received");
        }
    }

    private void validateSaveUserNotificationRequest(UserNotificationRequest request) throws BadRequestException {
        if (request.getDescription() == null || request.getDescription().trim().isEmpty()
                || request.getPlatform() == null || request.getPlatform().isEmpty()
                || request.getAnnouncementTo() == null || request.getAnnouncementTo().isEmpty()
                || request.getPromotionTitle() == null || request.getPromotionTitle().trim().isEmpty()
                || request.getPromotionScheduling() == null
                || LocalDateTime.parse(request.getPromotionScheduling(), DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a").ISO_DATE_TIME).isBefore(LocalDateTime.now())
                || request.getPromotionCategoryId() == null
                || request.getDescription() == null || request.getDescription().trim().isEmpty()) {
            throw new BadRequestException("Invalid input data provided");
        }
    }

    @Override
    public List<Platform> getallPlatform() {
        List<Platform> platforms=platformRepository.findAll();
        return platforms;
    }

    @Override
    public List<AnnouncementTo> getallannouncement() {
        List<AnnouncementTo>  announcementTos=announcementToRepository.findAll();
        return announcementTos;
    }

    @Override
    public List<PromotionCategory> getallPromotion() {
        List<PromotionCategory> promotionCategories=promotionCategoryRepository.findAll();
        return promotionCategories;  
    }

    @Override
    public List<ProjectDTO> getallProjects() {
        List<Project> projects=projectRepository.findAll();
        
        return projects.stream().map(x -> {
            ProjectDTO p = new ProjectDTO();
            p.setId(x.getId());
            p.setActive(x.getActive());
            p.setCodeTitle(x.getCodeTitle());
            p.setCreatedAt(x.getCreatedAt());
            p.setNumber(x.getNumber());
            p.setModifiedBy(x.getModifiedBy());
            p.setModifiedAt(x.getModifiedAt());
            return p;
        }).collect(Collectors.toList());
    }
    

}
