package com.selaras.api.service.impl;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class UserAccountDeptDTO {
    private Long id;
    private String name;
    private String email;
    private String password;
    private String kpNumber;
    private Long domainId;
    private Boolean systemGeneratedPassword;
    private Boolean changePasswordOnFirstLogin;
    private Boolean emailProofOfAuthentication;
    private Long departmentId;
    private String Agenct_name;
    private Long sectionId;
    private String position;
    private String officialPhone;
    private String mobilePhone;
    private Long typeOfDepartmentAdministrator;
    private Boolean active;
    private String createdBy;
    private LocalDateTime createdAt;
    private String modifiedBy;
    private LocalDateTime modifiedAt;
}

    

