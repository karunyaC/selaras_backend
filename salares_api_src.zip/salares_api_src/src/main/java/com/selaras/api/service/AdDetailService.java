package com.selaras.api.service;

import java.util.List;

import com.selaras.api.dto.ADDetailsDTO;
import com.selaras.api.dto.RiskTypeDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.requests.CompanySaveRequest;
import com.selaras.api.responses.CompanyResponse;

public interface AdDetailService {
    List<ADDetailsDTO> getAllAdDetails();
    String updateById(ADDetailsDTO adDetailsDTO,long id);
    String bulkDeletes(List<Long> ids);
    ADDetailsDTO createAdDetail(ADDetailsDTO adDetailsDTO);
    ADDetailsDTO getAdDetailById(Long id);
    ADDetailsDTO updateAdDetail(Long id, ADDetailsDTO adDetail);
    void deleteAdDetail(Long id);  
}
