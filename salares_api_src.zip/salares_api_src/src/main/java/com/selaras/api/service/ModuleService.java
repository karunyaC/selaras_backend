package com.selaras.api.service;

import com.selaras.api.dto.ModuleAccessLevelDTO;
import com.selaras.api.dto.ModuleDTO;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface ModuleService {

    List<ModuleDTO> getAllModules();

    ModuleDTO getModuleById(Long id);

    ModuleDTO createModule(ModuleDTO module);

    void deleteModule(Long id);

    ModuleAccessLevelDTO addAccessLevelToModule(Long moduleId, Long accessLevelId, String additionalInfo);

    String uploadLogo(Long moduleId, MultipartFile image);

    byte[] downloadLogo(Long moduleId);
}
