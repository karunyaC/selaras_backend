package com.selaras.api.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdDetailResponse {
    private int id;
    private String domainName;
    private String port;
    private String groupBase;
    private boolean isActive;
}
