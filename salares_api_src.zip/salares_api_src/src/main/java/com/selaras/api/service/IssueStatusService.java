package com.selaras.api.service;

import java.util.List;

import com.selaras.api.dto.IssueStatusDTO;
import com.selaras.api.exception.ResourceNotFoundException;

public interface IssueStatusService {
    
    IssueStatusDTO createIssueStatusDTO(IssueStatusDTO IssueStatusDTO);

    IssueStatusDTO getIssueStatusDTOById(Long id) throws ResourceNotFoundException;

    List<IssueStatusDTO> getAllIssueStatusDTOes();

    IssueStatusDTO updateIssueStatusDTO(Long id, IssueStatusDTO IssueStatusDTO) throws ResourceNotFoundException;

    String deleteIssueStatusDTO(Long id) throws ResourceNotFoundException;
}
