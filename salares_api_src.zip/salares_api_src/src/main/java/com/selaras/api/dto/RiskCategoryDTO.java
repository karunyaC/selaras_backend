package com.selaras.api.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class RiskCategoryDTO implements Serializable{
    private static final long serialVersionUID = 1L;
    
    private Long id;

    private String riskCatCode;

    private String riskCategory;

    // private String riskImpact_code;
    
    private Boolean isActive;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;
    
}
