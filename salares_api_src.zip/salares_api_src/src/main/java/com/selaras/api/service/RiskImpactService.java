package com.selaras.api.service;

import java.util.List;

import com.selaras.api.dto.RiskImpactDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;

public interface RiskImpactService {
  RiskImpactDTO   createRiskImpact(RiskImpactDTO riskProbDTO) throws BadRequestException;
  RiskImpactDTO getById(long id) throws ResourceNotFoundException;
    List<RiskImpactDTO> getall();
    RiskImpactDTO updateRiskImpact(long id,RiskImpactDTO riskProbDTO) throws ResourceNotFoundException;
    String deleteRiskImpact(long id) throws ResourceNotFoundException;
}
