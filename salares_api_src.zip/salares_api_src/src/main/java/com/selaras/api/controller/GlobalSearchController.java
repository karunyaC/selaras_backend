package com.selaras.api.controller;

import com.selaras.api.requests.GlobalSearchRequest;
import com.selaras.api.responses.GlobalSearchResponse;
import com.selaras.api.service.GlobalSearchService;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class GlobalSearchController {
    private final GlobalSearchService globalSearchService;

    @PostMapping("/global/search")
    public ResponseEntity<GlobalSearchResponse> globalSearch(@RequestBody GlobalSearchRequest searchRequest) {
        GlobalSearchResponse results = globalSearchService.search(searchRequest);
        return ResponseEntity.ok(results);
    }
}
