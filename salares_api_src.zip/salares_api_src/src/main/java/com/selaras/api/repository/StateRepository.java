package com.selaras.api.repository;

import com.selaras.api.entity.State;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface StateRepository extends JpaRepository<State, Long>, JpaSpecificationExecutor<State> {

}