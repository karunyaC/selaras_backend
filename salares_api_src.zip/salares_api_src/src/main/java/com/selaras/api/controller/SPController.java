package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.requests.SpSaveDTO;
import com.selaras.api.service.SpService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
    @RestController
    @RequestMapping("/api")
    @RequiredArgsConstructor
    public class SPController {

        private final SpService spService;

        @Operation(summary = "Save or update SP", description = "Save or update SP")
        @ApiResponse(responseCode = "200", description = "OK")
        @AuditTrail(recordType = "Digitization Strategic Plan", action = "Save or update SP", presentValue = "Save or update SP")
        @PostMapping("/sp")
        public ResponseEntity<?> saveSp(@RequestBody SpSaveDTO saveDTO) {
            return ResponseEntity.ok().body(spService.saveSp(saveDTO));
        }

        @Operation(summary = "Get all SP", description = "Get all SP")
        @ApiResponse(responseCode = "200", description = "OK")
        @AuditTrail(recordType = "Digitization Strategic Plan", action = "Get all SP", presentValue = "Get all SP")
        @GetMapping("/sp")
        public ResponseEntity<?> getAllsp() {
            return ResponseEntity.ok().body(spService.getAllsp());
        }

        @Operation(summary = "Search SP by code", description = "Search SP by code")
        @ApiResponse(responseCode = "200", description = "OK")
        @AuditTrail(recordType = "Digitization Strategic Plan", action = "Search SP by code", presentValue = "Search SP by code")
        @GetMapping("/sp/{code}")
        public ResponseEntity<?> getspByCode(@PathVariable String code) {
            return ResponseEntity.ok().body(spService.getSpByCode(code));
        }

        @Operation(summary = "Delete SP", description = "Delete SP")
        @ApiResponse(responseCode = "200", description = "OK")
        @AuditTrail(recordType = "Digitization Strategic Plan", action = "Delete SP by code", presentValue = "Delete SP by code")
        @DeleteMapping("/sp/{code}")
        public ResponseEntity<?> deleteSpByCode(@PathVariable String code) throws ResourceNotFoundException {
            return ResponseEntity.ok().body(spService.deleteSpByCode(code));
        }
    }

