package com.selaras.api.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "sp_overview")
public class SPOverview {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer rowId;

    @Column(unique = true, nullable = false)
    private String spCode;

    private String spPlanCode;
    private LocalDate spStartyear;
    private LocalDate spEndyear;
    private Integer spNumCores;
    private Integer spNameCores;
    private Integer spNumStrategies;
    private String spNameStrategies;
    private boolean statusLookup;
    private LocalDateTime createdAt;
    private LocalDateTime modifiedAt;

    @OneToMany(mappedBy = "spOverview", cascade = CascadeType.ALL)
    private List<SPCore> cores;
}
