package com.selaras.api.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Data;

@Data
public class RiskImpactDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Long id;

    private String riskImpCode;

    private String riskImpact;
    
    // private String riskProb_code;
    
    private Boolean isactive;  
    
    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;
}
