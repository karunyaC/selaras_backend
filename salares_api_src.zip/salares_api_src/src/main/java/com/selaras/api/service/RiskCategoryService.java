package com.selaras.api.service;

import java.util.List;

import com.selaras.api.dto.RiskCategoryDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;

public interface RiskCategoryService {
    RiskCategoryDTO   createRiskCategory(RiskCategoryDTO riskProbDTO) throws BadRequestException;
    RiskCategoryDTO getById(long id) throws ResourceNotFoundException;
    List<RiskCategoryDTO> getall();
    RiskCategoryDTO updateRiskCategory(long id,RiskCategoryDTO riskProbDTO) throws ResourceNotFoundException;
    String deleteRiskCategory(long id) throws ResourceNotFoundException;
}
