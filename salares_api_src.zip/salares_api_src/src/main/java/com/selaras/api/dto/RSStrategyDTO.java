package com.selaras.api.dto;

import java.util.Date;

public class RSStrategyDTO {
    private Long rowId;
    private String rsFocusId;
    private String rsCode;
    private String rsPlanCode;
    private String rsStratId;
    private String rsFocusPreferredName;
    private String rsFocusPreferredCode;
    private Date createdAt;
    private Date modifiedAt;
}
