package com.selaras.api.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.Hibernate;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class ModuleAccessLevelId implements Serializable {
    private static final long serialVersionUID = 7491113876580188499L;
    @Column(name = "module_id", nullable = false)
    private Integer moduleId;

    @Column(name = "access_level_id", nullable = false)
    private Integer accessLevelId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        ModuleAccessLevelId entity = (ModuleAccessLevelId) o;
        return Objects.equals(this.accessLevelId, entity.accessLevelId) &&
                Objects.equals(this.moduleId, entity.moduleId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accessLevelId, moduleId);
    }

}