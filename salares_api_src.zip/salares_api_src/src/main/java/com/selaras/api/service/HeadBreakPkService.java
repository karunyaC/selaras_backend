package com.selaras.api.service;

import com.selaras.api.dto.HeadBreakPkDTO;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.exception.ResourceNotFoundRunTimeException;

import java.util.List;

public interface HeadBreakPkService {
    HeadBreakPkDTO saveHeadBreakPk( HeadBreakPkDTO headBreakPkDTO ) throws ResourceNotFoundException;

    HeadBreakPkDTO updateHeadBreak( HeadBreakPkDTO headBreakPkDTO ) throws ResourceNotFoundException;

    List< HeadBreakPkDTO > getAllHeadBreakPk();

    List<HeadBreakPkDTO> getdepartmentBreakPkbyid(Long id) throws ResourceNotFoundRunTimeException;

    List<HeadBreakPkDTO> deleteHeadBreakPk( Long[] id ) throws ResourceNotFoundException;

}
