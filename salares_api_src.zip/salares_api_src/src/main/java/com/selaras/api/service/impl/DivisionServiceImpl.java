package com.selaras.api.service.impl;

import com.selaras.api.dto.DivisionDTO;
import com.selaras.api.entity.Division;
import com.selaras.api.exception.ConfigDataNotFoundException;
import com.selaras.api.repository.DivisionRepository;
import com.selaras.api.service.DivisionService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Service
public class DivisionServiceImpl implements DivisionService {

    private final DivisionRepository divisionRepository;

    private final ModelMapper mapper;

    @Override
    public DivisionDTO saveDivision( DivisionDTO request ) {

        Division division = mapper.map( request, Division.class );
        division.setCreatedBy( request.getCreatedBy() != null ? request.getCreatedBy() : "SYSTEM" );
        Division savedObject = divisionRepository.save( division );
        return mapper.map( savedObject, DivisionDTO.class );
    }

    @Override
    public DivisionDTO updateDivision( DivisionDTO request ) {

        Division foundObject = findById( request.getId() );
        if ( foundObject != null ) {
            Division division = mapper.map( request, Division.class );
            Division savedObject = divisionRepository.save( division );
            return mapper.map( savedObject, DivisionDTO.class );
        }
        return null;
    }

    @Override
    public List< DivisionDTO > getAllDivision() {

        List< Division > divisionList = divisionRepository.findAll();
        List< DivisionDTO > dtoList = new ArrayList<>();

        if ( divisionList.isEmpty() ) {
            return null;
        } else {
            for ( Division value : divisionList ) {
                DivisionDTO dto = mapper.map( value, DivisionDTO.class );
                dtoList.add( dto );
            }
            return dtoList;
        }
    }

    @Override
    public void deleteByDivisionId( Long id ) {
        // Validating that the Record is Present in DB
        Division foundObject = findById( id );
        if ( foundObject != null ) {
            //If record is Present then setting the Active Status to false
            foundObject.setActive( false );
            //Update DB
            Division savedObject = divisionRepository.save( foundObject );
        }
    }

    private Division findById( Long id ) {
        return divisionRepository
                .findById( id )
                .orElseThrow( () -> new ConfigDataNotFoundException( "No Such Data found !!! " ) );
    }
}
