package com.selaras.api.service;

import java.util.List;

import com.selaras.api.dto.IssuePriorityDTO;
import com.selaras.api.exception.ResourceNotFoundException;

public interface IssuePriorityService {
    IssuePriorityDTO createIssuePriority(IssuePriorityDTO issuePriorityDTO);
    IssuePriorityDTO getIssuePriorityById(Long id) throws ResourceNotFoundException;
    List<IssuePriorityDTO> getAllIssuePriorities();
    IssuePriorityDTO updateIssuePriority(Long id, IssuePriorityDTO issuePriorityDTO) throws ResourceNotFoundException;
    String deleteIssuePriority(Long id) throws ResourceNotFoundException;
}
