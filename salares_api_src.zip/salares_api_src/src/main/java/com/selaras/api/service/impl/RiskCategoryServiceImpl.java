package com.selaras.api.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.selaras.api.dto.RiskCategoryDTO;
import com.selaras.api.entity.RiskCategory;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.RiskCatRepository;
import com.selaras.api.service.RiskCategoryService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RiskCategoryServiceImpl implements RiskCategoryService {

    private final RiskCatRepository riskCatRepository;
    private final ModelMapper modelMapper;

    @Override
    @Transactional
    public RiskCategoryDTO createRiskCategory(RiskCategoryDTO riskProbDTO) throws BadRequestException {
        if (riskProbDTO.getRiskCatCode() == null || riskProbDTO.getRiskCatCode().isEmpty()) {
            throw new BadRequestException("Risk category code cannot be null or empty");
        }

        // Map DTO to Entity
        RiskCategory riskCategory = modelMapper.map(riskProbDTO, RiskCategory.class);
        riskCategory.setCreatedAt(LocalDateTime.now());
        riskCategory.setModifiedAt(LocalDateTime.now());

        // Save to the database
        RiskCategory savedRiskCategory = riskCatRepository.save(riskCategory);
        return modelMapper.map(savedRiskCategory, RiskCategoryDTO.class);
    }

    @Override
    public RiskCategoryDTO getById(long id) throws ResourceNotFoundException {
        RiskCategory riskCategory = riskCatRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RiskCategory not found with id: " + id));
        return modelMapper.map(riskCategory, RiskCategoryDTO.class);
    }

    @Override
    @Transactional
    public RiskCategoryDTO updateRiskCategory(long id, RiskCategoryDTO riskProbDTO) throws ResourceNotFoundException {
        RiskCategory existingRiskCategory = riskCatRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RiskCategory not found with id: " + id));

        // Update fields
        existingRiskCategory.setRiskCatCode(riskProbDTO.getRiskCatCode());
        existingRiskCategory.setRiskCategory(riskProbDTO.getRiskCategory());
        existingRiskCategory.setIsActive(riskProbDTO.getIsActive());
        existingRiskCategory.setModifiedAt(LocalDateTime.now());
        existingRiskCategory.setModifiedBy(riskProbDTO.getModifiedBy());

        // Save updated entity
        RiskCategory updatedRiskCategory = riskCatRepository.save(existingRiskCategory);
        return modelMapper.map(updatedRiskCategory, RiskCategoryDTO.class);
    }

    @Override
    @Transactional
    public String deleteRiskCategory(long id) throws ResourceNotFoundException {
        RiskCategory existingRiskCategory = riskCatRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RiskCategory not found with id: " + id));

        // Mark as inactive instead of deleting
        existingRiskCategory.setIsActive(false);
        riskCatRepository.save(existingRiskCategory);

        return "RiskCategory with id " + id + " has been marked as inactive.";
    }

    @Override
    public List<RiskCategoryDTO> getall() {
        List<RiskCategory> riskCategories = riskCatRepository.findAll();
        return riskCategories.stream()
                .map(riskCategory -> modelMapper.map(riskCategory, RiskCategoryDTO.class))
                .toList();
    }
}
