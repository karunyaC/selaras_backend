package com.selaras.api.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.selaras.api.dto.IssueImpactDTO;
import com.selaras.api.entity.IssueImpact;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.IssueImpRepository;
import com.selaras.api.service.IssueImpactService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class IssueImpactServiceImpl implements IssueImpactService {

    private final IssueImpRepository issueImpactRepository;
    private final ModelMapper modelMapper;

    @Override
    public IssueImpactDTO createIssueImpact(IssueImpactDTO issueImpactDTO) {
        IssueImpact issueImpact = modelMapper.map(issueImpactDTO, IssueImpact.class);
        IssueImpact savedIssueImpact = issueImpactRepository.save(issueImpact);
        return modelMapper.map(savedIssueImpact, IssueImpactDTO.class);
    }

    @Override
    public IssueImpactDTO getIssueImpactById(Long id) throws ResourceNotFoundException {
        IssueImpact issueImpact = issueImpactRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("IssueImpact not found with id " + id));
        return modelMapper.map(issueImpact, IssueImpactDTO.class);
    }

    @Override
    public List<IssueImpactDTO> getAllIssueImpacts(){
        List<IssueImpact> issueImpacts = issueImpactRepository.findAll();
        if (issueImpacts == null || issueImpacts.isEmpty()) {
            return List.of();
        }
        List<IssueImpactDTO> issueImpactDTOs = new ArrayList<>();
        
        for (IssueImpact issueImpact : issueImpacts) {
            issueImpactDTOs.add(modelMapper.map(issueImpact, IssueImpactDTO.class));
        }
        return issueImpactDTOs.isEmpty() ? List.of() : issueImpactDTOs;
    }

    @Override
    public IssueImpactDTO updateIssueImpact(Long id, IssueImpactDTO issueImpactDTO) throws ResourceNotFoundException {
        IssueImpact issueImpact = issueImpactRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("IssueImpact not found with id " + id));

        issueImpact.setIssueImpCode(issueImpactDTO.getIssueImpCode());
        issueImpact.setIssueImpact(issueImpactDTO.getIssueImpact());
        issueImpact.setCreatedBy(issueImpactDTO.getCreatedBy());
        issueImpact.setModifiedBy(issueImpactDTO.getModifiedBy());

        IssueImpact updatedIssueImpact = issueImpactRepository.save(issueImpact);
        return modelMapper.map(updatedIssueImpact, IssueImpactDTO.class);
    }

    @Override
    public String deleteIssueImpact(Long id) throws ResourceNotFoundException {
        IssueImpact issueImpact = issueImpactRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("IssueImpact not found with id " + id));

        issueImpact.setIsActive(false);
        issueImpactRepository.save(issueImpact);
        return "IssueImpact with id " + id + " has been deactivated.";
    }
}
