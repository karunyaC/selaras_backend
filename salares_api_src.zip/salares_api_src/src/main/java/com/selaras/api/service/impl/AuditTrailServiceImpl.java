package com.selaras.api.service.impl;

import com.selaras.api.entity.AuditTrail;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.repository.AuditTrailRepository;
import com.selaras.api.requests.AuditTrailRequest;
import com.selaras.api.responses.AuditTrailResponse;
import com.selaras.api.service.AuditTrailService;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AuditTrailServiceImpl implements AuditTrailService {


   private final AuditTrailRepository auditTrailRepository;

    @Override
    public String saveAuditTrail(AuditTrailRequest request) throws BadRequestException {
        validateAuditTrail(request);
        AuditTrail trail = new AuditTrail();
        trail.setAction(request.getAction());
        trail.setUserEmail(request.getUserEmail());
        trail.setAction(request.getAction());
        trail.setRecordType(request.getRecordType());
        auditTrailRepository.save(trail);
        return "Audit trail recorded successfully";
    }

    @Override
    public List<AuditTrailResponse> getAllAuditTrail() {
        List<AuditTrail> trailList = auditTrailRepository.findAll();
        List<AuditTrailResponse> response = new ArrayList<>();
        trailList.forEach(trail -> {
            AuditTrailResponse res = new AuditTrailResponse();
            res.setId(trail.getId());
            res.setAction(trail.getAction());
            res.setUserEmail(trail.getUserEmail());
            res.setRecordType(trail.getRecordType());
            res.setCreatedAt(trail.getCreatedAt().format(DateTimeFormatter.ofPattern("yyyy-MM-dd, hh:mma")));
            response.add(res);
        });

        return response;
    }

    private void validateAuditTrail(AuditTrailRequest request) throws BadRequestException {
        if (request.getAction() == null || request.getAction().trim().isEmpty() || request.getUserEmail() == null || request.getUserEmail().trim().isEmpty() || request.getRecordType() == null || request.getRecordType().trim().isEmpty()) {
            throw new BadRequestException("Invalid input received");
        }
    }
}
