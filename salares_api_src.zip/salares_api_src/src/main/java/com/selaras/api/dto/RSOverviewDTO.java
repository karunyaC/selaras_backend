package com.selaras.api.dto;

import java.util.Date;

public class RSOverviewDTO {
    private Long rowId;

    private String rsCode;

    private String rsPlanCode;

    private Date rsStartyear;

    private Date rsEndyear;

    private Integer rsNumStrategies;

    private String rsNameStrategies;

    private Integer rsNumFocus;

    private boolean statusLookup;

    private Date createdAt;

    private Date modifiedAt;   
}
