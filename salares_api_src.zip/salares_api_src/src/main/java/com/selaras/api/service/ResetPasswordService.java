package com.selaras.api.service;

import jakarta.servlet.http.HttpServletRequest;

public interface ResetPasswordService {

	String generateResetToken(String email, HttpServletRequest request);

	String resetPassword(String token, String password);
}
