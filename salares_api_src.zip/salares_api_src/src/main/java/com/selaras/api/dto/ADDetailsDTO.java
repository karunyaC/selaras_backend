package com.selaras.api.dto;

import java.time.LocalDateTime;

public class ADDetailsDTO {
    private Long row_id;
    private String domainName;
    private String port;
    private String groupBase;
    private boolean isActive;
    private LocalDateTime createdAt;
    private String createdBy;
    private LocalDateTime modifiedAt;
    private String modifiedBy;
}
