package com.selaras.api.service.impl;

import com.selaras.api.dto.StateDTO;
import com.selaras.api.entity.State;
import com.selaras.api.repository.StateRepository;
import com.selaras.api.service.StateService;

import lombok.RequiredArgsConstructor;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StateServiceImpl implements StateService {


    private final StateRepository stateRepository;


    private final ModelMapper modelMapper;

    @Override
    public List<StateDTO> getStates() {
        List<State> states = stateRepository.findAll();

       return states
                .stream()
                .map(state -> modelMapper.map(state, StateDTO.class))
                .collect(Collectors.toList());
    }
}
