package com.selaras.api.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class HeadBreakPkDTO {

    private Long id;

    private String pkValue;

    private String projectCodeTitle;

    private Integer department_id;

    private Boolean active;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;
}
