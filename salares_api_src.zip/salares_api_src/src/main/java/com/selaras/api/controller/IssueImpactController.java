package com.selaras.api.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.selaras.api.dto.IssueImpactDTO;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.service.IssueImpactService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/issueImpacts")
@RequiredArgsConstructor
public class IssueImpactController {

    private final IssueImpactService issueImpactService;

    @PostMapping
    public ResponseEntity<IssueImpactDTO> createIssueImpact(@RequestBody IssueImpactDTO issueImpactDTO) {
        IssueImpactDTO createdImpact = issueImpactService.createIssueImpact(issueImpactDTO);
        return ResponseEntity.status(201).body(createdImpact);
    }

    @GetMapping("/{id}")
    public ResponseEntity<IssueImpactDTO> getIssueImpactById(@PathVariable Long id) throws ResourceNotFoundException {
        IssueImpactDTO issueImpact = issueImpactService.getIssueImpactById(id);
        return ResponseEntity.ok(issueImpact);
    }

    @GetMapping
    public ResponseEntity<List<IssueImpactDTO>> getAllIssueImpacts() throws ResourceNotFoundException{
        List<IssueImpactDTO> issueImpacts = issueImpactService.getAllIssueImpacts();
        if (issueImpacts.isEmpty()) {
            return ResponseEntity.ok().body(List.of()); // Return an empty list if no impacts found
        }
        return ResponseEntity.ok(issueImpacts);
    }

    @PutMapping("/{id}")
    public ResponseEntity<IssueImpactDTO> updateIssueImpact(
            @PathVariable Long id,
            @RequestBody IssueImpactDTO issueImpactDTO) throws ResourceNotFoundException {
        IssueImpactDTO updatedImpact = issueImpactService.updateIssueImpact(id, issueImpactDTO);
        return ResponseEntity.ok(updatedImpact);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteIssueImpact(@PathVariable Long id) throws ResourceNotFoundException {
        String responseMessage = issueImpactService.deleteIssueImpact(id);
        return ResponseEntity.ok(responseMessage);
    }
}
