package com.selaras.api.repository;

import com.selaras.api.entity.HeadBreakPk;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface HeadBreakPkRepository extends JpaRepository< HeadBreakPk, Long > {
    List<HeadBreakPk> findAllByDepartmentId(Integer departmentId);
}
