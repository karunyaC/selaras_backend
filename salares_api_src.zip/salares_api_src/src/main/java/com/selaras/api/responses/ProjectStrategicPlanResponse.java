package com.selaras.api.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectStrategicPlanResponse {

    private int id;
    private String startYear;
    private String endYear;
    private int noOfCores;
    private String coreName;
    private boolean status;
    private String code;
    private String createdAt;
}
