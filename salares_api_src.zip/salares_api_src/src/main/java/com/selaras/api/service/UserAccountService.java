package com.selaras.api.service;

import com.selaras.api.dto.UserAccountDTO;
import com.selaras.api.entity.UserAccount;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.service.impl.UserAccountDeptDTO;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface UserAccountService {
	UserAccountDTO registerUser(UserAccountDTO userAccountDTO);

	List<UserAccount> getAllUsers();

	List<UserAccountDeptDTO> getAllUserDept();


	UserAccountDTO addUser(UserAccountDTO userAccountDTO);

	UserAccountDTO updateUser(Long id, UserAccountDTO userAccountDTO) throws ResourceNotFoundException;

	void deleteUser(Long id) throws ResourceNotFoundException;

	UserAccountDTO getUserDetails(Long id) throws ResourceNotFoundException;
	
	Page<UserAccountDTO> searchUsersByName(String name, Pageable pageable);

	Page<UserAccountDTO> getAllUsers(UserAccount filter, Pageable pageable);

    List<UserAccountDTO> getAllSystemUsers();

	UserAccountDTO saveOrgUser(UserAccountDTO userAccountDTO);
}
