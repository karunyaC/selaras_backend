package com.selaras.api.service;

import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.requests.HelpdeskLogRequest;
import com.selaras.api.requests.HelpdeskRequest;
import com.selaras.api.requests.HelpdeskStatusUpdateRequest;

public interface HelpdeskService {
    String saveHelpdeskWithFiles(HelpdeskRequest request);

    String saveHelpdeskLog(HelpdeskLogRequest request) throws ResourceNotFoundException;

    String updateStatus(HelpdeskStatusUpdateRequest request) throws ResourceNotFoundException, BadRequestException;

    Object getAllHelpDeskTickets();
}
