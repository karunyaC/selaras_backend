package com.selaras.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.selaras.api.entity.SPStrategy;

@Repository
public interface SPStrategyRepository extends JpaRepository<SPStrategy, Integer>{
    List<SPStrategy> findBySpOverviewSpCode(String spCode);
    List<SPStrategy> findBySpCoreSpCoreId(String spCoreId);
    SPStrategy findBySpStratId(String spStratId);

    SPStrategy findBySpStratPreferredName(String strategyName);

}
