package com.selaras.api.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "strategic_plan")
public class StrategicPlan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "code", nullable = false, length = 50)
    private String code;

    @Column(name = "start_year")
    private LocalDateTime startYear;

    @Column(name = "end_year")
    private LocalDateTime endYear;

    @Column(name = "no_of_cores")
    private Integer noOfCores;

    @Column(name = "core_name")
    private String coreName;

    @ColumnDefault("true")
    @Column(name = "active")
    private Boolean active;

    @Column(name = "created_by", length = 100)
    private String createdBy;

    @ColumnDefault("CURRENT_TIMESTAMP")
    @Column(name = "created_at")
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column(name = "modified_by", length = 100)
    private String modifiedBy;

    @ColumnDefault("CURRENT_TIMESTAMP")
    @Column(name = "modified_at")
    @UpdateTimestamp
    private LocalDateTime modifiedAt;

}