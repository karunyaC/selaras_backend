package com.selaras.api.repository;

import com.selaras.api.entity.PasswordRules;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface PasswordRulesRepository extends JpaRepository<PasswordRules, Long>, JpaSpecificationExecutor<PasswordRules> {

    PasswordRules findByRuleName(String ruleName);

    PasswordRules findByRuleNameAndSecurityType(String ruleName, String securityType);

    List<PasswordRules> findAllBySecurityType(String securityType);
}