package com.selaras.api.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class DivisionDTO {

    private Long id;

    private String nameDivision;

    private String nameChiefAsstOfficer;

    private String email;

    private String phoneNumber;

    private String addressLine1;

    private String addressLine2;

    private String city;

    private String postalCode;

    private String state;

    private Boolean active;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;

}
