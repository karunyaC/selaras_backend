package com.selaras.api.repository;

import com.selaras.api.entity.Department;
import com.selaras.api.entity.Project;
import com.selaras.api.entity.ProjectUpdateNotifications;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectUpdateNotificationsRepository extends JpaRepository<ProjectUpdateNotifications, Long> {

    ProjectUpdateNotifications findByProjectAndDepartment(Project project, Department department);
}
