package com.selaras.api.service;

import com.selaras.api.dto.SubDepartmentDTO;
import com.selaras.api.exception.ResourceNotFoundException;

import java.util.List;

public interface SubDepartmentService {
    SubDepartmentDTO getSubDepartmentByName(String name) throws ResourceNotFoundException;

    SubDepartmentDTO getSubDepartmentById(Long id) throws ResourceNotFoundException;

    List<SubDepartmentDTO> getAllSubDepartments() throws ResourceNotFoundException;

    SubDepartmentDTO createSubDepartment(SubDepartmentDTO subDepartmentDTO) throws ResourceNotFoundException;
}
