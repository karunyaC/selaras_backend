package com.selaras.api.requests;


import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StrategyDTO {
    private String strategyName;
    private String strategyCode;
}

