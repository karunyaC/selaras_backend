package com.selaras.api.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.selaras.api.dto.IssueStatusDTO;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.service.IssueStatusService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/issue-status")
@RequiredArgsConstructor
public class IssueStatusController {

    private final IssueStatusService issueStatusService;

    @PostMapping
    public ResponseEntity<IssueStatusDTO> createIssueStatus(@RequestBody IssueStatusDTO issueStatusDTO) {
        IssueStatusDTO createdIssueStatus = issueStatusService.createIssueStatusDTO(issueStatusDTO);
        return new ResponseEntity<>(createdIssueStatus, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<IssueStatusDTO> getIssueStatusById(@PathVariable Long id) {
        try {
            IssueStatusDTO issueStatusDTO = issueStatusService.getIssueStatusDTOById(id);
            return new ResponseEntity<>(issueStatusDTO, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping
    public ResponseEntity<List<IssueStatusDTO>> getAllIssueStatuses() {
        List<IssueStatusDTO> issueStatuses = issueStatusService.getAllIssueStatusDTOes();
        return new ResponseEntity<>(issueStatuses, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<IssueStatusDTO> updateIssueStatus(@PathVariable Long id, @RequestBody IssueStatusDTO issueStatusDTO) {
        try {
            IssueStatusDTO updatedIssueStatus = issueStatusService.updateIssueStatusDTO(id, issueStatusDTO);
            return new ResponseEntity<>(updatedIssueStatus, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteIssueStatus(@PathVariable Long id) {
        try {
            String result = issueStatusService.deleteIssueStatusDTO(id);
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}
