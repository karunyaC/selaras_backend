package com.selaras.api.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table( name = "division" )
public class Division {

    @Id
    @GeneratedValue( strategy = GenerationType.IDENTITY )
    private Long id;

    @Column( name = "name_division" )
    private String nameDivision;

    @Column( name = "name_chief_asst_officer" )
    private String nameChiefAsstOfficer;

    @Column( name = "email" )
    private String email;

    @Column( name = "phone_number" )
    private String phoneNumber;

    @Column( name = "address_line1" )
    private String addressLine1;

    @Column( name = "address_line2" )
    private String addressLine2;

    @Column(name = "city")
    private String city;

    @Column(name = "postal_code")
    private String postalCode;

    @Column(name = "state")
    private String state;

    @ColumnDefault( "true" )
    @Column( name = "active" )
    private Boolean active;

    @Column( name = "created_by", length = 100 )
    private String createdBy;

    @ColumnDefault( "CURRENT_TIMESTAMP" )
    @Column( name = "created_at" )
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column( name = "modified_by", length = 100 )
    private String modifiedBy;

    @ColumnDefault( "CURRENT_TIMESTAMP" )
    @Column( name = "modified_at" )
    @UpdateTimestamp
    private LocalDateTime modifiedAt;

}
