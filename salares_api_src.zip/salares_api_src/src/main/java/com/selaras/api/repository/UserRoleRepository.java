package com.selaras.api.repository;

import com.selaras.api.entity.UserRole;
import com.selaras.api.entity.UserRoleId;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface UserRoleRepository extends JpaRepository<UserRole, UserRoleId>, JpaSpecificationExecutor<UserRole> {

    List<UserRole> findByUserId(Long intValue);

}