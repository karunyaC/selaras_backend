package com.selaras.api.service.impl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.selaras.api.dto.IssueStatusDTO;
import com.selaras.api.entity.IssueStatus;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.IssueStatusRepository;
import com.selaras.api.service.IssueStatusService;

import lombok.RequiredArgsConstructor;
@Service
@RequiredArgsConstructor
public class IssueStatusServiceImpl  implements IssueStatusService{

    private final IssueStatusRepository issueStatusRepository;
        private final ModelMapper modelMapper;
    @Override
    public IssueStatusDTO createIssueStatusDTO(IssueStatusDTO issueStatusDTO) {
    IssueStatus issueStatus = modelMapper.map(issueStatusDTO, IssueStatus.class);
    
    IssueStatus savedIssueStatus = issueStatusRepository.save(issueStatus);
    return modelMapper.map(savedIssueStatus, IssueStatusDTO.class);
    }


    @Override
    public IssueStatusDTO getIssueStatusDTOById(Long id) throws ResourceNotFoundException {
        IssueStatus issueStatus = issueStatusRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Issue status not found with id: " + id));
        
        return modelMapper.map(issueStatus, IssueStatusDTO.class);
    }
    

    @Override
    public List<IssueStatusDTO> getAllIssueStatusDTOes() {
        List<IssueStatus> issueStatuses = issueStatusRepository.findAll();

        
    if (issueStatuses == null || issueStatuses.isEmpty()) {
        return List.of();
    }
        
        return issueStatuses.stream()
            .map(issueStatus -> modelMapper.map(issueStatus, IssueStatusDTO.class))
            .toList();
    }
    

    @Override
    public IssueStatusDTO updateIssueStatusDTO(Long id, IssueStatusDTO issueStatusDTO) 
            throws ResourceNotFoundException {
        IssueStatus existingIssueStatus = issueStatusRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Issue status not found with id: " + id));
        
        modelMapper.map(issueStatusDTO, existingIssueStatus);
        
        IssueStatus updatedIssueStatus = issueStatusRepository.save(existingIssueStatus);
        
        return modelMapper.map(updatedIssueStatus, IssueStatusDTO.class);
    }
    

    @Override
    public String deleteIssueStatusDTO(Long id) throws ResourceNotFoundException {
        IssueStatus issueStatus = issueStatusRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Issue status not found with id: " + id));
        
        issueStatusRepository.delete(issueStatus);
        
        return "Issue status with id: " + id + " has been deleted successfully.";
    }
    
    
}
