package com.selaras.api.service;

import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.requests.EmailTemplateRequest;
import com.selaras.api.responses.EmailTemplateResettodefaultResponse;
import com.selaras.api.responses.EmailTemplateResponse;

import java.util.List;


public interface EmailTemplateService {
    String saveEmailTemplate(EmailTemplateRequest request);

    List<EmailTemplateResponse> getAllEmailTemplates();

    EmailTemplateResponse getEmailById(Long id) throws ResourceNotFoundException;
 
    String updateEmailById(EmailTemplateRequest request,long id) throws ResourceNotFoundException;
 
    EmailTemplateResettodefaultResponse setDefault(long id) throws ResourceNotFoundException;
 
    String resetDefault(long id,EmailTemplateResettodefaultResponse emailTemplateResettodefaultResponse) throws ResourceNotFoundException;
  
}
