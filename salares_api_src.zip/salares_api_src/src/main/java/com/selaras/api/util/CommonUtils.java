package com.selaras.api.util;

import com.selaras.api.exception.ResourceNotFoundException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class CommonUtils {

//    private final DefaultKaptcha defaultKaptcha;

    @Autowired
    CaptchaGenerator captchaGenerator;

//    @Autowired
//    public CommonUtils(DefaultKaptcha defaultKaptcha) {
//        this.defaultKaptcha = defaultKaptcha;
//    }

    public void getCaptchaImage(HttpServletRequest request, HttpServletResponse response, String email) throws IOException, ResourceNotFoundException {
        captchaGenerator.generateCaptcha(request, response, email);
    }

}
