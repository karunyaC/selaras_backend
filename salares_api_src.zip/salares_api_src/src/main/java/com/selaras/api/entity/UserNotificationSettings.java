package com.selaras.api.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * $table.getTableComment()
 */
@Data
@Entity
@Table(name = "user_notification_settings")
public class UserNotificationSettings implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "promotion_title", nullable = false)
    private String promotionTitle;

    @ManyToOne
    @JoinColumn(name = "promotion_category_id")
    private PromotionCategory promotionCategory;

    @Column(name = "description")
    private String description;

    @Column(name = "platform")
    private String platform;


    @Column(name = "announcement_to")
    private String announcementTo;

    @Column(name = "promotion_scheduling")
    private LocalDateTime promotionScheduling;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_at")
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "modified_at")
    @UpdateTimestamp
    private LocalDateTime modifiedAt;

    @Column(name = "status")
    private String status;

}
