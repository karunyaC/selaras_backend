package com.selaras.api.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HelpdeskGroupedResponse {
    private Integer srNumber;
    private String srTitle;
    private String srDescription;
    private String browser;
    private String os;
    private String link;
    private String criticalLevel;
    private String status;
    private String createdBy;
    private LocalDateTime createdAt;
    private String updatedBy;
    private LocalDateTime updatedAt;
    private List<HelpdeskFileResponse> files;
    private List<HelpdeskTicketLogResponse> ticketLogs;

}
