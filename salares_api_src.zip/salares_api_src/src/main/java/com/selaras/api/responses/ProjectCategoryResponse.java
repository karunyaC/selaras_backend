package com.selaras.api.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectCategoryResponse {

    private Integer id;
    private String code;
    private String category;
    private Boolean active;
    private String createdAt;
}
