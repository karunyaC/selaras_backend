package com.selaras.api.config;

import com.selaras.api.exception.BadRequestException;
import io.minio.MinioClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MinioConfig {

    @Value("${minio.endpoint}")
    String endPoint;

    @Value("${minio.accesskey}")
    String accesskey;

    @Value("${minio.secretkey}")
    String secretkey;

    public MinioClient getMinioClient() throws BadRequestException {
        try {
            return
                    MinioClient.builder()
                            .endpoint(endPoint)
                            .credentials(accesskey, secretkey)
                            .build();
        } catch (Exception e) {
            throw new BadRequestException("Error creating minio client");
        }

    }


}
