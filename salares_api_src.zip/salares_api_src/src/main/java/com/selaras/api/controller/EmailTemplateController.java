package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.requests.EmailTemplateRequest;
import com.selaras.api.responses.EmailTemplateResettodefaultResponse;
import com.selaras.api.responses.EmailTemplateResponse;
import com.selaras.api.service.EmailTemplateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class EmailTemplateController {

private final EmailTemplateService emailTemplateService;

    @Operation(summary = "Save Email template", description = "Save email template")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/email/template")
    @AuditTrail(recordType = "EmailTemplate", action = "Save Email Template", presentValue = "Email template saved")
    public ResponseEntity<?> saveEmailTemplate(@RequestBody EmailTemplateRequest request) {
        return ResponseEntity.ok().body(emailTemplateService.saveEmailTemplate(request));
    }

    @Operation(summary = "Get all email templates", description = "Get all email templates")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/email/template")
    @AuditTrail(recordType = "EmailTemplate", action = "Get All Email Templates", presentValue = "Retrieved all email templates")
    public ResponseEntity<?> getAllEmailTemplates() {
        return ResponseEntity.ok().body(emailTemplateService.getAllEmailTemplates());
    }
    @Operation(summary ="Get Email By Id", description = " Get Email By Id")
    @ApiResponse(responseCode ="200",description="ok")
    @GetMapping("/getemailbyid")
    @AuditTrail(recordType = "EmailTemplate", action = "Get Email Templates id", presentValue = "Retrieved email templates by Id")
    public ResponseEntity<EmailTemplateResponse> getEmailById(long id) throws ResourceNotFoundException{
        return ResponseEntity.ok().body(emailTemplateService.getEmailById(id));
    }
    @PutMapping("/updateEmailById/{id}")
    @AuditTrail(recordType = "EmailTemplate", action = "Update Email Templates id", presentValue = "Update email templates by Id")
    public ResponseEntity<String> updateEmailTemplateById(@PathVariable Long id, @RequestBody EmailTemplateRequest request) throws ResourceNotFoundException {
        String responseMessage = emailTemplateService.updateEmailById(request, id);
        return ResponseEntity.ok(responseMessage);
    }
    @GetMapping("/resettoDefault/{id}")
    @AuditTrail(recordType = "EmailTemplate", action = "Restore default Email Templates", presentValue = "Restore default Email Templates")
    public ResponseEntity<EmailTemplateResettodefaultResponse> setDefault(@PathVariable Long id) throws ResourceNotFoundException {
        EmailTemplateResettodefaultResponse response = emailTemplateService.setDefault(id);
        return ResponseEntity.ok(response);
    }
    
    @PutMapping("/UpdateDefault/{id}")
    @AuditTrail(recordType = "EmailTemplate", action = "Update default Email Templates", presentValue = "Update default Email Templates")
    public ResponseEntity<String> resetDefault(@PathVariable Long id, EmailTemplateResettodefaultResponse emailTemplateResettodefaultResponse) throws ResourceNotFoundException {
        String responseMessage = emailTemplateService.resetDefault(id,emailTemplateResettodefaultResponse);
        return ResponseEntity.ok(responseMessage);
    }    


}
