package com.selaras.api.controller;

import com.selaras.api.exception.BadRequestException;
import com.selaras.api.requests.AuditTrailRequest;
import com.selaras.api.service.AuditTrailService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AuditTrailController {

    
     private final AuditTrailService auditTrailService;

    @Operation(summary = "Save Audit Trail", description = "Save Audit Trail parameters")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/audit/trail")
    public ResponseEntity<?> saveAuditTrail(@RequestBody AuditTrailRequest request) throws BadRequestException {
        return ResponseEntity.ok().body(auditTrailService.saveAuditTrail(request));
    }

    @Operation(summary = "Get Audit Trail", description = "Retrieve saved Aduit Trail")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/audit/trail")
    public ResponseEntity<?> getAllAuditTrail() {
        return ResponseEntity.ok().body(auditTrailService.getAllAuditTrail());
    }
}
