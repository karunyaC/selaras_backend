package com.selaras.api.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectStatusResponse {

    private Integer id;
    private String code;
    private String category;
    private String type;
    private Boolean active;
    private String createdAt;
}
