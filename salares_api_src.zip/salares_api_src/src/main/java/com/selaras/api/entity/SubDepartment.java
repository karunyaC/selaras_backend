package com.selaras.api.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "sub_department")
public class SubDepartment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "sub_dept_name")
    private String subDeptName;

    @ManyToOne
    @JoinColumn(name = "dept_id")
    private Department department;

}
