package com.selaras.api.service;


import com.selaras.api.entity.UserAccount;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.repository.UserAccountRepository;
import com.selaras.api.repository.UserRepository;
import com.selaras.api.responses.SignupRequest;

import lombok.RequiredArgsConstructor;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class UserService {

  private final  UserAccountRepository userAccountRepository;
  private final UserRepository repository;
  private final PasswordEncoder passwordEncoder;

  @Transactional
  public void signup(SignupRequest request) throws BadRequestException {
    String email = request.getEmail();
    UserAccount existingUser = userAccountRepository.findByEmail(email);
    if (existingUser == null) {
      throw new BadRequestException(String.format("User with the email address '%s' already exists.", email));
    }

    String hashedPassword = passwordEncoder.encode(request.getPassword());

    // Generate a random numeric domain ID or assign one based on your application's logic.
    Long domainId = generateDomainId();

    UserAccount userAccount = new UserAccount();
    userAccount.setName(request.getName());
    userAccount.setEmail(email);
    userAccount.setPassword(hashedPassword);
    userAccount.setDomainId(domainId); // Assuming domainId comes from SignupRequest
    userAccount.setSystemGeneratedPassword(false); // Default value, adjust as needed
    userAccount.setChangePasswordOnFirstLogin(true); // Default value, adjust as needed
    userAccount.setEmailProofOfAuthentication(false); // Default value, adjust as needed
    userAccount.setActive(true); // Default value, adjust as needed
    userAccount.setCreatedBy("system"); // Set appropriate value
    userAccount.setCreatedAt(LocalDateTime.now());
    // Set any other fields that are necessary or have default values

    userAccountRepository.save(userAccount);
  }
  // Example method to generate a random numeric domain ID
  private Long generateDomainId() {
    return (long) (Math.random() * 100000000L); // Generates a random 8-digit number
  }

}
