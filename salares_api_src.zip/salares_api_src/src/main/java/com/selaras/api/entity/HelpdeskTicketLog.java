package com.selaras.api.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "helpdeskticketlog")
public class HelpdeskTicketLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "comment", nullable = false)
    private String comment;

    @Column(name = "commentby", nullable = false)
    private String commentBy;

    @Column(name = "commentat", nullable = false)
    @CreationTimestamp
    private LocalDateTime commentAt;

    @ManyToOne
    @JoinColumn(name = "srnumber")
    private Helpdesk helpdesk;
}
