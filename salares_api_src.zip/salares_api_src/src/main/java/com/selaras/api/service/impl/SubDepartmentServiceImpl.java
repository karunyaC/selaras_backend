package com.selaras.api.service.impl;

import com.selaras.api.dto.SubDepartmentDTO;
import com.selaras.api.entity.Department;
import com.selaras.api.entity.SubDepartment;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.DepartmentRepository;
import com.selaras.api.repository.SubDepartmentRepository;
import com.selaras.api.service.SubDepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SubDepartmentServiceImpl implements SubDepartmentService {

    private final SubDepartmentRepository subDepartmentRepository;
    private final DepartmentRepository departmentRepository;

    @Override
    public SubDepartmentDTO getSubDepartmentByName(String name) throws ResourceNotFoundException {
        SubDepartment dept = subDepartmentRepository.findBySubDeptName(name);

        if (dept == null) {
            throw new ResourceNotFoundException("Sub department not found with given name");
        }

        SubDepartmentDTO subDepartmentDTO = new SubDepartmentDTO();
        subDepartmentDTO.setId(Long.valueOf(dept.getId()));
        subDepartmentDTO.setSubDeptName(dept.getSubDeptName());
        subDepartmentDTO.setDeptId(Long.valueOf(dept.getDepartment().getId()));
        subDepartmentDTO.setDeptName(dept.getDepartment().getName());
        return subDepartmentDTO;
    }

    @Override
    public SubDepartmentDTO getSubDepartmentById(Long id) throws ResourceNotFoundException {
        SubDepartment dept = subDepartmentRepository.findById(id).orElse(null);

        if (dept == null) {
            throw new ResourceNotFoundException("Sub department not found with given id");
        }

        SubDepartmentDTO subDepartmentDTO = new SubDepartmentDTO();
        subDepartmentDTO.setId(Long.valueOf(dept.getId()));
        subDepartmentDTO.setSubDeptName(dept.getSubDeptName());
        subDepartmentDTO.setDeptId(Long.valueOf(dept.getDepartment().getId()));
        subDepartmentDTO.setDeptName(dept.getDepartment().getName());
        return subDepartmentDTO;
    }

    @Override
    public List<SubDepartmentDTO> getAllSubDepartments() throws ResourceNotFoundException {
        List<SubDepartment> deptList = subDepartmentRepository.findAll();
        List<SubDepartmentDTO> deptDtoList = new ArrayList<>();

        if (deptList.isEmpty()) {
            throw new ResourceNotFoundException("Sub departments not found");
        }
        deptList.forEach(dept -> {
            SubDepartmentDTO subDepartmentDTO = new SubDepartmentDTO();
            subDepartmentDTO.setId(Long.valueOf(dept.getId()));
            subDepartmentDTO.setSubDeptName(dept.getSubDeptName());
            subDepartmentDTO.setDeptId(Long.valueOf(dept.getDepartment().getId()));
            subDepartmentDTO.setDeptName(dept.getDepartment().getName());
            deptDtoList.add(subDepartmentDTO);
        });

        return deptDtoList;
    }

    @Override
    public SubDepartmentDTO createSubDepartment(SubDepartmentDTO subDepartmentDTO) throws ResourceNotFoundException {

        SubDepartment subDepartment = subDepartmentRepository.findBySubDeptName(subDepartmentDTO.getSubDeptName());
        if (subDepartment == null) {
            subDepartment = new SubDepartment();
        }

        Department dept = departmentRepository.findById(subDepartmentDTO.getDeptId()).orElse(null);
        if (dept == null) {
            throw new ResourceNotFoundException("Department not found with given id");
        }

        subDepartment.setSubDeptName(subDepartmentDTO.getSubDeptName());
        subDepartment.setDepartment(dept);

        SubDepartment savedSubDept = subDepartmentRepository.save(subDepartment);

        SubDepartmentDTO savedSubDeptDTO = new SubDepartmentDTO();
        savedSubDeptDTO.setId(Long.valueOf(savedSubDept.getId()));
        savedSubDeptDTO.setSubDeptName(savedSubDept.getSubDeptName());
        savedSubDeptDTO.setDeptId(Long.valueOf(savedSubDept.getDepartment().getId()));
        savedSubDeptDTO.setDeptName(savedSubDept.getDepartment().getName());

        return savedSubDeptDTO;
    }
}
