package com.selaras.api.repository;

import com.selaras.api.entity.Company;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface CompanyRepository extends JpaRepository<Company, Long>, JpaSpecificationExecutor<Company> {

    Company findByName(String companyName);

    Company findByRegistrationNumber(String regNo);

    Company findByNameAndRegistrationNumber(String companyName, String regNo);
    
    List<Company> findByActive(Boolean isActive);

}