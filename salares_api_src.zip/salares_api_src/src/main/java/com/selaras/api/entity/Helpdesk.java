package com.selaras.api.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "helpdesk")
public class Helpdesk {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "helpdesk_seq")
    @SequenceGenerator(name = "helpdesk_seq", sequenceName = "helpdesk_srnumber_seq", allocationSize = 1)
    @Column(name = "srnumber")
    private Integer srNumber;

    @Column(name = "srtitle", nullable = false)
    private String srTitle;

    @Column(name = "srdescription")
    private String srDescription;

    @Column(name = "browser")
    private String browser;

    @Column(name = "os")
    private String os;

    @Column(name = "link")
    private String link;

    @Column(name = "criticallevel")
    private String criticalLevel;

    @Column(name = "status")
    private String status;

    @Column(name = "createdby", nullable = false)
    private String createdBy;

    @Column(name = "createdat", nullable = false)
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column(name = "updatedby")
    private String updatedBy;

    @Column(name = "updatedat")
    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
