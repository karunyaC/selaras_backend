package com.selaras.api.dto;

import java.time.Instant;

public class DSPStrategyDTO {
    private Long rowId;
    private String code;
    private String planCode;
    private String coreId;
    private String stratId;
    private String stratPreferredName;
    private String stratPreferredCode;
    private Instant createdAt;
    private Instant modifiedAt;
}
