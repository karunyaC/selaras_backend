package com.selaras.api.responses;

import com.selaras.api.entity.UserAccount;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.LocalDateTime;

public class LoginAttemptResponse {

  @Schema(description = "The date and time of the login attempt")
  private LocalDateTime createdAt;

  @Schema(description = "The login status")
  private boolean success;

  // Constructor
  public LoginAttemptResponse(LocalDateTime createdAt, boolean success) {
    this.createdAt = createdAt;
    this.success = success;
  }

  // Getters
  public LocalDateTime getCreatedAt() {
    return createdAt;
  }

  public boolean isSuccess() {
    return success;
  }

  public static LoginAttemptResponse convertToFrom(UserAccount userAccount) {

    boolean success = userAccount.getActive() != null && userAccount.getActive();
    return new LoginAttemptResponse(userAccount.getCreatedAt(), success);
  }
}
