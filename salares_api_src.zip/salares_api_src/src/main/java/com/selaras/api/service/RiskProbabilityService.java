package com.selaras.api.service;

import java.util.List;

import com.selaras.api.dto.RiskProbDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;

public interface RiskProbabilityService {

    RiskProbDTO createRiskProb(RiskProbDTO riskProbDTO) throws BadRequestException;
    RiskProbDTO getById(long id) throws ResourceNotFoundException;
    List<RiskProbDTO> getall();
    RiskProbDTO updateRiskProb(long id,RiskProbDTO riskProbDTO) throws ResourceNotFoundException;
    String deleteRiskProbability(long id) throws ResourceNotFoundException;
}
