package com.selaras.api.util;

public class ApplicationConstants {

	public static final String DEFAULT_PAGE_NUMBER = "1";
	public static final String DEFAULT_PAGE_SIZE = "10";
	public static final String DEFAULT_SORT_BY = "name";
	public static final String DEFAULT_ORDER_BY = "DESC";

}
