package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.requests.HelpdeskLogRequest;
import com.selaras.api.requests.HelpdeskRequest;
import com.selaras.api.requests.HelpdeskStatusUpdateRequest;
import com.selaras.api.service.HelpdeskService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/helpdesk")
@RequiredArgsConstructor
public class HelpdeskController {

    private final  HelpdeskService helpdeskService;

    @Operation(summary = "Save new SR", description = "Save new Service Request")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/save")
    @AuditTrail(recordType = "Service Request", action = "Save Service Request", presentValue = "New service request created")
    public ResponseEntity<?> saveHelpdeskWithFiles(@RequestBody HelpdeskRequest request) {
        return ResponseEntity.ok().body(helpdeskService.saveHelpdeskWithFiles(request));
    }

    @Operation(summary = "Get log of SR", description = "Retrieve all comments related to a SR")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/save/log")
    @AuditTrail(recordType = "Service Request Log", action = "Save Log", presentValue = "Log entry added to service request to SR")
    public ResponseEntity<?> saveHelpdeskLog(@RequestBody HelpdeskLogRequest request) throws ResourceNotFoundException {
        return ResponseEntity.ok().body(helpdeskService.saveHelpdeskLog(request));
    }

    @Operation(summary = "Save a Service Request", description = "Save a service request")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/save/status")
    @AuditTrail(recordType = "Service Request", action = "Update Status", presentValue = "Status updated for service request")
    public ResponseEntity<?> updateStatus(@RequestBody HelpdeskStatusUpdateRequest request) throws ResourceNotFoundException, BadRequestException {
        return ResponseEntity.ok().body(helpdeskService.updateStatus(request));
    }

    @Operation(summary = "Get SRs list", description = "Get all SRs")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/")
    @AuditTrail(recordType = "Service Request", action = "Retrieve All", presentValue = "All service requests retrieved")
    public ResponseEntity<?> getAllHelpDeskTickets(){
        return ResponseEntity.ok().body(helpdeskService.getAllHelpDeskTickets());
    }
}
