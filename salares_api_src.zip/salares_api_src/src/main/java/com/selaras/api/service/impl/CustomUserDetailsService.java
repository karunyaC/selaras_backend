package com.selaras.api.service.impl;

import com.selaras.api.entity.UserAccount;
import com.selaras.api.repository.UserAccountRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {


    private final UserAccountRepository userAccountRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserAccount user = userAccountRepository.findByName(username);
        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return User.withUsername(user.getName())
                .password(user.getPassword())
                .roles("USER") // Or load roles from the database
                .build();
    }

    public UserDetails loadUserByEmail(String email) throws UsernameNotFoundException {
        UserAccount user = userAccountRepository.findByEmail(email);
        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return User.withUsername(user.getEmail())
                .password(user.getPassword())
                .build();
    }
}

