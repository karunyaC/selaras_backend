package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.requests.DspSaveDTO;
import com.selaras.api.service.DspService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.apache.coyote.Response;
import org.simpleframework.xml.Path;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class DSPController {

    private final DspService dspService;

    @Operation(summary = "Save or update DSP", description = "Save or update DSP")
    @ApiResponse(responseCode = "200", description = "OK")
    @AuditTrail(recordType = "Digitization Strategic Plan", action = "Save or update DSP", presentValue = "Save or update DSP")
    @PostMapping("/dsp")
    public ResponseEntity<?> saveDsp(@RequestBody DspSaveDTO saveDTO) {
        return ResponseEntity.ok().body(dspService.saveDSP(saveDTO));
    }

    @Operation(summary = "Get all DSP", description = "Get all DSP")
    @ApiResponse(responseCode = "200", description = "OK")
    @AuditTrail(recordType = "Digitization Strategic Plan", action = "Get all DSP", presentValue = "Get all DSP")
    @GetMapping("/dsp")
    public ResponseEntity<?> getAllDsp() {
        return ResponseEntity.ok().body(dspService.getAllDsp());
    }

    @Operation(summary = "Search DSP by code", description = "Search DSP by code")
    @ApiResponse(responseCode = "200", description = "OK")
    @AuditTrail(recordType = "Digitization Strategic Plan", action = "Search DSP by code", presentValue = "Search DSP by code")
    @GetMapping("/dsp/{code}")
    public ResponseEntity<?> getDspByCode(@PathVariable String code) {
        return ResponseEntity.ok().body(dspService.getDspByCode(code));
    }

    @Operation(summary = "Delete DSP", description = "Delete DSP")
    @ApiResponse(responseCode = "200", description = "OK")
    @AuditTrail(recordType = "Digitization Strategic Plan", action = "Delete DSP by code", presentValue = "Delete DSP by code")
    @DeleteMapping("/dsp/{code}")
    public ResponseEntity<?> deleteDspByCode(@PathVariable String code) throws ResourceNotFoundException {
        return ResponseEntity.ok().body(dspService.deleteDspByCode(code));
    }
}
