package com.selaras.api.repository;

import com.selaras.api.entity.ModuleAccessLevel;
import com.selaras.api.entity.ModuleAccessLevelId;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface ModuleAccessLevelRepository extends JpaRepository<ModuleAccessLevel, ModuleAccessLevelId>, JpaSpecificationExecutor<ModuleAccessLevel> {

    List<ModuleAccessLevel> findAllByAccessLevel_IdIn(List<Long> accessIds);
}