package com.selaras.api.dto;

import java.time.Instant;

public class DSPCoreDTO {
    private Long rowId;
    private String code;
    private String planCode;
    private String coreId;
    private String corePreferredName;
    private String corePreferredCode;
    private Instant createdAt;
    private Instant modifiedAt;
}
