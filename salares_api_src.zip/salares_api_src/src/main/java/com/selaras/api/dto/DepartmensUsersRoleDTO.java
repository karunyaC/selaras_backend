package com.selaras.api.dto;

import java.time.LocalDateTime;

import lombok.Data;
import java.util.List;

@Data
public class DepartmensUsersRoleDTO {

    private Long id;

    private String User_name;
    
    private List<String> user_groups;

    private LocalDateTime lastModified;

    private Boolean active;

}
