package com.selaras.api.service;

import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.requests.SpSaveDTO;

import java.util.List;

public interface SpService {
    SpSaveDTO saveSp(SpSaveDTO saveDTO);

    List<SpSaveDTO> getAllsp();

    SpSaveDTO getSpByCode(String code);

    String deleteSpByCode(String code) throws ResourceNotFoundException;
}
