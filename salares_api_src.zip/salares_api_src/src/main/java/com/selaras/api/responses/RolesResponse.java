package com.selaras.api.responses;

import com.selaras.api.dto.RoleDTO;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class RolesResponse {
    private List<RoleDTO> roles;
    private int pageNo;
    private int pageSize;
    private long totalElements;
    private int totalPages;
    private boolean last;
}
