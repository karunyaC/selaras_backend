package com.selaras.api.repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.selaras.api.entity.DSPCore;

public interface DSPCoreRepository extends JpaRepository<DSPCore, Long> {

    @Query(value = "SELECT * FROM dsp_core WHERE code = :code", nativeQuery = true)
    List<DSPCore> findByCode(@Param("code") String code);

    @Query(value = "SELECT * FROM dsp_core WHERE core_id = :coreId AND modified_at IS NULL OR modified_at = :modifiedAt", nativeQuery = true)
    Optional<DSPCore> findMostRecentByCoreIdAndModifiedAt(@Param("coreId") String coreId, @Param("modifiedAt") Instant modifiedAt);

    DSPCore findByCorePreferredName(String coreName);

    List<DSPCore> findByPlanCode(String planCode);
}
