package com.selaras.api.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.selaras.api.dto.RiskImpactDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.service.RiskImpactService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/risk-impact")
@RequiredArgsConstructor
public class RiskImpactController {

    private final RiskImpactService riskImpactService;

    @PostMapping
    public ResponseEntity<RiskImpactDTO> createRiskImpact(@RequestBody RiskImpactDTO riskImpactDTO) {
        try {
            RiskImpactDTO createdRiskImpact = riskImpactService.createRiskImpact(riskImpactDTO);
            return new ResponseEntity<>(createdRiskImpact, HttpStatus.CREATED);
        } catch (BadRequestException e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<RiskImpactDTO> getRiskImpactById(@PathVariable long id) {
        try {
            RiskImpactDTO riskImpactDTO = riskImpactService.getById(id);
            return new ResponseEntity<>(riskImpactDTO, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping
    public ResponseEntity<List<RiskImpactDTO>> getAllRiskImpacts() {
        List<RiskImpactDTO> riskImpactDTOs = riskImpactService.getall();
        return new ResponseEntity<>(riskImpactDTOs, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<RiskImpactDTO> updateRiskImpact(@PathVariable long id, @RequestBody RiskImpactDTO riskImpactDTO) {
        try {
            RiskImpactDTO updatedRiskImpact = riskImpactService.updateRiskImpact(id, riskImpactDTO);
            return new ResponseEntity<>(updatedRiskImpact, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteRiskImpact(@PathVariable long id) {
        try {
            String message = riskImpactService.deleteRiskImpact(id);
            return new ResponseEntity<>(message, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }
}
