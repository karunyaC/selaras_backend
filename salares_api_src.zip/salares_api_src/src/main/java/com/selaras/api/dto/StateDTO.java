package com.selaras.api.dto;

import lombok.Data;

import java.time.LocalDateTime;


@Data
public class StateDTO {

    private Long id;

    private String name;

    private String code;

    private Boolean active;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;
}
