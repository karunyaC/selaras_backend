package com.selaras.api.controller;

import com.selaras.api.dto.ProjectDTO;
import com.selaras.api.entity.AnnouncementTo;
import com.selaras.api.entity.Platform;
import com.selaras.api.entity.PromotionCategory;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.requests.ProjectNotificationsRequest;
import com.selaras.api.requests.UserNotificationRequest;
import com.selaras.api.service.ProjectUserNotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ProjectUserNotificationController {
     private final ProjectUserNotificationService projectUserNotificationService;

    @Operation(summary = "Save User Notifications", description = "Save user Notifications")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/user/notification")
    public ResponseEntity<?> saveUserNotification(@RequestBody UserNotificationRequest request) throws BadRequestException {
        return ResponseEntity.ok().body(projectUserNotificationService.saveUserNotification(request));
    }

    @Operation(summary = "Get all User Notifications", description = "Get all user notifications")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/user/notification")
    public ResponseEntity<?> getAllUserNotification() {
        return ResponseEntity.ok().body(projectUserNotificationService.getAllUserNotification());
    }

    @Operation(summary = "Save Project Notifications", description = "Save project notifications")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/project/notifications")
    public ResponseEntity<?> saveProjectNotifications(@RequestBody ProjectNotificationsRequest request) throws BadRequestException {
        return ResponseEntity.ok().body(projectUserNotificationService.saveProjectNotification(request));
    }

    @Operation(summary = "Get all project notifications", description = "Get all project notifications")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/project/notifications")
    public ResponseEntity<?> getAllProjectNotifications() {
        return ResponseEntity.ok().body(projectUserNotificationService.getAllProjectNotification());
    }
  @Operation(summary = "Get all Platforms", description = "Retrieve all available platforms")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/platforms")
    public ResponseEntity<List<Platform>> getAllPlatforms() {
        List<Platform> platforms = projectUserNotificationService.getallPlatform();
        return ResponseEntity.ok(platforms);
    }


    @Operation(summary = "Get all Announcements", description = "Retrieve all available announcements")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/announcements")
    public ResponseEntity<List<AnnouncementTo>> getAllAnnouncements() {
        List<AnnouncementTo> announcements = projectUserNotificationService.getallannouncement();
        return ResponseEntity.ok(announcements);
    }

    @Operation(summary = "Get all Promotions", description = "Retrieve all available promotions")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/promotions")
    public ResponseEntity<List<PromotionCategory>> getAllPromotions() {
        List<PromotionCategory> promotions = projectUserNotificationService.getallPromotion();
        return ResponseEntity.ok(promotions);
    }

    @Operation(summary = "Get all User Projects", description = "Get all user notifications")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/Projects")
    public ResponseEntity<?> getAllProjects() {
        return ResponseEntity.ok().body(projectUserNotificationService.getallProjects());
    }


}
