package com.selaras.api.service.impl;

import com.selaras.api.entity.Company;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.repository.CompanyRepository;
import com.selaras.api.requests.CompanySaveRequest;
import com.selaras.api.responses.CompanyResponse;
import com.selaras.api.service.CompanyAssociationService;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor

public class CompanyAssociationServiceImpl implements CompanyAssociationService {


    private final CompanyRepository companyRepository;

    @Override
    public String saveCompany(CompanySaveRequest request) throws BadRequestException {
        validateCompany(request);

        Company companyByName = companyRepository.findByName(request.getCompanyName());
        Company companyByRegNo = companyRepository.findByRegistrationNumber(request.getRegNo());

        if (companyByName != null) {
            if (!companyByName.getRegistrationNumber().trim().equalsIgnoreCase(request.getRegNo())) {
                throw new BadRequestException("Company exists with a different registration number");
            }
            companyByName.setActive(request.isStatus());
            companyRepository.save(companyByName);
        } else if (companyByRegNo != null) {
            if (!companyByRegNo.getName().trim().equalsIgnoreCase(request.getCompanyName())) {
                throw new BadRequestException("Another company exists with this registration number");
            }
            companyByRegNo.setActive(request.isStatus());
            companyRepository.save(companyByRegNo);
        } else {
            Company company = new Company();
            company.setCreatedBy("SYSTEM");
            company.setName(request.getCompanyName());
            company.setRegistrationNumber(request.getRegNo());
            company.setDateOfRegistration(LocalDateTime.now());
            company.setActive(request.isStatus());

            companyRepository.save(company);
        }

        return "Company/Association saved successfully";
    }


    @Override
    public List<CompanyResponse> getAllCompanies() {
        List<Company> companiesList = companyRepository.findAll();
        List<CompanyResponse> companies = new ArrayList<>();

        companiesList.forEach(company -> {
            CompanyResponse res = new CompanyResponse();
            res.setCompanyName(company.getName());
            res.setId(company.getId());
            res.setRegNo(company.getRegistrationNumber());
            res.setStatus(company.getActive());
            res.setDateOfRegistration(company.getDateOfRegistration().format(DateTimeFormatter.ofPattern("yyyy-MM-dd, hh:mma")));
            companies.add(res);
        });

        return companies;
    }

    private void validateCompany(CompanySaveRequest request) throws BadRequestException {
        if (request.getCompanyName() == null || request.getCompanyName().trim().isEmpty() || request.getRegNo() == null || request.getRegNo().trim().isEmpty()) {
            throw new BadRequestException("Invalid input provided");
        }
    }
    @Override
    public String updateCompany(Long companyId, CompanySaveRequest request) throws BadRequestException {
        validateCompany(request);
    
        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new BadRequestException("Company not found with id: " + companyId));    
        company.setName(request.getCompanyName());
        company.setRegistrationNumber(request.getRegNo());
        company.setActive(request.isStatus());
    
        companyRepository.save(company);
    
        return "Company/Association updated successfully";
    }   
    @Override
    public CompanyResponse getCompanyByNameOrId(String name, Long id) throws BadRequestException {
        Optional<Company> company;

        if (id != null) {
            company = companyRepository.findById(id);
        } else if (name != null && !name.trim().isEmpty()) {
            company = Optional.ofNullable(companyRepository.findByName(name));
        } else {
            throw new BadRequestException("Name or ID must be provided to search");
        }

        return company.map(this::convertToResponse)
                .orElseThrow(() -> new BadRequestException("Company not found with provided name or id"));
    }

    private CompanyResponse convertToResponse(Company company) {
        CompanyResponse response = new CompanyResponse();
        response.setCompanyName(company.getName());
        response.setId(company.getId());
        response.setRegNo(company.getRegistrationNumber());
        response.setStatus(company.getActive());
        response.setDateOfRegistration(company.getDateOfRegistration().toString());
        return response;
    }
//deactivateCompanies status
@Override
public List<CompanyResponse> DelectCompanies(Long[] ids) {
    List<CompanyResponse> updatedCompanies = new ArrayList<>();

    for (long id : ids) {
        Optional<Company> companyOptional = companyRepository.findById(id);

        if (companyOptional.isPresent()) {
            Company company = companyOptional.get();
            company.setActive(false);
            companyRepository.save(company);
            
            CompanyResponse response = new CompanyResponse();
            response.setId(company.getId());
            response.setCompanyName(company.getName());
            response.setRegNo(company.getRegistrationNumber());
            response.setStatus(company.getActive());
            updatedCompanies.add(response);
        } else {
            System.out.println("Company with ID " + id + " not found.");
        }
    }

    return updatedCompanies;
}
@Override
public List<CompanyResponse> findByActive(Boolean isActive) {
    List<Company> companiesList;

    if (isActive != null) {
        companiesList = companyRepository.findByActive(isActive);
    } else {
        companiesList = companyRepository.findAll();
    }

    List<CompanyResponse> companies = new ArrayList<>();
    companiesList.forEach(company -> {
        CompanyResponse res = new CompanyResponse();
        res.setCompanyName(company.getName());
        res.setId(company.getId());
        res.setRegNo(company.getRegistrationNumber());
        res.setStatus(company.getActive());
        res.setDateOfRegistration(company.getDateOfRegistration().format(DateTimeFormatter.ofPattern("yyyy-MM-dd, hh:mma")));
        companies.add(res);
    });

    return companies;
}


}