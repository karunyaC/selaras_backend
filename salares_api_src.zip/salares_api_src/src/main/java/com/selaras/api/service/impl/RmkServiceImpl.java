package com.selaras.api.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.selaras.api.entity.Rmk;
import com.selaras.api.repository.RmkRepository;
import com.selaras.api.service.RmkService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RmkServiceImpl implements RmkService {
    private final RmkRepository rmkRepository;

    @Override
    public List<Rmk> getAllRmks() {
        return rmkRepository.findAll();
    }

    @Override
    public Rmk getRmkById(Integer id) {
        Optional<Rmk> rmkOptional = rmkRepository.findById(Long.valueOf(id));
        return rmkOptional.orElse(null);
    }

    @Override
    public Rmk createRmk(Rmk rmk) {
        return rmkRepository.save(rmk);
    }

    @Override
    public Rmk updateRmk(Integer id, Rmk rmk) {
        Rmk existingRmk = getRmkById(id);
        if (existingRmk != null) {
            existingRmk.setCode(rmk.getCode());
            existingRmk.setObjective(rmk.getObjective());
            existingRmk.setStartYear(rmk.getStartYear());
            existingRmk.setEndYear(rmk.getEndYear());
            existingRmk.setOverallBudget(rmk.getOverallBudget());
            existingRmk.setActive(rmk.getActive());
            existingRmk.setCreatedBy(rmk.getCreatedBy());
            existingRmk.setCreatedAt(rmk.getCreatedAt());
            existingRmk.setModifiedBy(rmk.getModifiedBy());
            existingRmk.setModifiedAt(rmk.getModifiedAt());
            return rmkRepository.save(existingRmk);
        } else {
            return null;
        }
    }

    @Override
    public void deleteRmk(Integer id) {
        rmkRepository.deleteById(Long.valueOf(id));
    }
}
