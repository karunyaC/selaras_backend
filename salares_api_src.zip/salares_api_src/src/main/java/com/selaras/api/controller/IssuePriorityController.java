package com.selaras.api.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.selaras.api.dto.IssuePriorityDTO;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.service.IssuePriorityService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/issue-priorities")
@RequiredArgsConstructor
public class IssuePriorityController {

    private final IssuePriorityService issuePriorityService;

    @PostMapping
    public ResponseEntity<IssuePriorityDTO> createIssuePriority(@RequestBody IssuePriorityDTO issuePriorityDTO) {
        IssuePriorityDTO createdIssuePriority = issuePriorityService.createIssuePriority(issuePriorityDTO);
        return new ResponseEntity<>(createdIssuePriority, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<IssuePriorityDTO> getIssuePriorityById(@PathVariable Long id) throws ResourceNotFoundException {
        IssuePriorityDTO issuePriorityDTO = issuePriorityService.getIssuePriorityById(id);
        return new ResponseEntity<>(issuePriorityDTO, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<IssuePriorityDTO>> getAllIssuePriorities() {
        List<IssuePriorityDTO> issuePriorities = issuePriorityService.getAllIssuePriorities();
        return new ResponseEntity<>(issuePriorities, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<IssuePriorityDTO> updateIssuePriority(
            @PathVariable Long id, 
            @RequestBody IssuePriorityDTO issuePriorityDTO) throws ResourceNotFoundException {
        IssuePriorityDTO updatedIssuePriority = issuePriorityService.updateIssuePriority(id, issuePriorityDTO);
        return new ResponseEntity<>(updatedIssuePriority, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteIssuePriority(@PathVariable Long id) throws ResourceNotFoundException {
        String responseMessage = issuePriorityService.deleteIssuePriority(id);
        return new ResponseEntity<>(responseMessage, HttpStatus.OK);
    }
}
