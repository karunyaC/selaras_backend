package com.selaras.api.service.impl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.selaras.api.dto.IssuePriorityDTO;
import com.selaras.api.entity.IssuePriority;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.IssuePriorityRepository;
import com.selaras.api.service.IssuePriorityService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class IssuePriorityServiceImpl implements IssuePriorityService {

    private final IssuePriorityRepository issuePriorityRepository;
    private final ModelMapper modelMapper;

    @Override
    public IssuePriorityDTO createIssuePriority(IssuePriorityDTO issuePriorityDTO) {
        IssuePriority issuePriority = modelMapper.map(issuePriorityDTO, IssuePriority.class);
        IssuePriority savedIssuePriority = issuePriorityRepository.save(issuePriority);
        return modelMapper.map(savedIssuePriority, IssuePriorityDTO.class);
    }

    @Override
    public IssuePriorityDTO getIssuePriorityById(Long id) throws ResourceNotFoundException {
        IssuePriority issuePriority = issuePriorityRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Issue priority not found with id: " + id));
        return modelMapper.map(issuePriority, IssuePriorityDTO.class);
    }

    @Override
    public List<IssuePriorityDTO> getAllIssuePriorities() {
        List<IssuePriority> issuePriorities = issuePriorityRepository.findAll();
        if (issuePriorities == null || issuePriorities.isEmpty()) {
            return List.of();
        }
        return issuePriorities.stream()
            .map(issuePriority -> modelMapper.map(issuePriority, IssuePriorityDTO.class))
            .toList();
    }

    @Override
    public IssuePriorityDTO updateIssuePriority(Long id, IssuePriorityDTO issuePriorityDTO) 
            throws ResourceNotFoundException {
        IssuePriority existingIssuePriority = issuePriorityRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Issue priority not found with id: " + id));
        
        modelMapper.map(issuePriorityDTO, existingIssuePriority);
        
        IssuePriority updatedIssuePriority = issuePriorityRepository.save(existingIssuePriority);
        return modelMapper.map(updatedIssuePriority, IssuePriorityDTO.class);
    }

    @Override
    public String deleteIssuePriority(Long id) throws ResourceNotFoundException {
        IssuePriority issuePriority = issuePriorityRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Issue priority not found with id: " + id));
        
        issuePriority.setIsActive(false);
        issuePriorityRepository.save(issuePriority);
        
        return "Issue priority with id: " + id + " has been deactivated successfully.";
    }
}
