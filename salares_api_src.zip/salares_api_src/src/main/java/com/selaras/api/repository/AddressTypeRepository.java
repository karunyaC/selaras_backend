package com.selaras.api.repository;

import com.selaras.api.entity.AddressType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface AddressTypeRepository extends JpaRepository<AddressType, Long>, JpaSpecificationExecutor<AddressType> {

}