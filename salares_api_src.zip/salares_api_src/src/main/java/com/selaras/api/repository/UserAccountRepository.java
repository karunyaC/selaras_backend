package com.selaras.api.repository;

import com.selaras.api.entity.UserAccount;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserAccountRepository extends JpaRepository<UserAccount, Long>, JpaSpecificationExecutor<UserAccount> {
    UserAccount findByName(String username);
    Page<UserAccount> findByNameContainingIgnoreCase(String name, Pageable pageable);

    UserAccount findByEmail(String email);

    UserAccount findByResetToken(String token);

    @Query(value = "SELECT * FROM public.user_account ua WHERE ua.email = :email AND created_at IS NOT NULL ORDER BY id DESC LIMIT 1",
            nativeQuery = true)
    List<UserAccount> findRecent(@Param("email") String email);

    List<UserAccount> findByDepartmentId(Long id);

    List<UserAccount> findByDomainIdIsNotAndDomainIdIsNotNull(Long domainId);

    List<UserAccount> findByNameContainingIgnoreCaseOrEmailContainingIgnoreCase(String searchTerm, String searchTerm1);
}