package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.dto.ModuleAccessLevelDTO;
import com.selaras.api.dto.ModuleDTO;
import com.selaras.api.service.ModuleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

import static org.springframework.util.MimeTypeUtils.IMAGE_PNG_VALUE;


@RestController
@RequestMapping("/api/module")
@RequiredArgsConstructor
public class ModuleController {
private final ModuleService moduleService;

 @Operation(summary = "Get all modules", description = "Retrieve a list of all modules")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/getAll")
    @AuditTrail(recordType = "Module", action = "Retrieve All", presentValue = "All modules retrieved")
    public ResponseEntity<List<ModuleDTO>> getAllModules() {
        List<ModuleDTO> modules = moduleService.getAllModules();
        return new ResponseEntity<>(modules, HttpStatus.OK);
    }
    @Operation(summary = "Get module by ID", description = "Retrieve a module by its ID")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/Id/{id}")
    @AuditTrail(recordType = "Module", action = "Retrieve", presentValue = "Module retrieved with ID: {id}")
    public ResponseEntity<ModuleDTO> getModuleById(@PathVariable Long id) {
        return new ResponseEntity<ModuleDTO>(moduleService.getModuleById(id), HttpStatus.OK);
    }
    @Operation(summary = "Create a new module", description = "Create a new module in the system")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/create")
    @AuditTrail(recordType = "Module", action = "Create", presentValue = "New module created")
    public ResponseEntity<ModuleDTO> createModule(@RequestBody ModuleDTO module) {
        return new ResponseEntity<ModuleDTO>(moduleService.createModule(module), HttpStatus.OK);
    }
    @Operation(summary = "Upload module logo", description = "Upload a logo image for a specific module")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/upload/logo")
    @AuditTrail(recordType = "Module", action = "Upload Logo", presentValue = "Logo uploaded for module")
    public ResponseEntity<String> uploadLogo(@RequestParam("moduleId") Long moduleId, @RequestParam("image") MultipartFile image) {
        return new ResponseEntity<String>(moduleService.uploadLogo(moduleId, image), HttpStatus.OK);
    }
    @Operation(summary = "Delete a module", description = "Delete a module by its ID")
    @ApiResponse(responseCode = "204", description = "No Content")
    @DeleteMapping("/{id}")
    @AuditTrail(recordType = "Module", action = "Delete", presentValue = "Module deleted with ID: {id}")
    public ResponseEntity<Void> deleteModule(@PathVariable Long id) {
        moduleService.deleteModule(id);
        return ResponseEntity.noContent().build();
    }

    //@PostMapping("/{moduleId}/access-levels/{accessLevelId}")
    public ResponseEntity<ModuleAccessLevelDTO> addAccessLevelToModule(@PathVariable Long moduleId,
                                                       @PathVariable Long accessLevelId,
                                                       @RequestParam String additionalInfo) {
        return new ResponseEntity<ModuleAccessLevelDTO>(moduleService.addAccessLevelToModule(moduleId, accessLevelId, additionalInfo), HttpStatus.CREATED);
    }
    @Operation(summary = "Download module logo", description = "Download the logo image of a specific module")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/downloadLogo/{moduleId}")
    @AuditTrail(recordType = "Module", action = "Download Logo", presentValue = "Logo downloaded for module with ID: {moduleId}")
    public ResponseEntity<?> downloadLogo(@PathVariable Long moduleId) {
        byte[] imageData = moduleService.downloadLogo(moduleId);
        return ResponseEntity.status(HttpStatus.OK)
                .contentType(MediaType.valueOf(IMAGE_PNG_VALUE))
                .body(imageData);
    }
}
