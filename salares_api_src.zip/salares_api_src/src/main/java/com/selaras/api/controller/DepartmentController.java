package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.dto.DepartmensUsersRoleDTO;
import com.selaras.api.dto.DepartmentAddressUsersDTO;
import com.selaras.api.dto.DepartmentDTO;
import com.selaras.api.dto.ProjectDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.responses.DepartmentsResponse;
import com.selaras.api.service.DepartmentService;
import com.selaras.api.util.ApplicationConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class DepartmentController {
private final DepartmentService departmentService;

/*
 * Search Department by name response in  pagination 	
 */
@Operation(summary = "Search Department by name", description = "Retrieve a paginated list of departments by name")
@ApiResponse(responseCode = "200", description = "OK")
@GetMapping("/dept/Name/{name}")
@AuditTrail(recordType = "Department", action = "Search Department by Name", presentValue = "Departments retrieved by name")
public ResponseEntity<DepartmentsResponse> getDepartmentByName(
        @RequestParam(value = "pageNo", defaultValue = ApplicationConstants.DEFAULT_PAGE_NUMBER, required = false) int pageNo,
        @RequestParam(value = "pageSize", defaultValue = ApplicationConstants.DEFAULT_PAGE_SIZE, required = false) int pageSize,
        @RequestParam(value = "sortBy", defaultValue = ApplicationConstants.DEFAULT_SORT_BY, required = false) String sortBy,
        @RequestParam(value = "orderBy", defaultValue = ApplicationConstants.DEFAULT_ORDER_BY, required = false) String orderBy,
        @PathVariable(value = "name") String name) throws ResourceNotFoundException {
	return new ResponseEntity<>(departmentService.getDepartmentByName(pageNo,pageSize,sortBy,orderBy,name),HttpStatus.OK);
	
}

/*
 * Add Department
 */
@Operation(summary = "Add Department", description = "Create a new department")
@ApiResponse(responseCode = "201", description = "Created")
@PostMapping("/create")
@AuditTrail(recordType = "Department", action = "Add Department", presentValue = "Department created")
public ResponseEntity<DepartmentAddressUsersDTO> createDepartment(@RequestBody DepartmentAddressUsersDTO departmentDTO) {
	DepartmentAddressUsersDTO savedDepartmentDTO = departmentService.createDepartment(departmentDTO);
	return new ResponseEntity<>(savedDepartmentDTO, HttpStatus.CREATED);
}
	
/*
 * Get Department by id
 */
@Operation(summary = "Get Department by ID", description = "Retrieve a department by its ID")
@ApiResponse(responseCode = "200", description = "OK")
@GetMapping("/dept/id/{id}")
@AuditTrail(recordType = "Department", action = "Get Department by ID", presentValue = "Department retrieved by ID")
public ResponseEntity<DepartmentDTO> getDepartmentById(@PathVariable("id") Long id) throws ResourceNotFoundException{
	DepartmentDTO departmentDTO=null;
    departmentDTO = departmentService.getDepartmentById(id);
    return new ResponseEntity<>(departmentDTO,HttpStatus.OK);
}

	@Operation(summary = "Get All departments", description = "getAllDepartments")
	@ApiResponse(responseCode = "200", description = "OK")
	@GetMapping("/dept")
	@AuditTrail(recordType = "Department", action = "Get All Departments", presentValue = "All departments retrieved")
	public ResponseEntity<List<DepartmentDTO>> getDepartments() throws ResourceNotFoundException{
		List<DepartmentDTO> departmentDTO=new ArrayList<>();
		departmentDTO.addAll(departmentService.getAllDepartments());
		return new ResponseEntity<>(departmentDTO,HttpStatus.OK);
	}
	@Operation(summary = "Get All Departmens Users Role DTO", description = "getAllDepartments")
	@ApiResponse(responseCode = "200", description = "OK")
	@GetMapping("/deptroles/{id}")
	@AuditTrail(recordType = "Department", action = "Get All Departmens Users Role DTO", presentValue = "All departments retrieved")
	public ResponseEntity<List<DepartmensUsersRoleDTO>> getDepartmentsuser(@PathVariable long id) throws ResourceNotFoundException{
		List<DepartmensUsersRoleDTO> departmentDTO= departmentService.getallDepartmensUsersRoleDTO(id);
		return new ResponseEntity<>(departmentDTO,HttpStatus.OK);
	}


	@Operation(summary = "Get All departments for Departments menu", description = "getAllDepartments")
	@ApiResponse(responseCode = "200", description = "OK")
	@GetMapping("/dept-main")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@AuditTrail(recordType = "Department", action = "Get All Departments for dept menu", presentValue = "All departments retrieved")
	public ResponseEntity<List<DepartmentAddressUsersDTO>> getDepartmentsMenu() throws ResourceNotFoundException{
		List<DepartmentAddressUsersDTO> departmentDTO=new ArrayList<>();
		departmentDTO.addAll(departmentService.getAllDepartmentsByAddressUsersDTO());
		return new ResponseEntity<>(departmentDTO,HttpStatus.OK);
	}

/*
* update Department
*/
@Operation(summary = "Update Department", description = "Update an existing department")
@ApiResponse(responseCode = "200", description = "OK")	
@PutMapping("/dept/update/{id}")
@AuditTrail(recordType = "Department", action = "Update Department", previousValue = "Department details before update", presentValue = "Department updated with ID")
public ResponseEntity<DepartmentDTO> updateDepartment(@RequestBody DepartmentDTO departmentDTOReq, @PathVariable("id") Long id) throws ResourceNotFoundException, BadRequestException {
	DepartmentDTO departmentDTO=departmentService.updateDepartment(departmentDTOReq, id);
	return new ResponseEntity<>(departmentDTO,HttpStatus.OK);
}
/*
* Delete Department
*/
@Operation(summary = "Delete Department", description = "Delete a department by its ID")
@ApiResponse(responseCode = "200", description = "OK")
@DeleteMapping("/dept/id")
@AuditTrail(recordType = "Department", action = "Delete Department", presentValue = "Department deleted with ID")
public void deleteDepartment(@RequestParam Long[] id) throws ResourceNotFoundException {
	departmentService.deleteDepartment(id);
}
	
/*
 * 	Add Project 
 */
@Operation(summary = "Add Project to Department", description = "Add a project to a department by department ID")
@ApiResponse(responseCode = "200", description = "OK")
@PostMapping("/dept/id/{id}")
@AuditTrail(recordType = "Project", action = "Add Project to Department", presentValue = "Project added to department with ID")
public ResponseEntity<ProjectDTO> addProjectToDepartment(@PathVariable("id") Long id, @RequestBody ProjectDTO projectDTOReq) throws ResourceNotFoundException {
	ProjectDTO projectDTO=departmentService.addProjcetToDepartment(id,projectDTOReq);
	return new ResponseEntity<>(projectDTO,HttpStatus.OK);
}
	
/*
 *  Delete Project 
 */
@Operation(summary = "Delete Project from Department", description = "Delete a project from a department by department ID and project ID")
@ApiResponse(responseCode = "200", description = "OK")
@DeleteMapping("/dept/id/{id}/{projectId}")
@AuditTrail(recordType = "Project", action = "Delete Project from Department", presentValue = "Project removed from department ID and project ID")
public void deleteProjectFromDepartment(@PathVariable("id") Long id, @PathVariable("projectId") Long projectId) throws ResourceNotFoundException {
	departmentService.deleteProjectFromDepartment(id,projectId);
}
		

}
