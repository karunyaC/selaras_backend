package com.selaras.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.selaras.api.entity.Rmk;
import com.selaras.api.service.RmkService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/rmks")
public class RmkController {
    private final RmkService rmkService;

    @GetMapping
    public List<Rmk> getAllRmks() {
        return rmkService.getAllRmks();
    }

    @GetMapping("/{id}")
    public Rmk getRmkById(@PathVariable Integer id) {
        return rmkService.getRmkById(id);
    }

    @PostMapping
    public Rmk createRmk(@RequestBody Rmk rmk) {
        return rmkService.createRmk(rmk);
    }

    @PutMapping("/{id}")
    public Rmk updateRmk(@PathVariable Integer id, @RequestBody Rmk rmk) {
        return rmkService.updateRmk(id, rmk);
    }

    @DeleteMapping("/{id}")
    public void deleteRmk(@PathVariable Integer id) {
        rmkService.deleteRmk(id);
    }
}
