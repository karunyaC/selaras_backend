package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.dto.DepartmentAddressUsersDTO;
import com.selaras.api.dto.SubDepartmentDTO;
import com.selaras.api.entity.SubDepartment;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.service.SubDepartmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class SubDepartmentController {

    private final SubDepartmentService subDepartmentService;
    @Operation(summary = "Search Sub Department by name", description = "Retrieve a paginated list of sub departments by name")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/sub/dept/name/{name}")
    @AuditTrail(recordType = "Sub Department", action = "Search Sub Department by Name", presentValue = "Sub Departments retrieved by name")
    public ResponseEntity<SubDepartmentDTO> getSubDepartmentByName(
            @PathVariable(value = "name") String name) throws ResourceNotFoundException {
        return new ResponseEntity<>(subDepartmentService.getSubDepartmentByName(name), HttpStatus.OK);

    }

    @Operation(summary = "Get All sub departments", description = "getAllSubDepartments")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/sub/dept")
    @AuditTrail(recordType = "Sub Department", action = "Get All Sub Departments", presentValue = "All Sub departments retrieved")
    public ResponseEntity<List<SubDepartmentDTO>> getAllSubDepartments() throws ResourceNotFoundException{
        return new ResponseEntity<>(subDepartmentService.getAllSubDepartments(),HttpStatus.OK);
    }

    /*
     * Get Department by id
     */
    @Operation(summary = "Get Sub Department by ID", description = "Retrieve a sub department by its ID")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/sub/dept/id/{id}")
    @AuditTrail(recordType = "Sub Department", action = "Get Sub Department by ID", presentValue = "sub Department retrieved by ID")
    public ResponseEntity<SubDepartmentDTO> getSubDepartmentById(@PathVariable("id") Long id) throws ResourceNotFoundException{

        return new ResponseEntity<>(subDepartmentService.getSubDepartmentById(id),HttpStatus.OK);
    }


    /*
     * Add Department
     */
    @Operation(summary = "Add Sub Department", description = "Create a new sub department")
    @ApiResponse(responseCode = "201", description = "Created")
    @PostMapping("/sub/dept/create")
    @AuditTrail(recordType = "Sub Department", action = "Add Sub Department", presentValue = "Sub Department created")
    public ResponseEntity<SubDepartmentDTO> createSubDepartment(@RequestBody SubDepartmentDTO subDepartmentDTO) throws ResourceNotFoundException {
        return new ResponseEntity<>(subDepartmentService.createSubDepartment(subDepartmentDTO), HttpStatus.CREATED);
    }



}
