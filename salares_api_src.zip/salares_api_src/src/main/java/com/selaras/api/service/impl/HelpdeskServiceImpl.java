package com.selaras.api.service.impl;

import com.selaras.api.entity.Helpdesk;
import com.selaras.api.entity.HelpdeskFile;
import com.selaras.api.entity.HelpdeskTicketLog;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.HelpdeskFileRepository;
import com.selaras.api.repository.HelpdeskRepository;
import com.selaras.api.repository.HelpdeskTicketLogRepository;
import com.selaras.api.requests.HelpdeskLogRequest;
import com.selaras.api.requests.HelpdeskRequest;
import com.selaras.api.requests.HelpdeskStatusUpdateRequest;
import com.selaras.api.responses.HelpdeskFileResponse;
import com.selaras.api.responses.HelpdeskGroupedResponse;
import com.selaras.api.responses.HelpdeskTicketLogResponse;
import com.selaras.api.service.HelpdeskService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HelpdeskServiceImpl implements HelpdeskService {


    private final HelpdeskRepository helpdeskRepository;


    private final HelpdeskFileRepository helpdeskFileRepository;


    private final HelpdeskTicketLogRepository helpdeskTicketLogRepository;

    @Override
    @Transactional
    public String saveHelpdeskWithFiles(HelpdeskRequest request) {
        Helpdesk helpDesk = new Helpdesk();
        helpDesk.setOs(request.getOs());
        helpDesk.setLink(request.getLink());
        helpDesk.setBrowser(request.getBrowser());
        helpDesk.setCreatedBy(request.getCreatedBy());
        helpDesk.setCriticalLevel(request.getCriticalLevel());
        helpDesk.setSrDescription(request.getSrDescription());
        helpDesk.setStatus("OPEN");
        helpDesk.setSrTitle(request.getSrTitle());
        Helpdesk savedHelpDesk = helpdeskRepository.save(helpDesk);

        request.getFiles().forEach(file -> {
            HelpdeskFile helpdeskFile = new HelpdeskFile();
            helpdeskFile.setFilePath(file.getFilePath());
            helpdeskFile.setCreatedBy(file.getCreatedBy());
            helpdeskFile.setHelpdesk(savedHelpDesk);
            helpdeskFileRepository.save(helpdeskFile);
        });

        HelpdeskTicketLog log = new HelpdeskTicketLog();
        log.setHelpdesk(savedHelpDesk);
        log.setComment("New Ticket created");
        log.setCommentBy(request.getCreatedBy());
        helpdeskTicketLogRepository.save(log);
        return "Service request raised with SR Number: #" + savedHelpDesk.getSrNumber();
    }

    @Override
    public String saveHelpdeskLog(HelpdeskLogRequest request) throws ResourceNotFoundException {

        Helpdesk helpdesk = helpdeskRepository.findBySrNumber(request.getSrNumber());
        if (helpdesk == null) {
            throw new ResourceNotFoundException("No SR found with this given number");
        }
        HelpdeskTicketLog log = new HelpdeskTicketLog();
        log.setHelpdesk(helpdesk);
        log.setComment(request.getComment());
        log.setCommentBy(request.getCommentBy());
        helpdeskTicketLogRepository.save(log);

        return "SR comments updated successfully";
    }

    @Override
    public String updateStatus(HelpdeskStatusUpdateRequest request) throws ResourceNotFoundException, BadRequestException {
        Helpdesk helpdesk = helpdeskRepository.findBySrNumber(request.getSrNumber());
        if (helpdesk == null) {
            throw new ResourceNotFoundException("No SR found with this given number");
        }

        if (!Arrays.asList("OPEN", "CLOSED").contains(request.getStatus().toUpperCase())) {
            throw new BadRequestException("Invalid status provided to update");
        }
        helpdesk.setStatus(request.getStatus());
        helpdeskRepository.save(helpdesk);

        return "SR status have been updated";
    }

    @Override
    public Object getAllHelpDeskTickets() {
        List<Helpdesk> helpdeskList = helpdeskRepository.findAll();
        List<HelpdeskFile> helpdeskFiles = helpdeskFileRepository.findAll();
        List<HelpdeskTicketLog> helpdeskTicketLogs = helpdeskTicketLogRepository.findAll();

        Map<Integer, List<HelpdeskFileResponse>> filesBySrNumber = helpdeskFiles.stream()
                .collect(Collectors.groupingBy(
                        file -> file.getHelpdesk().getSrNumber(),
                        Collectors.mapping(
                                file -> new HelpdeskFileResponse(file.getId(), file.getFilePath(), file.getCreatedBy(), file.getCreatedAt()),
                                Collectors.toList()
                        )
                ));

        Map<Integer, List<HelpdeskTicketLogResponse>> logsBySrNumber = helpdeskTicketLogs.stream()
                .collect(Collectors.groupingBy(
                        log -> log.getHelpdesk().getSrNumber(),
                        Collectors.mapping(
                                log -> new HelpdeskTicketLogResponse(log.getId(), log.getComment(), log.getCommentBy(), log.getCommentAt()),
                                Collectors.toList()
                        )
                ));

        return helpdeskList.stream()
                .map(helpdesk -> new HelpdeskGroupedResponse(
                        helpdesk.getSrNumber(),
                        helpdesk.getSrTitle(),
                        helpdesk.getSrDescription(),
                        helpdesk.getBrowser(),
                        helpdesk.getOs(),
                        helpdesk.getLink(),
                        helpdesk.getCriticalLevel(),
                        helpdesk.getStatus(),
                        helpdesk.getCreatedBy(),
                        helpdesk.getCreatedAt(),
                        helpdesk.getUpdatedBy(),
                        helpdesk.getUpdatedAt(),
                        filesBySrNumber.getOrDefault(helpdesk.getSrNumber(), Collections.emptyList()),
                        logsBySrNumber.getOrDefault(helpdesk.getSrNumber(), Collections.emptyList())
                )).sorted(Comparator.comparing(HelpdeskGroupedResponse::getSrNumber))
                .collect(Collectors.toList());
    }
}
