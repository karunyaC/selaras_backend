package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.dto.DistrictStateAssemblyDTO;
import com.selaras.api.dto.KpiYearsDTO;
import com.selaras.api.dto.MeasuringUnitKpiDTO;
import com.selaras.api.dto.ProjectStartAndEndYearDTO;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.requests.ProjectCategoryRequest;
import com.selaras.api.requests.ProjectStatusRequest;
import com.selaras.api.requests.ProjectStrategicPlanRequest;
import com.selaras.api.service.DataDictionaryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor

public class DataDictionaryController {

    private final DataDictionaryService dataDictionaryService;

    @Operation(summary = "Save Project Status", description = "Save Project Status parameters")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/project/status")
    @AuditTrail(recordType = "ProjectStatus", action = "Save Project Status", presentValue = "Project status saved")
    public ResponseEntity<?> saveProjectStatus(@RequestBody ProjectStatusRequest request) throws BadRequestException {
        return ResponseEntity.ok().body(dataDictionaryService.saveProjectStatus(request));
    }

    @Operation(summary = "Get Project Status", description = "Retrieve all project status")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/project/status")
    @AuditTrail(recordType = "ProjectStatus", action = "Retrieve Project Status", presentValue = "All project statuses retrieved")
    public ResponseEntity<?> getAllProjectStatus() throws BadRequestException {
        return ResponseEntity.ok().body(dataDictionaryService.getAllProjectStatus());
    }

    @Operation(summary = "Save Project Category", description = "Save Project Category parameters")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/project/category")
    @AuditTrail(recordType = "ProjectCategory", action = "Save Project Category", presentValue = "Project category saved")
    public ResponseEntity<?> saveProjectCategory(@RequestBody ProjectCategoryRequest request) throws BadRequestException {
        return ResponseEntity.ok().body(dataDictionaryService.saveProjectCategory(request));
    }

    @Operation(summary = "Get Project Category", description = "Retrieve all project categories")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/project/category")
    @AuditTrail(recordType = "ProjectCategory", action = "Retrieve Project Category", presentValue = "All project categories retrieved")
    public ResponseEntity<?> getAllProjectCategory() throws BadRequestException {
        return ResponseEntity.ok().body(dataDictionaryService.getAllProjectCategory());
    }

    @Operation(summary = "Save Strategic Plan", description = "Save Strategic Plan parameters")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/project/stategic/plan")
    @AuditTrail(recordType = "StrategicPlan", action = "Save Strategic Plan", presentValue = "Strategic plan saved")
    public ResponseEntity<?> saveProjectStrategicPlan(@RequestBody ProjectStrategicPlanRequest request) throws BadRequestException {
        return ResponseEntity.ok().body(dataDictionaryService.saveProjectStrategicPlan(request));
    }

    @Operation(summary = "Get Strategic Plan", description = "Retrieve all Strategic Plans")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/project/stategic/plan")
    @AuditTrail(recordType = "StrategicPlan", action = "Retrieve Strategic Plan", presentValue = "All strategic plans retrieved")
    public ResponseEntity<?> getAllProjectStrategicPlan() throws BadRequestException {
        return ResponseEntity.ok().body(dataDictionaryService.getAllProjectStrategicPlan());
    }

    @Operation(summary = "Save DistrictStateAssembly", description = "Persist Values to DB for DistrictStateAssembly")
    @ApiResponse(responseCode = "201", description = "Created")
    @PostMapping("/project/district-state-assembly")
    @AuditTrail(recordType = "DistrictStateAssembly", action = "Save District State Assembly", presentValue = "District State Assembly saved")
    public ResponseEntity<DistrictStateAssemblyDTO> saveDistrictStateAssembly(@RequestBody DistrictStateAssemblyDTO request) throws BadRequestException {
        return ResponseEntity.status( HttpStatus.CREATED).body( dataDictionaryService.saveDistrictStateAssembly(request));
    }

    @Operation(summary = "Get DistrictStateAssembly", description = "Retrieve all DistrictStateAssembly")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/project/district-state-assembly")
    @AuditTrail(recordType = "DistrictStateAssembly", action = "Retrieve District State Assembly", presentValue = "All District State Assemblies retrieved")
    public ResponseEntity< List<DistrictStateAssemblyDTO> > getDistrictStateAssembly() throws BadRequestException {
        return ResponseEntity.ok().body(dataDictionaryService.getDistrictStateAssembly());
    }

    @Operation(summary = "Save KPI Years", description = "Persist Values to DB for KPI Years")
    @ApiResponse(responseCode = "201", description = "Created")
    @PostMapping("/project/kpi-years")
    @AuditTrail(recordType = "KpiYears", action = "Save KPI Years", presentValue = "KPI years saved")
    public ResponseEntity< KpiYearsDTO > saveKpiYears( @RequestBody KpiYearsDTO request) throws BadRequestException {
        return ResponseEntity.status( HttpStatus.CREATED).body( dataDictionaryService.saveKpiYears(request));
    }

    @Operation(summary = "Get KPI Years", description = "Retrieve all KPI years")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/project/kpi-years")
    @AuditTrail(recordType = "KpiYears", action = "Retrieve KPI Years", presentValue = "All KPI years retrieved")
    public ResponseEntity< List<KpiYearsDTO> > getKpiYears() throws BadRequestException {
        return ResponseEntity.ok().body(dataDictionaryService.getKpiYears());
    }

    @Operation(summary = "Save Project Years", description = "Persist Values to DB for Project Start and End Years")
    @ApiResponse(responseCode = "201", description = "Created")
    @PostMapping("/project/start-end-years")
    @AuditTrail(recordType = "ProjectYears", action = "Save Project Years", presentValue = "Project start and end years saved")
    public ResponseEntity< ProjectStartAndEndYearDTO > saveProjectYears( @RequestBody ProjectStartAndEndYearDTO request) throws BadRequestException {
        return ResponseEntity.status( HttpStatus.CREATED).body( dataDictionaryService.saveProjectYears(request));
    }

    @Operation(summary = "Get Project Years", description = "Retrieve all Project years")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/project/start-end-years")
    @AuditTrail(recordType = "ProjectYears", action = "Retrieve Project Years", presentValue = "All project start and end years retrieved")
    public ResponseEntity< List<ProjectStartAndEndYearDTO> > getProjectYears() throws BadRequestException {
        return ResponseEntity.ok().body(dataDictionaryService.getProjectYears());
    }

    @Operation(summary = "Save Measuring Unit KPI", description = "Persist Values to DB for Measuring Unit for KPI")
    @ApiResponse(responseCode = "201", description = "Created")
    @PostMapping("/project/kpi-measuring-unit")
    @AuditTrail(recordType = "MeasuringUnitKpi", action = "Save Measuring Unit KPI", presentValue = "Measuring unit for KPI saved")
    public ResponseEntity< MeasuringUnitKpiDTO > saveMeasuringUnit( @RequestBody MeasuringUnitKpiDTO request) throws BadRequestException {
        return ResponseEntity.status( HttpStatus.CREATED).body( dataDictionaryService.saveMeasuringUnit(request));
    }

    @Operation(summary = "Get Measuring Unit KPI", description = "Retrieve all Measuring Unit KPI")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/project/kpi-measuring-unit")
    @AuditTrail(recordType = "MeasuringUnitKpi", action = "Retrieve Measuring Unit KPI", presentValue = "All measuring units for KPI retrieved")
    public ResponseEntity< List<MeasuringUnitKpiDTO> > getMeasuringUnit() throws BadRequestException {
        return ResponseEntity.ok().body(dataDictionaryService.getMeasuringUnit());
    }
}
