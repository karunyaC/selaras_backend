package com.selaras.api.requests;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class HelpdeskRequest {
    private String srNumber;
    private String srTitle;
    private String srDescription;
    private String browser;
    private String os;
    private String link;
    private String criticalLevel;
    private String status;
    private String createdBy;
    private LocalDateTime createdAt;
    private List<HelpdeskFileDTO> files;
}
