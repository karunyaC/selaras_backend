package com.selaras.api.requests;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuditTrailRequest {

    private String userEmail;

    private String recordType;

    private String action;

    private String previousValue;

    private String presentValue;
}
