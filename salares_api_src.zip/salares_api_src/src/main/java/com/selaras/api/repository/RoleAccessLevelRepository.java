package com.selaras.api.repository;

import com.selaras.api.entity.RoleAccessLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface RoleAccessLevelRepository extends JpaRepository<RoleAccessLevel, Long>, JpaSpecificationExecutor<RoleAccessLevel> {

}