package com.selaras.api.service;

import com.selaras.api.requests.GlobalSearchRequest;
import com.selaras.api.responses.GlobalSearchResponse;

import java.util.List;
import java.util.Map;

public interface GlobalSearchService {
    GlobalSearchResponse search(GlobalSearchRequest searchRequest);
}
