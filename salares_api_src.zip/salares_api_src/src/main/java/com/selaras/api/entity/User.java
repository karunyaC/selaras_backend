package com.selaras.api.entity;

public record User(String name,
                   String email,
                   String password) {

}
