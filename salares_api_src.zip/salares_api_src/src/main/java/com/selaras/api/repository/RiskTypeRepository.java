package com.selaras.api.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.selaras.api.entity.RiskType;

public interface RiskTypeRepository extends JpaRepository<RiskType, Long>, JpaSpecificationExecutor<RiskType> {
    
}
