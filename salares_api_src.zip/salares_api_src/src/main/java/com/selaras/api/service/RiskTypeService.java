package com.selaras.api.service;

import java.util.List;

import com.selaras.api.dto.RiskTypeDTO;

public interface RiskTypeService {
    List<RiskTypeDTO> getAll();
    String updateById(RiskTypeDTO riskTypeDTO,long id);
    String bulkDeletes(List<Long> ids);
    RiskTypeDTO createNew(RiskTypeDTO riskTypeDTO);      
}
