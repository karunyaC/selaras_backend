package com.selaras.api.service.impl;

import com.selaras.api.dto.DepartmentDTO;
import com.selaras.api.dto.RoleDTO;
import com.selaras.api.dto.UsersDTO;
import com.selaras.api.entity.Department;
import com.selaras.api.entity.Role;
import com.selaras.api.entity.UserAccount;
import com.selaras.api.repository.DepartmentRepository;
import com.selaras.api.repository.RoleRepository;
import com.selaras.api.repository.UserAccountRepository;
import com.selaras.api.requests.GlobalSearchRequest;
import com.selaras.api.responses.GlobalSearchResponse;
import com.selaras.api.service.GlobalSearchService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class GlobalSearchServiceImpl implements GlobalSearchService {

    private final UserAccountRepository userAccountRepository;
    private final DepartmentRepository departmentRepository;
    private final RoleRepository roleRepository;
    private final ModelMapper modelMapper;

    @Override
    public GlobalSearchResponse search(GlobalSearchRequest searchRequest) {
        String searchTerm = searchRequest.getSearchTerm();

        List<UserAccount> users = userAccountRepository.findByNameContainingIgnoreCaseOrEmailContainingIgnoreCase(searchTerm, searchTerm);
        List<UsersDTO> usersDTOS = new ArrayList<>();
        users.forEach(u -> {
            usersDTOS.add(modelMapper.map(u, UsersDTO.class));
        });

        List<Department> departments = departmentRepository.findByNameContainingIgnoreCase(searchTerm);
        List<DepartmentDTO> departmentDTOS = new ArrayList<>();
        departments.forEach(d -> {
            departmentDTOS.add(modelMapper.map(d, DepartmentDTO.class));
        });

        List<Role> roles = roleRepository.findByNameContainingIgnoreCase(searchTerm);
        List<RoleDTO> rolesDTO = new ArrayList<>();
        roles.forEach(r -> {
            rolesDTO.add(modelMapper.map(r, RoleDTO.class));
        });

        GlobalSearchResponse globalSearchResponse = new GlobalSearchResponse();
        globalSearchResponse.setUsers(usersDTOS);
        globalSearchResponse.setDepartments(departmentDTOS);
        globalSearchResponse.setRoles(rolesDTO);

        return globalSearchResponse;
    }

}
