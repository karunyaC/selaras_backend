package com.selaras.api.dto;


import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class EmailTemplateDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long templateId;

    private String templateName;

    private String subject;

    private String body;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private Boolean active;

}
