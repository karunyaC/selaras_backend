package com.selaras.api.service.impl;

import com.selaras.api.config.MinioConfig;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.service.FileHandlerService;
import io.minio.*;
import io.minio.errors.*;
import lombok.RequiredArgsConstructor;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class FileHandlerServiceImpl extends MinioConfig implements FileHandlerService {
    @Override
    public Object uploadFile(String bucketName, MultipartFile file) throws BadRequestException, IOException, ServerException, InsufficientDataException, ErrorResponseException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        String fileName = file.getOriginalFilename();
        InputStream inputStream = file.getInputStream();
        String bucket = "selaras";
        MinioClient client = getMinioClient();
        String objectPath = SecurityContextHolder.getContext().getAuthentication().getPrincipal() == null ? "test" : SecurityContextHolder.getContext().getAuthentication().getPrincipal() + "/" + fileName;
        client.putObject(
                PutObjectArgs.builder()
                        .bucket(bucket)
                        .object(objectPath)
                        .stream(inputStream, file.getSize(), -1)
                        .contentType(file.getContentType())
                        .build()
        );
        System.out.println("C:\\Users\\WIN\\OneDrive\\Desktop\\test.txt");
        return "Uploaded to " + objectPath;
    }

    @Override
    public Map<InputStream, String> downloadFile(String filePath) throws BadRequestException, ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        String bucket = "selaras"; // Bucket name
        MinioClient client = getMinioClient();

        // Get the object from the bucket
        InputStream inputStream = client.getObject(
                GetObjectArgs.builder()
                        .bucket(bucket)
                        .object(filePath)
                        .build()
        );

        String contentType = client.statObject(
                StatObjectArgs.builder()
                        .bucket(bucket)
                        .object(filePath)
                        .build()
        ).contentType();

        Map<InputStream, String> map = new HashMap<>();
        map.put(inputStream, contentType);
        return map;
    }
}
