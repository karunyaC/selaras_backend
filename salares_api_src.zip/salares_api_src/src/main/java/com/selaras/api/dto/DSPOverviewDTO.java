package com.selaras.api.dto;


import java.sql.Timestamp;

public class DSPOverviewDTO {

    private Long rowId;

    private String code;

    private String planCode;

    private String startYear;

    private String endYear;

    private Integer numCores;

    private Integer numStrategies;

    private String statusLookup;

    private Timestamp createdAt;

    private Timestamp modifiedAt;
}