package com.selaras.api.service;

import com.selaras.api.dto.DivisionDTO;

import java.util.List;

public interface DivisionService {

    DivisionDTO saveDivision( DivisionDTO request );

    DivisionDTO updateDivision( DivisionDTO request );

    List< DivisionDTO > getAllDivision();

    void deleteByDivisionId( Long id );
}
