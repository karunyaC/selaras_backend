package com.selaras.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.selaras.api.entity.RiskCategory;

public interface RiskCatRepository extends JpaRepository<RiskCategory, Long>, JpaSpecificationExecutor<RiskCategory> {
    
}
