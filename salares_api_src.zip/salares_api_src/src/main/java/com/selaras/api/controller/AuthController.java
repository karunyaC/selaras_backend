
package com.selaras.api.controller;


import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.entity.UserAccount;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.exception.UnauthorizedException;
import com.selaras.api.helper.JwtHelper;
import com.selaras.api.repository.UserAccountRepository;
import com.selaras.api.responses.*;
import com.selaras.api.service.UserService;
import com.selaras.api.util.CommonUtils;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.servlet.UnavailableException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping(path = "/api/auth", produces = MediaType.APPLICATION_JSON_VALUE)
@RequiredArgsConstructor
public class AuthController {

    private final UserAccountRepository userAccountRepository;
    private final AuthenticationManager authenticationManager;
    private final UserService userService;

    private final CommonUtils commonUtils;

    @Operation(summary = "Signup user")
    @ApiResponse(responseCode = "201")
    @ApiResponse(responseCode = "404", content = @Content(schema = @Schema(implementation = ApiErrorResponse.class)))
    @ApiResponse(responseCode = "409", content = @Content(schema = @Schema(implementation = ApiErrorResponse.class)))
    @ApiResponse(responseCode = "500", content = @Content(schema = @Schema(implementation = ApiErrorResponse.class)))
    @Hidden
    @PostMapping("/signup")
    @AuditTrail(recordType = "Registration", action = "User sign up", presentValue = "User signed up")
    public ResponseEntity<String> signup(@Valid @RequestBody SignupRequest requestDto) throws BadRequestException {
        userService.signup(requestDto);
        return ResponseEntity.ok().body("User created successfully");
    }

    @Operation(summary = "Authenticate user and return token")
    @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation = LoginResponse.class)))
    @ApiResponse(responseCode = "401", content = @Content(schema = @Schema(implementation = ApiErrorResponse.class)))
    @ApiResponse(responseCode = "404", content = @Content(schema = @Schema(implementation = ApiErrorResponse.class)))
    @ApiResponse(responseCode = "500", content = @Content(schema = @Schema(implementation = ApiErrorResponse.class)))
    @PostMapping(value = "/login")
    @AuditTrail(recordType = "Authentication and Authorization", action = "Login successful for user", presentValue = "User logged in")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request, HttpServletRequest httpRequest) throws UnauthorizedException, UnavailableException {

        // Uncomment when UI is ready to integrate captcha
       /* HttpSession session = httpRequest.getSession(false);
        if (session == null) {
            throw new UnauthorizedException("Invalid session");
        }
        String expectedCaptchaCode = (String) session.getAttribute("captcha");
        if (expectedCaptchaCode == null || !request.captcha().equalsIgnoreCase(expectedCaptchaCode)) {
            throw new UnauthorizedException("Invalid captcha");
        }*/

        /*UserAccount user = userAccountRepository.findByEmail(request.email());
        if(user.getLoginCaptcha() != null && !user.getLoginCaptcha().trim().equalsIgnoreCase(request.captcha().trim())) {
            throw new UnavailableException("Invalid Captcha");
        } else {
            user.setLoginCaptcha(null);
            userAccountRepository.save(user);
        }*/

        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.email(), request.password()));


        Map<String, String> token = JwtHelper.generateTokens(request.email());
        return ResponseEntity.ok(new LoginResponse(request.email(), token.get("accessToken"), token.get("refreshToken")));
    }

    @Operation(summary = "Get Captcha", description = "Generate and send Captcha image")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/captcha")
    @AuditTrail(recordType = "Authorization", action = "Retrieve captcha to run", presentValue = "Captcha retrieved")
    public void loadCaptcha(HttpServletRequest request, HttpServletResponse response, @RequestParam String email) throws BadRequestException, IOException, ResourceNotFoundException {

        commonUtils.getCaptchaImage(request, response, email);
    }

    private List<LoginAttemptResponse> convertToDTOs(List<UserAccount> loginAttempts) {
        return loginAttempts.stream()
                .map(LoginAttemptResponse::convertToFrom)
                .collect(Collectors.toList());
    }
}