package com.selaras.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.selaras.api.entity.SPCore;

@Repository
public interface SPCoreRepository extends JpaRepository<SPCore, Integer> {
    List<SPCore> findBySpOverviewSpCode(String spCode);
    SPCore findBySpCoreId(String spCoreId);

    SPCore findBySpCorePreferredName(String spCorePreferredName);
}
