package com.selaras.api.dto;


import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;
@Data
public class KpiYearsDTO {

    private Long id;
    private String code;
    private List<LocalDateTime> years;
    private Boolean active;
    private String createdBy;
    private LocalDateTime createdAt;
    private String modifiedBy;
    private LocalDateTime modifiedAt;
}
