package com.selaras.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.selaras.api.entity.RSStrategy;

@Repository
public interface RSStrategyRepository extends JpaRepository<RSStrategy, Long>{
    
}
