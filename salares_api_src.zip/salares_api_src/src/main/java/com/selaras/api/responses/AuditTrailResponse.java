package com.selaras.api.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuditTrailResponse {
    private int id;
    private String userEmail;

    private String recordType;

    private String action;

    private String createdAt;
}
