package com.selaras.api.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.selaras.api.dto.RiskTypeDTO;
import com.selaras.api.service.RiskTypeService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/risk")
public class RiskTypeController {

    private final RiskTypeService riskTypeService;
    
    @GetMapping("/getall")
    @Operation(summary = "Get all Risk Types", description = "Retrieves a list of all Risk Types.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of Risk Types"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<List<RiskTypeDTO>> getAll() {
        List<RiskTypeDTO> riskTypeDTOs = riskTypeService.getAll();
        return ResponseEntity.ok(riskTypeDTOs);
    }

    @PostMapping("/create")
    @Operation(summary = "Create a new Risk Type", description = "Creates a new Risk Type based on the provided data.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Successfully created Risk Type"),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<RiskTypeDTO> create(@RequestBody RiskTypeDTO riskTypeDTO) {
        RiskTypeDTO createdRiskType = riskTypeService.createNew(riskTypeDTO);
        return ResponseEntity.ok(createdRiskType);
    }

    @PutMapping("/update/{id}")
    @Operation(summary = "Update an existing Risk Type", description = "Updates an existing Risk Type by ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully updated Risk Type"),
        @ApiResponse(responseCode = "404", description = "Risk Type not found"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<String> update(@PathVariable long id, @RequestBody RiskTypeDTO riskTypeDTO) {
        String result = riskTypeService.updateById(riskTypeDTO, id);
        return ResponseEntity.ok(result);
    }

    @DeleteMapping("/bulkdelete")
    @Operation(summary = "Bulk delete Risk Types", description = "Deactivates multiple Risk Types by their IDs.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully deactivated Risk Types"),
        @ApiResponse(responseCode = "404", description = "Some Risk Types not found"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<String> bulkDelete(@RequestBody List<Long> ids) {
        String result = riskTypeService.bulkDeletes(ids);
        return ResponseEntity.ok(result);
    }

}
