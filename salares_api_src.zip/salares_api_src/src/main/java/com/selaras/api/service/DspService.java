package com.selaras.api.service;

import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.requests.DspSaveDTO;

import java.util.List;

public interface DspService {
    DspSaveDTO saveDSP(DspSaveDTO saveDTO);

    List<DspSaveDTO> getAllDsp();

    DspSaveDTO getDspByCode(String code);

    String deleteDspByCode(String code) throws ResourceNotFoundException;
}
