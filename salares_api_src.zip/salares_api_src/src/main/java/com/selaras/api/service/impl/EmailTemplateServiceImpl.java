package com.selaras.api.service.impl;

import com.selaras.api.entity.EmailTemplate;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.EmailTemplateRepository;
import com.selaras.api.requests.EmailTemplateRequest;
import com.selaras.api.responses.EmailTemplateResettodefaultResponse;
import com.selaras.api.responses.EmailTemplateResponse;
import com.selaras.api.service.EmailTemplateService;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class EmailTemplateServiceImpl implements EmailTemplateService {

    private final EmailTemplateRepository emailTemplateRepository;

    @Override
    public String saveEmailTemplate(EmailTemplateRequest request) {
        EmailTemplate template = emailTemplateRepository.findByTemplateName(request.getTemplateName());
        if (template == null) {
            template = new EmailTemplate();
            template.setTemplateName(request.getTemplateName());
            template.setFirstSavedbody(request.getBody());
            template.setFirstSavedsubject(request.getSubject());
        }
        template.setBody(request.getBody());
        template.setSubject(request.getSubject());
        template.setActive(request.isActive());

        emailTemplateRepository.save(template);
        return "Email Template saved successfully";
    }

    @Override
    public List<EmailTemplateResponse> getAllEmailTemplates() {

        List<EmailTemplateResponse> responses = new ArrayList<>();
        List<EmailTemplate> emailTemplates = emailTemplateRepository.findAll();
        emailTemplates.forEach(i -> {
            EmailTemplateResponse response = new EmailTemplateResponse();
            response.setId(i.getId());
            response.setTemplateName(i.getTemplateName());
            response.setBody(i.getBody());
            response.setSubject(i.getSubject());
            response.setFirstSavedBody(i.getFirstSavedbody());
            response.setActive(i.getActive());
            response.setFirstSavedSubject(i.getFirstSavedsubject());
            responses.add(response);
        });
        return responses;
    }

   @Override
public EmailTemplateResponse getEmailById(Long id) throws ResourceNotFoundException {
    EmailTemplate emailTemplate = emailTemplateRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Email template not found with id: " + id));

    EmailTemplateResponse response = new EmailTemplateResponse();
    response.setId(emailTemplate.getId());
    response.setTemplateName(emailTemplate.getTemplateName());
    response.setBody(emailTemplate.getBody());
    response.setSubject(emailTemplate.getSubject());
    response.setFirstSavedBody(emailTemplate.getFirstSavedbody());
    response.setFirstSavedSubject(emailTemplate.getFirstSavedsubject());
    response.setActive(emailTemplate.getActive());

    return response;
}


@Override
public String updateEmailById(EmailTemplateRequest request,long id) throws ResourceNotFoundException {
    EmailTemplate emailTemplate = emailTemplateRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Email template not found with id: " + id));

    if (request.getTemplateName() != null) {
        emailTemplate.setTemplateName(request.getTemplateName());
    }

    if (request.getBody() != null) {
        emailTemplate.setBody(request.getBody());
    }

    if (request.getSubject() != null) {
        emailTemplate.setSubject(request.getSubject());
    }
    Boolean a=request.isActive();
    if (a != null) {
        emailTemplate.setActive(request.isActive());
    }

    emailTemplateRepository.save(emailTemplate);

    return "Email Template updated successfully";
}

@Override
public EmailTemplateResettodefaultResponse setDefault(long id) throws ResourceNotFoundException {
    EmailTemplate emailTemplate = emailTemplateRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Email template not found with id: " + id));

    EmailTemplateResettodefaultResponse response = new EmailTemplateResettodefaultResponse();

    response.setFirstSavedBody(emailTemplate.getFirstSavedbody());
    response.setFirstSavedSubject(emailTemplate.getFirstSavedsubject());
    response.setActive(emailTemplate.getActive());

    return response;
}


@Override
public String resetDefault(long id,EmailTemplateResettodefaultResponse emailTemplateResettodefaultResponse) throws ResourceNotFoundException {
    EmailTemplate emailTemplate = emailTemplateRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Email template not found with id: " + id));

    emailTemplate.setBody(emailTemplateResettodefaultResponse.getFirstSavedBody());
    emailTemplate.setSubject(emailTemplateResettodefaultResponse.getFirstSavedSubject());

    emailTemplateRepository.save(emailTemplate);

    return "Email Template reset to default values successfully";
}
}
