package com.selaras.api.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table( name = "head_break_pk" )
public class HeadBreakPk {

    @Id
    @GeneratedValue( strategy = GenerationType.IDENTITY )
    private Long id;

    @Column( name = "pk_value" )
    private String pkValue;

    @Column( name = "project_code_title" )
    private String projectCodeTitle;

    @JoinColumn( name = "department_id" )
    @ManyToOne
    private Department department;

    @ColumnDefault( "true" )
    @Column( name = "active" )
    private Boolean active;

    @Column( name = "created_by", length = 100 )
    private String createdBy;

    @ColumnDefault( "CURRENT_TIMESTAMP" )
    @Column( name = "created_at" )
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column( name = "modified_by", length = 100 )
    private String modifiedBy;

    @ColumnDefault( "CURRENT_TIMESTAMP" )
    @Column( name = "modified_at" )
    @UpdateTimestamp
    private LocalDateTime modifiedAt;
}
