package com.selaras.api.controller;

import com.selaras.api.audittrail.annotation.AuditTrail;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.requests.FaqRequest;
import com.selaras.api.responses.FaqResponse;
import com.selaras.api.service.FaqService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api")
@Validated
@RequiredArgsConstructor
public class FaqController {

    private final FaqService faqService;

    @Operation(summary = "Get Categories for FAQ", description = "Get Categories for FAQ")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/categories")
    @AuditTrail(recordType = "FAQCategory", action = "Get All FAQ Categories", presentValue = "Retrieved all FAQ categories")
    public ResponseEntity<List<FaqResponse>> getAllFaqCategories() {
        return ResponseEntity.ok(faqService.getAllFaqCategories());
    }

    @Operation(summary = "Create a FAQ", description = "Save FAQ")
    @ApiResponse(responseCode = "200", description = "OK")
    @PostMapping("/categories")
    @AuditTrail(recordType = "FAQ", action = "Create or Update FAQ", presentValue = "FAQ created or updated")
    public ResponseEntity<?> createOrUpdateFaq(@Valid @RequestBody FaqRequest faqRequest) throws BadRequestException {
        return ResponseEntity.ok(faqService.createOrUpdateFaq(faqRequest));
    }

    @Operation(summary = "List of FAQs", description = "List of FAQs")
    @ApiResponse(responseCode = "200", description = "OK")
    @GetMapping("/faqs")
    @AuditTrail(recordType = "FAQ", action = "Get All FAQs", presentValue = "Retrieved list of all FAQs")
    public ResponseEntity<?> getFaqs() throws BadRequestException {
        return ResponseEntity.ok(faqService.getAllFaqs());
    }


}
