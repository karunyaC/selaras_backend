package com.selaras.api.entity;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "rs_overview")
public class RSOverview {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rowId;

    @Column(unique = true, name = "rs_code")
    private String rsCode;

    @Column(name = "rs_plan_code", nullable = false)
    private String rsPlanCode;

    private Date rsStartyear;

    private Date rsEndyear;

    private Integer rsNumStrategies;

    private String rsNameStrategies;

    private Integer rsNumFocus;

    @Column(columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean statusLookup;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "modified_at")
    private Date modifiedAt;
}
