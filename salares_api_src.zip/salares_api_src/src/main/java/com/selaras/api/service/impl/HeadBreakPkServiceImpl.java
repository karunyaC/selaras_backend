package com.selaras.api.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.time.LocalDateTime;


import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.selaras.api.dto.HeadBreakPkDTO;
import com.selaras.api.entity.Department;
import com.selaras.api.entity.HeadBreakPk;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.exception.ResourceNotFoundRunTimeException;
import com.selaras.api.repository.DepartmentRepository;
import com.selaras.api.repository.HeadBreakPkRepository;
import com.selaras.api.service.HeadBreakPkService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HeadBreakPkServiceImpl implements HeadBreakPkService {

    private final HeadBreakPkRepository headBreakPkRepository;
    private final ModelMapper mapper;
    private final DepartmentRepository departmentRepository;

    @Override
public HeadBreakPkDTO saveHeadBreakPk(HeadBreakPkDTO headBreakPkDTO) throws ResourceNotFoundException {
    Department department = departmentRepository.findById(Long.valueOf(headBreakPkDTO.getDepartment_id()))
            .orElseThrow(() -> new ResourceNotFoundException("Department ID not found"));

    HeadBreakPk headBreakPk = new HeadBreakPk();
    headBreakPk.setPkValue(headBreakPkDTO.getPkValue());
    headBreakPk.setProjectCodeTitle(headBreakPkDTO.getProjectCodeTitle());
    headBreakPk.setDepartment(department);  
    headBreakPk.setActive(headBreakPkDTO.getActive());
    headBreakPk.setCreatedBy(headBreakPkDTO.getCreatedBy());
    headBreakPk.setCreatedAt(LocalDateTime.now()); 

    HeadBreakPk savedObject = headBreakPkRepository.save(headBreakPk);

    HeadBreakPkDTO savedDto = new HeadBreakPkDTO();
    savedDto.setId(savedObject.getId());
    savedDto.setPkValue(savedObject.getPkValue());
    savedDto.setProjectCodeTitle(savedObject.getProjectCodeTitle());
    savedDto.setDepartment_id(savedObject.getDepartment() != null ? savedObject.getDepartment().getId() : null);
    savedDto.setActive(savedObject.getActive());
    savedDto.setCreatedBy(savedObject.getCreatedBy());
    savedDto.setCreatedAt(savedObject.getCreatedAt());
    savedDto.setModifiedBy(savedObject.getModifiedBy());
    savedDto.setModifiedAt(savedObject.getModifiedAt());

    return savedDto;
}

@Override
public HeadBreakPkDTO updateHeadBreak(HeadBreakPkDTO headBreakPkDTO) throws ResourceNotFoundException {
    // Find the existing object by ID
    HeadBreakPk foundObject = findById(headBreakPkDTO.getId());
    
    if (foundObject == null) {
        // Handle not found case, possibly throw an exception or return null
        throw new ResourceNotFoundException("HeadBreakPk not found with ID: " + headBreakPkDTO.getId());
    }

    // Update fields selectively
    foundObject.setPkValue(headBreakPkDTO.getPkValue());
    foundObject.setProjectCodeTitle(headBreakPkDTO.getProjectCodeTitle());
    foundObject.setActive(headBreakPkDTO.getActive());
    foundObject.setModifiedBy(headBreakPkDTO.getCreatedBy()); // assuming updated by the same user
    foundObject.setModifiedAt(LocalDateTime.now());

    // Handle department if it’s provided
    if (headBreakPkDTO.getDepartment_id() != null) {
        Department department = departmentRepository.findById(Long.valueOf(headBreakPkDTO.getDepartment_id()))
                .orElseThrow(() -> new ResourceNotFoundException("Department ID not found"));
        foundObject.setDepartment(department);
    }

    // Save the updated object
    HeadBreakPk updatedObject = headBreakPkRepository.save(foundObject);

    // Map and return the updated DTO
    HeadBreakPkDTO updatedDto = new HeadBreakPkDTO();
    updatedDto.setId(updatedObject.getId());
    updatedDto.setPkValue(updatedObject.getPkValue());
    updatedDto.setProjectCodeTitle(updatedObject.getProjectCodeTitle());
    updatedDto.setDepartment_id(updatedObject.getDepartment() != null ? updatedObject.getDepartment().getId() : null);
    updatedDto.setActive(updatedObject.getActive());
    updatedDto.setCreatedBy(updatedObject.getCreatedBy());
    updatedDto.setCreatedAt(updatedObject.getCreatedAt());
    updatedDto.setModifiedBy(updatedObject.getModifiedBy());
    updatedDto.setModifiedAt(updatedObject.getModifiedAt());

    return updatedDto;
}


    @Override
    public List< HeadBreakPkDTO > getAllHeadBreakPk() {

        List< HeadBreakPk > foundList = headBreakPkRepository.findAll();
        List< HeadBreakPkDTO > dtoList = new ArrayList<>();

        if ( foundList.isEmpty() ) {
            return List.of();
        } else {
            for ( HeadBreakPk value : foundList ) {
                HeadBreakPkDTO dto = mapper.map( value, HeadBreakPkDTO.class );
                if (value.getDepartment() != null) {
                    dto.setDepartment_id(value.getDepartment().getId());
                } else {
                    dto.setDepartment_id(null);
                }                dtoList.add( dto );
            }
            return dtoList;
        }
    }

    @Override
public List<HeadBreakPkDTO> deleteHeadBreakPk(Long[] ids) throws ResourceNotFoundException {
    List<HeadBreakPkDTO> updatedDtos = new ArrayList<>();

    for (Long id : ids) {
        HeadBreakPk foundObject = findById(id);
        if (foundObject != null) {
            foundObject.setActive(false);
            HeadBreakPk updatedObject = headBreakPkRepository.save(foundObject);

            // Map and add the updated DTO to the list
            HeadBreakPkDTO updatedDto = new HeadBreakPkDTO();
            updatedDto.setId(updatedObject.getId());
            updatedDto.setPkValue(updatedObject.getPkValue());
            updatedDto.setProjectCodeTitle(updatedObject.getProjectCodeTitle());
            updatedDto.setDepartment_id(updatedObject.getDepartment() != null ? updatedObject.getDepartment().getId() : null);
            updatedDto.setActive(updatedObject.getActive());
            updatedDto.setCreatedBy(updatedObject.getCreatedBy());
            updatedDto.setCreatedAt(updatedObject.getCreatedAt());
            updatedDto.setModifiedBy(updatedObject.getModifiedBy());
            updatedDto.setModifiedAt(updatedObject.getModifiedAt());

            updatedDtos.add(updatedDto); // Add the updated DTO to the list
        } else {
            throw new ResourceNotFoundException("HeadBreakPk not found with ID: " + id);
        }
    }

    return updatedDtos;  // Return the list of updated DTOs
}


    private HeadBreakPk findById( Long id ) {
        return headBreakPkRepository
                .findById( id )
                .orElseThrow( () -> new ResourceNotFoundRunTimeException( " No Such Data Found !!! " ) );
    }

    @Override
public List<HeadBreakPkDTO> getdepartmentBreakPkbyid(Long id) throws ResourceNotFoundRunTimeException {
    List<HeadBreakPk> foundObjects = headBreakPkRepository.findAllByDepartmentId(id.intValue());

    if (foundObjects.isEmpty()) {
      return List.of();
    }

    return foundObjects.stream()
                       .map(object -> convertToDto(object))
                       .collect(Collectors.toList());
}

private HeadBreakPkDTO convertToDto(HeadBreakPk entity) {
    HeadBreakPkDTO dto = new HeadBreakPkDTO();
    
    dto.setId(entity.getId());
    dto.setPkValue(entity.getPkValue());
    dto.setProjectCodeTitle(entity.getProjectCodeTitle());
    dto.setDepartment_id(entity.getDepartment() != null ? entity.getDepartment().getId() : null);
    dto.setActive(entity.getActive());
    dto.setCreatedBy(entity.getCreatedBy());
    dto.setCreatedAt(entity.getCreatedAt());
    dto.setModifiedBy(entity.getModifiedBy());
    dto.setModifiedAt(entity.getModifiedAt());
    
    return dto;
}

    
    
    
    
    
}
