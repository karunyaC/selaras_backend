package com.selaras.api.service.impl;

import com.selaras.api.entity.PasswordRules;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.PasswordRulesRepository;
import com.selaras.api.requests.AppSecurityRequest;
import com.selaras.api.responses.AppSecurityResponse;
import com.selaras.api.service.AppSecurityServices;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AppSecurityServicesImpl implements AppSecurityServices {


   private final PasswordRulesRepository passwordRulesRepository;

    @Override
    public String saveAppSecurity(List<AppSecurityRequest> request) {

        request.forEach(rule -> {
            PasswordRules passwordRule = passwordRulesRepository.findByRuleNameAndSecurityType(rule.getRuleName(), rule.getSecurityType());

            if (passwordRule == null) {
                passwordRule = new PasswordRules();
            }

            passwordRule.setRuleName(rule.getRuleName());
            passwordRule.setRuleValue(rule.getRuleValue());
            passwordRule.setActive(rule.isActive());
            passwordRule.setDescription(rule.getRuleDescription());
            passwordRule.setCreatedBy("TestUser");
            passwordRule.setSecurityType(rule.getSecurityType());
            passwordRulesRepository.save(passwordRule);
        });
        return "All password rules have been updated";
    }

    @Override
    public List<AppSecurityResponse> getAppSecurities(String securityType) {
        List<AppSecurityResponse> responses = new ArrayList<>();
        List<PasswordRules> allRules = passwordRulesRepository.findAllBySecurityType(securityType);
        allRules.forEach(rule -> {
            AppSecurityResponse response = new AppSecurityResponse();
            response.setActive(rule.getActive());
            response.setRuleValue(rule.getRuleValue());
            response.setRuleDescription(rule.getDescription());
            response.setRuleName(rule.getRuleName());
            response.setId(rule.getId());
            responses.add(response);
        });
        return responses;
    }

    @Override
    public AppSecurityResponse getAppSecuritiesById(Long id) throws ResourceNotFoundException {
        AppSecurityResponse response = new AppSecurityResponse();

        Optional<PasswordRules> passwordRule = passwordRulesRepository.findById(id);

        if(!passwordRule.isPresent()) {
            throw new ResourceNotFoundException("No rule found with given id");
        }

        response.setActive(passwordRule.get().getActive());
        response.setRuleValue(passwordRule.get().getRuleValue());
        response.setRuleDescription(passwordRule.get().getDescription());
        response.setRuleName(passwordRule.get().getRuleName());
        response.setId(passwordRule.get().getId());

        return response;
    }

    @Override
public AppSecurityResponse updateAppSecuritiesById(Long id, Boolean active, String ruleValue) throws ResourceNotFoundException {
    PasswordRules passwordRule = passwordRulesRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("No rule found with the given id"));

    
    if (active != null) {
        passwordRule.setActive(active);
    }
    if (ruleValue != null && !ruleValue.trim().isEmpty()) {
        passwordRule.setRuleValue(ruleValue);
    }

    passwordRulesRepository.save(passwordRule);

    AppSecurityResponse response = new AppSecurityResponse();
    response.setActive(passwordRule.getActive());
    response.setRuleValue(passwordRule.getRuleValue());
    response.setRuleDescription(passwordRule.getDescription());
    response.setRuleName(passwordRule.getRuleName());
    response.setId(passwordRule.getId());

    return response;
}

}
