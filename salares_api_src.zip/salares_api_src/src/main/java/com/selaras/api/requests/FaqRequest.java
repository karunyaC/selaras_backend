package com.selaras.api.requests;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class FaqRequest {

    @NotEmpty(message = "Article title cannot be empty")
    private String articleTitle;

    private String articleSummary;

    @NotNull(message = "Article category ID cannot be null")
    private Integer articleCategoryId;

    @NotEmpty(message = "Article description cannot be empty")
    private String articleDescription;

}

