package com.selaras.api.requests;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SpSaveDTO {
    private String spCode;
    private String yearFrom;
    private String yearUpto;
    private String noOfCores;
    private List<CoreDTO> core;
    private boolean status;
}