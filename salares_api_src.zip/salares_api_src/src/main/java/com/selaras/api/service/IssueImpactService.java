package com.selaras.api.service;

import java.util.List;
import com.selaras.api.dto.IssueImpactDTO;
import com.selaras.api.exception.ResourceNotFoundException;

public interface IssueImpactService {
    IssueImpactDTO createIssueImpact(IssueImpactDTO issueImpactDTO);

    IssueImpactDTO getIssueImpactById(Long id) throws ResourceNotFoundException;

    List<IssueImpactDTO> getAllIssueImpacts() ;

    IssueImpactDTO updateIssueImpact(Long id, IssueImpactDTO issueImpactDTO) throws ResourceNotFoundException;

    String deleteIssueImpact(Long id) throws ResourceNotFoundException;
}
