package com.selaras.api.dto;

import java.util.Date;

public class RSCoreDTO {
    private Long rowId;
    private String rsStratId;
    private String rsCode;
    private String rsPlanCode;
    private String rsStratPreferredName;
    private String rsStratPreferredCode;
    private Date createdAt;
    private Date modifiedAt; 
}
