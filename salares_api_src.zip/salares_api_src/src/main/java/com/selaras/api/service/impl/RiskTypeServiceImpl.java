package com.selaras.api.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.selaras.api.dto.RiskTypeDTO;
import com.selaras.api.entity.RiskType;
import com.selaras.api.repository.RiskTypeRepository;
import com.selaras.api.service.RiskTypeService;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
@Service
@RequiredArgsConstructor
public class RiskTypeServiceImpl implements RiskTypeService {

 private final RiskTypeRepository riskTypeRepository;

private final ModelMapper modelMapper;
    @Override
    public List<RiskTypeDTO> getAll() {
        List<RiskType> riskTypes=riskTypeRepository.findAll();
        return riskTypes.stream().map(x->{
            RiskTypeDTO riskTypeDTOs=new RiskTypeDTO();
            riskTypeDTOs.setId(x.getId());
            riskTypeDTOs.setRiskCode(x.getRiskCode());
            riskTypeDTOs.setRiskType(x.getRiskType());
            riskTypeDTOs.setCreatedAt(x.getCreatedAt());
            riskTypeDTOs.setCreatedBy(x.getCreatedBy());
            riskTypeDTOs.setIsActive(x.getIsActive());
            riskTypeDTOs.setModifiedAt(x.getModifiedAt());
            riskTypeDTOs.setModifiedBy(x.getModifiedBy());
            return riskTypeDTOs;
        }).collect(Collectors.toList());
    }

  @Override
public String updateById(RiskTypeDTO riskTypeDTO,long id) {
    Optional<RiskType> optionalRiskType = riskTypeRepository.findById(id);

    if (optionalRiskType.isPresent()) {
        RiskType riskType = optionalRiskType.get();
        
        riskType.setRiskCode(riskTypeDTO.getRiskCode());
        riskType.setRiskType(riskTypeDTO.getRiskType());
        riskType.setCreatedAt(riskTypeDTO.getCreatedAt());
        riskType.setCreatedBy(riskTypeDTO.getCreatedBy());
        riskType.setIsActive(riskTypeDTO.getIsActive());
        riskType.setModifiedAt(riskTypeDTO.getModifiedAt());
        riskType.setModifiedBy(riskTypeDTO.getModifiedBy());
        
        riskTypeRepository.save(riskType);
        return "Updated successfully";
    } else {
        throw new EntityNotFoundException("RiskType with ID " + riskTypeDTO.getId() + " not found.");
    }
}

@Override
public String bulkDeletes(List<Long> ids) {
    List<RiskTypeDTO> updatedRiskTypes = new ArrayList<>();

    for (Long id : ids) {
        Optional<RiskType> riskTypeOptional = riskTypeRepository.findById(id);

        if (riskTypeOptional.isPresent()) {
            RiskType riskType = riskTypeOptional.get();
            riskType.setIsActive(false); // Deactivate the RiskType
            riskTypeRepository.save(riskType);
            
            RiskTypeDTO response = new RiskTypeDTO();
            response.setId(riskType.getId());
            response.setRiskCode(riskType.getRiskCode());
            response.setRiskType(riskType.getRiskType());
            response.setCreatedAt(riskType.getCreatedAt());
            response.setCreatedBy(riskType.getCreatedBy());
            response.setIsActive(riskType.getIsActive());
            response.setModifiedAt(riskType.getModifiedAt());
            response.setModifiedBy(riskType.getModifiedBy());
            updatedRiskTypes.add(response);
        } else {
            throw new EntityNotFoundException("RiskType with ID " + id + " not found.");
        }
    }
    return" RiskType(s) deactivated successfully.";

}
    @Override
    public RiskTypeDTO createNew(RiskTypeDTO riskImpactDTO) {
         RiskType aRiskType=modelMapper.map(riskImpactDTO, RiskType.class);
         RiskType saveRiskType=riskTypeRepository.save(aRiskType);
         return modelMapper.map(saveRiskType,RiskTypeDTO.class);         
    }
    
}
