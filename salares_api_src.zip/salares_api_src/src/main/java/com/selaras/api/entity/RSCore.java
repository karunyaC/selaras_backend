package com.selaras.api.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "rs_core")
public class RSCore {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rowId;

    @Column(unique = true)
    private String rsStratId;

    @ManyToOne
    @JoinColumn(name = "rs_code", referencedColumnName = "rs_code")
    private RSOverview rsCode;

    @ManyToOne
    @JoinColumn(name = "rs_plan_code", referencedColumnName = "rs_plan_code")
    private RSOverview rsPlanCode;

    private String rsStratPreferredName;
    private String rsStratPreferredCode;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "modified_at")
    private Date modifiedAt;
}
