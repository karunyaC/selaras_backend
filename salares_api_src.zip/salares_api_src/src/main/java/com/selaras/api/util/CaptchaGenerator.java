package com.selaras.api.util;

import com.selaras.api.entity.UserAccount;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.UserAccountRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

@Component
@RequiredArgsConstructor
public class CaptchaGenerator {
    private static final Random RANDOM = new Random();

    private final UserAccountRepository userAccountRepository;

    // Settings based on DefaultKaptcha configuration
    private static final Color BACKGROUND_COLOR = new Color(230, 230, 230); // Light gray
    private static final Color BORDER_COLOR = new Color(200, 0, 0); // Red border
    private static final Color TEXT_COLOR = new Color(0, 0, 255); // Blue text
    private static final Color LINE_COLOR = new Color(0, 0, 0); // Black lines

    private static final Font TEXT_FONT = new Font("宋体", Font.ITALIC | Font.BOLD, 50); // Font and size
    private static final int CHAR_COUNT = 6; // Number of characters
    private static final int IMAGE_WIDTH = 200;
    private static final int IMAGE_HEIGHT = 100;
    private static final float HORIZ_MARGIN = 20.0f;

    public void generateCaptcha(HttpServletRequest request, HttpServletResponse response, String email) throws IOException, ResourceNotFoundException {
            // Create the buffered image
            BufferedImage bufferedImage = new BufferedImage(IMAGE_WIDTH, IMAGE_HEIGHT, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = bufferedImage.createGraphics();

            // Fill background
            g.setColor(BACKGROUND_COLOR);
            g.fillRect(0, 0, IMAGE_WIDTH, IMAGE_HEIGHT);

            // Setup text properties
            g.setColor(TEXT_COLOR);
            g.setFont(TEXT_FONT);
            FontMetrics fontMetrics = g.getFontMetrics();
            String eligibleChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
            char[] chars = eligibleChars.toCharArray();
            float spaceForLetters = -HORIZ_MARGIN * 2 + IMAGE_WIDTH;
            float spacePerChar = spaceForLetters / (CHAR_COUNT - 1.0f);
            StringBuilder finalString = new StringBuilder();

            // Draw characters with subtle distortions and slight random rotations
            for (int i = 0; i < CHAR_COUNT; i++) {
                char characterToShow = chars[RANDOM.nextInt(chars.length)];
                finalString.append(characterToShow);

                BufferedImage charImage = createDistortedCharacterImage(characterToShow, fontMetrics, TEXT_COLOR);
                float x = HORIZ_MARGIN + spacePerChar * i - charImage.getWidth() / 2.0f;
                int y = (IMAGE_HEIGHT - charImage.getHeight()) / 2;

                // Apply slight random rotation
                g.rotate(Math.toRadians(RANDOM.nextInt(10) - 5), x + charImage.getWidth() / 2.0, y + charImage.getHeight() / 2.0);
                g.drawImage(charImage, (int) x, y, null);
                g.rotate(-Math.toRadians(RANDOM.nextInt(10) - 5), x + charImage.getWidth() / 2.0, y + charImage.getHeight() / 2.0);
            }

            // Draw random lines across the text
//            drawDistortingLines(g, IMAGE_WIDTH, IMAGE_HEIGHT, LINE_COLOR);

            // Add noise dots
            addNoiseDots(g, IMAGE_WIDTH, IMAGE_HEIGHT);

            // Apply subtle wave distortion
            applySubtleWaveDistortion(bufferedImage);

            // Draw border around the image
            g.setColor(BORDER_COLOR);
            g.drawRect(0, 0, IMAGE_WIDTH - 1, IMAGE_HEIGHT - 1);
            g.dispose();

            // Store CAPTCHA in session
            String captchaString = finalString.toString();
            HttpSession session = request.getSession(true);
            session.setAttribute("captcha", captchaString);

            UserAccount existingUser = userAccountRepository.findByEmail(email);

            if(existingUser == null) {
                throw new ResourceNotFoundException("User does not exist with given email");
            }

            existingUser.setLoginCaptcha(captchaString);
            userAccountRepository.save(existingUser);

            // Output the image
            response.setContentType("image/png");
            ImageIO.write(bufferedImage, "png", response.getOutputStream());
            response.getOutputStream().close();
    }

    private void drawDistortingLines(Graphics2D g, int width, int height, Color lineColor) {
        g.setColor(lineColor);
        for (int i = 0; i < 5; i++) {  // Fewer lines
            int x1 = RANDOM.nextInt(width);
            int y1 = RANDOM.nextInt(height);
            int x2 = RANDOM.nextInt(width);
            int y2 = RANDOM.nextInt(height);
            g.drawLine(x1, y1, x2, y2);
        }
    }

    private BufferedImage createDistortedCharacterImage(char character, FontMetrics fontMetrics, Color textColor) {
        int charWidth = fontMetrics.charWidth(character);
        int charHeight = fontMetrics.getHeight();
        BufferedImage charImage = new BufferedImage(charWidth, charHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D charGraphics = charImage.createGraphics();

        // Draw character with italic style
        charGraphics.setColor(textColor);
        charGraphics.setFont(TEXT_FONT);
        charGraphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        charGraphics.drawString(String.valueOf(character), 0, fontMetrics.getAscent());

        // Apply very slight distortion
        applySlightDistortion(charImage);

        charGraphics.dispose();
        return charImage;
    }

    private void applySlightDistortion(BufferedImage image) {
        Graphics2D g = image.createGraphics();
        g.setComposite(AlphaComposite.SrcOver.derive(0.8f)); // Slight transparency
        g.setColor(new Color(0, 0, 0, 60)); // Subtle distortion color

        // Draw few random lines for slight distortion
        for (int i = 0; i < 2; i++) {
            int x1 = RANDOM.nextInt(image.getWidth());
            int y1 = RANDOM.nextInt(image.getHeight());
            int x2 = RANDOM.nextInt(image.getWidth());
            int y2 = RANDOM.nextInt(image.getHeight());
            g.drawLine(x1, y1, x2, y2);
        }

        g.dispose();
    }

    private void addNoiseDots(Graphics2D g, int width, int height) {
        g.setColor(new Color(0, 0, 0)); // Black noise dots
        for (int i = 0; i < 100; i++) {  // Reduced number of noise dots
            int x = RANDOM.nextInt(width);
            int y = RANDOM.nextInt(height);
            g.drawOval(x, y, 1, 1);
        }
    }

    private void applySubtleWaveDistortion(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        BufferedImage distortedImage = new BufferedImage(width, height, image.getType());

        double waveFrequency = 3.0; // Fixed wave frequency for subtle distortion
        double waveAmplitude = 2.0; // Fixed wave amplitude for subtle distortion

        for (int y = 0; y < height; y++) {
            int yOffset = (int) (Math.sin((double) y / waveFrequency) * waveAmplitude);
            for (int x = 0; x < width; x++) {
                int xOffset = (int) (Math.sin((double) x / waveFrequency) * waveAmplitude);
                int newX = Math.min(Math.max(x + xOffset, 0), width - 1);
                int newY = Math.min(Math.max(y + yOffset, 0), height - 1);
                distortedImage.setRGB(newX, newY, image.getRGB(x, y));
            }
        }

        Graphics2D g = image.createGraphics();
        g.drawImage(distortedImage, 0, 0, null);
        g.dispose();
    }
}
