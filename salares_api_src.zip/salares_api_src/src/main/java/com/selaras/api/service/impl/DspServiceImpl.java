package com.selaras.api.service.impl;

import com.selaras.api.entity.DSPCore;
import com.selaras.api.entity.DSPOverview;
import com.selaras.api.entity.DSPStrategy;
import com.selaras.api.exception.BadRequestException;
import com.selaras.api.exception.ResourceNotFoundException;
import com.selaras.api.repository.DSPCoreRepository;
import com.selaras.api.repository.DSPOverviewRepository;
import com.selaras.api.repository.DSPStrategyRepository;
import com.selaras.api.requests.CoreDTO;
import com.selaras.api.requests.DspSaveDTO;
import com.selaras.api.requests.StrategyDTO;
import com.selaras.api.service.DspService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DspServiceImpl implements DspService {

    private final DSPOverviewRepository dspOverviewRepository;
    private final DSPCoreRepository dspCoreRepository;
    private final DSPStrategyRepository dspStrategyRepository;

    @Override
    public DspSaveDTO saveDSP(DspSaveDTO saveDTO) {
// Create and save DSPOverview

        DSPOverview dspOverview = dspOverviewRepository.findByCode(saveDTO.getPlanCode());
        if (dspOverview == null) {
            dspOverview = new DSPOverview();
        }
        dspOverview.setCode(saveDTO.getPlanCode());
        dspOverview.setStartYear(saveDTO.getYearFrom());
        dspOverview.setEndYear(saveDTO.getYearUpto());
        dspOverview.setNumCores(Integer.valueOf(saveDTO.getNoOfCores()));
        dspOverview.setStatusLookup(saveDTO.isStatus());
        dspOverviewRepository.save(dspOverview);

        // Loop through each core in the request
        int coreCount = 1;
        for (CoreDTO coreRequest : saveDTO.getCore()) {
            DSPCore dspCore = dspCoreRepository.findByCorePreferredName(coreRequest.getCoreName());
            if (dspCore == null) {
                dspCore = new DSPCore();
            }
            dspCore.setCorePreferredCode("PSP-KP-T" + coreCount);
            dspCore.setCorePreferredName(coreRequest.getCoreName());
            dspCore.setPlanCode(dspOverview.getCode());
            dspCoreRepository.save(dspCore);


            // Loop through each strategy in the core
            int strategyCount = 1;
            for (StrategyDTO strategyRequest : coreRequest.getStrategy()) {
                DSPStrategy dspStrategy = dspStrategyRepository.findByStratPreferredName(strategyRequest.getStrategyName());
                if (dspStrategy == null) {
                    dspStrategy = new DSPStrategy();
                }
                dspStrategy.setCode(dspCore.getCorePreferredCode() + "-S" + strategyCount);
                dspStrategy.setCoreId(dspCore.getCorePreferredCode());
                dspStrategy.setStratPreferredName(strategyRequest.getStrategyName());
                dspStrategy.setPlanCode(dspOverview.getCode());
                dspStrategyRepository.save(dspStrategy);
                strategyCount++;
            }
            coreCount++;
        }
        return saveDTO;
    }

    @Override
    public List<DspSaveDTO> getAllDsp() {
        List<DSPOverview> overviews = dspOverviewRepository.findAll();
        List<DspSaveDTO> saveDTOS = new ArrayList<>();
        overviews.forEach(o -> {
            DspSaveDTO saveDTO = new DspSaveDTO();
            saveDTO.setPlanCode(o.getCode());
            saveDTO.setNoOfCores(String.valueOf(o.getNumCores()));
            saveDTO.setYearFrom(o.getStartYear());
            saveDTO.setYearUpto(o.getEndYear());
            saveDTO.setStatus(o.isStatusLookup());
            List<DSPCore> cores = dspCoreRepository.findByPlanCode(o.getCode());
            List<CoreDTO> coreDTOS = new ArrayList<>();
            cores.forEach(c -> {
                CoreDTO coreDTO = new CoreDTO();
                coreDTO.setCoreName(c.getCorePreferredName());
                List<DSPStrategy> strategies = dspStrategyRepository.findByCoreId(c.getCorePreferredCode());
                List<StrategyDTO> strategyDTOS = new ArrayList<>();
                strategies.forEach(s -> {
                    StrategyDTO strategyDTO = new StrategyDTO();
                    strategyDTO.setStrategyCode(s.getCode());
                    strategyDTO.setStrategyName(s.getStratPreferredName());
                    strategyDTOS.add(strategyDTO);
                });
                coreDTO.setStrategy(strategyDTOS);
                coreDTOS.add(coreDTO);
            });
            saveDTO.setCore(coreDTOS);
            saveDTOS.add(saveDTO);
        });
        return saveDTOS;
    }

    @Override
    public DspSaveDTO getDspByCode(String code) {
        DSPOverview overviews = dspOverviewRepository.findByCode(code);
        if(overviews == null) {
            return new DspSaveDTO();
        }
        DspSaveDTO saveDTO = new DspSaveDTO();
        saveDTO.setPlanCode(overviews.getCode());
        saveDTO.setNoOfCores(String.valueOf(overviews.getNumCores()));
        saveDTO.setYearFrom(overviews.getStartYear());
        saveDTO.setYearUpto(overviews.getEndYear());
        saveDTO.setStatus(overviews.isStatusLookup());
        List<DSPCore> cores = dspCoreRepository.findByPlanCode(overviews.getCode());
        List<CoreDTO> coreDTOS = new ArrayList<>();
        cores.forEach(c -> {
            CoreDTO coreDTO = new CoreDTO();
            coreDTO.setCoreName(c.getCorePreferredName());
            List<DSPStrategy> strategies = dspStrategyRepository.findByCoreId(c.getCorePreferredCode());
            List<StrategyDTO> strategyDTOS = new ArrayList<>();
            strategies.forEach(s -> {
                StrategyDTO strategyDTO = new StrategyDTO();
                strategyDTO.setStrategyCode(s.getCode());
                strategyDTO.setStrategyName(s.getStratPreferredName());
                strategyDTOS.add(strategyDTO);
            });
            coreDTO.setStrategy(strategyDTOS);
            coreDTOS.add(coreDTO);
        });
        saveDTO.setCore(coreDTOS);

        return saveDTO;
    }

    @Override
    public String deleteDspByCode(String code) throws ResourceNotFoundException {
        DSPOverview overviews = dspOverviewRepository.findByCode(code);
        if(overviews == null) {
            throw new ResourceNotFoundException("Digitization Strategic Plan not found with given code");
        }
        overviews.setStatusLookup(false);
        dspOverviewRepository.save(overviews);
        return "Digitization Strategic Plan deleted successfully";
    }
}
