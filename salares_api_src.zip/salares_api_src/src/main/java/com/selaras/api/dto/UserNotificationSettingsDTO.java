package com.selaras.api.dto;


import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class UserNotificationSettingsDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;

    private String promotionTitle;

    private Long projectCategoryId;

    private String description;

    private String platform;

    private LocalDateTime promotionScheduling;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;

}
