package com.selaras.api.service.impl;

import com.selaras.api.dto.AccessLevelDTO;
import com.selaras.api.repository.AccessLevelRepository;
import com.selaras.api.service.AccessLevelService;

import lombok.RequiredArgsConstructor;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AccessLevelServiceImpl implements AccessLevelService {

    private  final AccessLevelRepository accessLevelRepository;


    private ModelMapper modelMapper;

    @Override
    public List<AccessLevelDTO> getAccessLevels() {
        var accessLevels = accessLevelRepository.findAll();

        return accessLevels
                .stream()
                .map(accessLevel -> modelMapper.map(accessLevel, AccessLevelDTO.class))
                .collect(Collectors.toList());
    }
}
