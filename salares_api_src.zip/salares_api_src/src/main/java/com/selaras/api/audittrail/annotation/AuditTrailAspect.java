package com.selaras.api.audittrail.annotation;

import com.selaras.api.requests.AuditTrailRequest;
import com.selaras.api.responses.SignupRequest;
import com.selaras.api.service.AuditTrailService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
@Component
public class AuditTrailAspect {

    private static final Logger logger = LoggerFactory.getLogger(AuditTrailAspect.class);

    @Autowired
    private AuditTrailService auditTrailService;

    @Around("@annotation(auditTrail)")
    public Object saveAuditTrail(ProceedingJoinPoint joinPoint, AuditTrail auditTrail) throws Throwable {
        // Capture the state before method execution
      //  Object previousState = captureStateBeforeExecution(joinPoint,auditTrail);

        Object result = null;

        try {
            result = joinPoint.proceed();

            // Capture the state after method execution
         //   Object presentState = captureStateAfterExecution(result);

            if (result == null || (result instanceof ResponseEntity && ((ResponseEntity<?>) result).getStatusCode().is2xxSuccessful())) {
                String userEmail = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
                logger.info("User Email: {}", userEmail);

                AuditTrailRequest auditTrailRequest = new AuditTrailRequest();
                auditTrailRequest.setUserEmail(userEmail);
                auditTrailRequest.setRecordType(auditTrail.recordType());
                auditTrailRequest.setAction(auditTrail.action());
                auditTrailRequest.setPreviousValue(auditTrail.previousValue());
                auditTrailRequest.setPresentValue(auditTrail.previousValue());
                //auditTrailRequest.setPreviousValue(previousState != null ? previousState.toString() : "");
                //auditTrailRequest.setPresentValue(auditTrail.presentValue());

                auditTrailService.saveAuditTrail(auditTrailRequest);
                logger.info("Audit trail saved successfully.");
            }
        } catch (Throwable throwable) {
            logger.error("Exception in method execution, audit trail will not be saved.", throwable);
            throw throwable;
        }
        return result;
    }
    private Object captureStateBeforeExecution(ProceedingJoinPoint joinPoint, AuditTrail auditTrail) {
        // Capture arguments and specifically handle SignupRequest
        Object[] args = joinPoint.getArgs();
        if (args.length > 0 && args[0] instanceof SignupRequest) {
            SignupRequest signupRequest = (SignupRequest) args[0];
            // Return a representation of the SignupRequest state
            return "SignupRequest: " + signupRequest.toString();
        }
        // If SignupRequest is not present, return the default previous value from the annotation
        return auditTrail.previousValue();
    }

    private Object captureStateAfterExecution(Object result) {
        // Return a representation of the method result
        if (result instanceof ResponseEntity) {
            ResponseEntity<?> responseEntity = (ResponseEntity<?>) result;
            // Return a representation of the ResponseEntity state
            return "ResponseEntity: " + responseEntity.getBody(); // Assuming you want to log the body
        }
        // If the result is not an instance of ResponseEntity, just return its string representation
        return result != null ? result.toString() : null;
    }

}

