package com.selaras.api.requests;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HelpdeskLogRequest {

    private Long srNumber;
    private String comment;
    private String commentBy;
}
