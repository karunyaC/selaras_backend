package com.selaras.api.dto;


import com.selaras.api.requests.ModuleAccessLevelsDTO;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class RoleDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;

    private String name;

    private String type;

    private String description;

    private Boolean active;

    private String createdBy;

    private LocalDateTime createdAt;

    private String modifiedBy;

    private LocalDateTime modifiedAt;

    private ModuleAccessLevelsDTO moduleAccessLevelsDTOS;

}
