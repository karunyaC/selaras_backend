package com.selaras.api.repository.specification;

import com.selaras.api.entity.UserAccount;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;

public class UserAccountSpecification implements Specification<UserAccount> {

    private final UserAccount filter;

    public UserAccountSpecification(UserAccount filter) {
        this.filter = filter;
    }

    @Override
    public Predicate toPredicate(Root<UserAccount> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();

        if (filter.getName() != null && !filter.getName().isEmpty()) {
            predicates.add(criteriaBuilder.like(root.get("name"), "%" + filter.getName() + "%"));
        }

        if (filter.getEmail() != null && !filter.getEmail().isEmpty()) {
            predicates.add(criteriaBuilder.equal(root.get("email"), filter.getEmail()));
        }

        if (filter.getDomainId() != null) {
            predicates.add(criteriaBuilder.equal(root.get("domainId"), filter.getDomainId()));
        }
        
        if (filter.getKpNumber() != null && !filter.getKpNumber().isEmpty()) {
            predicates.add(criteriaBuilder.like(root.get("kpNumber"), "%" + filter.getName() + "%"));
        }

        if (filter.getActive() != null) {
            predicates.add(criteriaBuilder.equal(root.get("active"), filter.getActive()));
        }

        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }
}
